import java.io._

import org.apache.commons.compress.compressors.bzip2.{BZip2CompressorInputStream, BZip2CompressorOutputStream}

import scala.collection.mutable
import scala.io.Source

/**
  * Data Management for disk-based map-reduce-like processing
  * 2016-08 by Gerard de Melo
  * http://gerard.demelo.org/
  */
object DataManager {
  def mapFiles(inputFiles: Seq[File],
               outputFile: File,
               mapper: (String, String) => Seq[(String, String)]) = {
    val outputStream = new BufferedOutputStream(
      new BZip2CompressorOutputStream(new FileOutputStream(outputFile)))
    val outputWriter = new OutputStreamWriter(outputStream, "UTF-8")
    for (inputFile <- inputFiles) {
      println("Mapper for " + inputFile)
      val inputStream = new BufferedInputStream(
        new BZip2CompressorInputStream(new FileInputStream(inputFile)))
      for (outputEntry <- Source
        .fromInputStream(inputStream, "UTF-8")
        .getLines()
        .map(_.split("\t", 2))
        .filter(_.length > 0)
        .flatMap(entry => mapper(entry(0), entry(1)))) outputWriter
        .write(outputEntry._1 + "\t" + outputEntry._2 + "\n")
      inputStream.close()
    }
    outputWriter.close()
  }

  def reduceFile(sortedFile: File, process: (String, Seq[String]) => Unit) = {
    println("Reducer on " + sortedFile)
    val inputStream = new BufferedInputStream(
      new BZip2CompressorInputStream(new FileInputStream(sortedFile)))
    var currentKey: String = null
    var currentItems: Seq[String] = null
    for (entry <- Source
      .fromInputStream(inputStream, "UTF-8")
      .getLines()
      .map(_.split("\t", 2))
      .filter(_.length > 0)) {
      val key = entry(0)
      val value = entry(1)
      if (key == currentKey)
        currentItems = currentItems :+ value
      else {
        if (currentItems != null)
          process(key, currentItems) // process last key
        currentKey = key
        currentItems = Seq(value)
      }
    }
    if (currentKey != null)
      process(currentKey, currentItems) // process final key
    inputStream.close()
  }

  def sortOutputFile(inputFile: File): File = {
    val inputFilePath = inputFile.getPath
    val sortedFile = new File(
      // either go from ".unsorted" to "" or from "" to ".sorted". Always output ".bz2" since the sorted file
      // is a final output
      if (inputFilePath.contains(".unsorted.tsv.bz2"))
        inputFilePath.replace("unsorted.tsv.bz2", ".tsv.bz2")
      else if (inputFilePath.contains(".unsorted.tsv.gz"))
        inputFilePath.replace("unsorted.tsv.gz", ".tsv.bz2")
      else
        inputFilePath
          .replace(".tsv.bz2", ".sorted.tsv.bz2")
          .replace(".tsv.gz", ".sorted.tsv.bz2"))
    println("Sorting " + inputFile)
    val decompressor =
      if (inputFilePath.endsWith(".gz"))
        "gunzip -c"
      else
        "bzcat"
    sys.process
      .Process(Seq("bash",
        "-c",
        decompressor + " " + inputFile.getPath +
          " | sort | bzip2 > " + sortedFile))
      .!
    sortedFile
  }

  def writeCounts(minThreshold: Double,
                  counts: mutable.Map[String, Int],
                  outputFile: File) = {
    val s =
      counts
        .map(entry => " Count for " + entry._1 + ": " + entry._2)
        .mkString("\n") + "\n Total: " + counts.values.sum + "\n"
    java.nio.file.Files.write(
      outputFile.toPath, s.getBytes(java.nio.charset.StandardCharsets.UTF_8))
  }
}
