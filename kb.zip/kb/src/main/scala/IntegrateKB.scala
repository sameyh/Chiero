import java.io._

import org.apache.commons.compress.compressors.bzip2.{BZip2CompressorInputStream, BZip2CompressorOutputStream}
import org.apache.commons.compress.archivers.zip.ZipFile
import org.apache.jena.riot.RDFDataMgr
import org.apache.jena.riot.system.{StreamRDF, StreamRDFBase}

import scala.collection.mutable
import scala.io.Source
import scala.collection.JavaConversions._

/**
  * Integrate KBs
  * 2016-07 by Gerard de Melo
  * http://gerard.demelo.org/
  */
object IntegrateKB {

  val sameAsURI = "http://www.w3.org/2002/07/owl#sameAs"
  val labelURI = "http://www.w3.org/2000/01/rdf-schema#label"
  val meansRelation = "http://lexvo.org/ontology#means"

  /** *********************************************************************************************************/
  /**
    * process an RDF file
    *
    * @param inputFile
    * @param handler
    */
  def processRDF(inputFile: File, handler: StreamRDF) = {
    // open input stream
    val inputStreamDirect = new FileInputStream(inputFile)
    val inputStream: InputStream =
      if (inputFile.getName.endsWith(".bz2"))
        //inputStreamDirect
        new BufferedInputStream(
            new BZip2CompressorInputStream(inputStreamDirect, true))
            // set decompressConcatenated to true to ensure that concatenated bzip2 streams are supported!!!
      else
        new BufferedInputStream(inputStreamDirect)
    // parse
    val parser =
      RDFDataMgr.createReader(org.apache.jena.riot.RDFLanguages.TURTLE)
    parser.read(inputStream, null, null, handler, null)
    // close input
    inputStream.close
  }

  /**
    * parse CSV line entry
    * source: http://stackoverflow.com/questions/32488364/whats-a-simple-scala-only-way-to-read-in-and-then-write-out-a-small-csv-file/32488453#32488453
    *
    * @param line
    * @return
    */
  def parseCSVLine(line: String): List[String] = {
    def recursive(
        lineRemaining: String,
        isWithinDoubleQuotes: Boolean,
        valueAccumulator: String,
        accumulator: List[String]
    ): List[String] = {
      if (lineRemaining.isEmpty)
        valueAccumulator :: accumulator
      else if (lineRemaining.head == '"')
        if (isWithinDoubleQuotes)
          if (lineRemaining.tail.nonEmpty && lineRemaining.tail.head == '"')
            // escaped double quote
            recursive(lineRemaining.drop(2),
                      true,
                      valueAccumulator + '"',
                      accumulator)
          else
            // end of double quote pair (ignore whatever's between here and the next comma)
            recursive(lineRemaining.dropWhile(_ != ','),
                      false,
                      valueAccumulator,
                      accumulator)
        else
          // start of a double quote pair (ignore whatever's in valueAccumulator)
          recursive(lineRemaining.drop(1), true, "", accumulator)
      else if (isWithinDoubleQuotes)
        // scan to next double quote
        recursive(
            lineRemaining.dropWhile(_ != '"'),
            true,
            valueAccumulator + lineRemaining.takeWhile(_ != '"'),
            accumulator
        )
      else if (lineRemaining.head == ',')
        // advance to next field value
        recursive(
            lineRemaining.drop(1),
            false,
            "",
            valueAccumulator :: accumulator
        )
      else
        // scan to next double quote or comma
        recursive(
            lineRemaining.dropWhile(char => (char != '"') && (char != ',')),
            false,
            valueAccumulator +
            lineRemaining.takeWhile(char => (char != '"') && (char != ',')),
            accumulator
        )
    }
    if (line.nonEmpty)
      recursive(line, false, "", Nil).reverse
    else
      Nil
  }

  /** *********************************************************************************************************/
  /**
    * Entity ID canonicalization
    *
    * @param iso639CodesFile ISO 639-3 code table available from SIL
    */
  class Canonicalizer(iso639CodesFile: File, relevantLanguages: Seq[String]) {
    val mappings = mutable.HashMap[String, String]()
    val iso639P3toP1Table = Source.fromFile(iso639CodesFile, "UTF-8")
      .getLines()
      .drop(1)
      .map(_.split("\t"))
      .filter(e => e.length > 0 && e(3).length > 0)
      .map(e => e(0) -> e(3))
      .toMap

    val dbpediaUriPrefix = "http://dbpedia.org/resource/"
    val relevantPrefixes =
      relevantLanguages.filter(_ != "en").map("http://" + _ + ".dbpedia.org/")

    def getIdFromDBpediaEn(uri: String): Option[String] = {
      if (uri.startsWith(dbpediaUriPrefix))
        Some(uri.substring(dbpediaUriPrefix.length))
      else None
    }

    def add(uri: String, id: String) =
      if (relevantPrefixes.exists(uri.startsWith(_)))
        mappings.put(uri, id)

    def tableSize = mappings.size

    def save(file: File) = {
      val outputStream = new BufferedOutputStream(
          new BZip2CompressorOutputStream(new FileOutputStream(file)))
      val outputWriter = new OutputStreamWriter(outputStream, "UTF-8")
      for ((key, value) <- mappings) outputWriter.write(
          key + "\t" + value + "\n")
      outputWriter.close()
    }

    def load(file: File) = {
      val inputStream = new BufferedInputStream(
          new BZip2CompressorInputStream(new FileInputStream(file)))
      for (entry <- Source
                     .fromInputStream(inputStream, "UTF-8")
                     .getLines()
                     .map(_.split("\t", 2))
                     .filter(_.length > 0)) add(entry(0), entry(1))
      inputStream.close()
    }

    def canonicalize(uri: String): String = mappings.get(uri) match {
      case Some(uri) => uri // successful lookup in mappings table
      case _ =>
        getIdFromDBpediaEn(uri).getOrElse(uri) // for English DBpedia, normalize to ID part, otherwise keep original URI
    }

    def canonicalizePredicate(uri: String) =
      uri // just keep original predicate URI

    def getIdFromLinguisticExpression(
        expression: String, languageCode: String) = {
      val langCodeToUse =
        if (languageCode.length == 3)
          iso639P3toP1Table.getOrElse(languageCode, languageCode)
        else languageCode
      "\"" + expression + "\"" + "@" + langCodeToUse
    }
  }

  /**
    * integrate RDF files
    */
  def integrateRDF(dir: File, canonicalizer: Canonicalizer) = {
    println("Initializing Canonicalizer")

    val canonicalizerFile = new File("idmappings.tsv.bz2")
    if (canonicalizerFile.exists())
      canonicalizer.load(canonicalizerFile)
    else {
      val dumpsWithSameAsLinks =
        if (dir.getName == "dbpedia")
          dir.listFiles().filter(_.getName.startsWith("interlanguage_links_"))
        else
          dir.listFiles()
      for (inputFile <- dumpsWithSameAsLinks) {
        println(inputFile)
        processRDF(
            inputFile,
            new StreamRDFBase() {
              var counter = 0

              override def triple(
                  statement: org.apache.jena.graph.Triple): Unit = {
                if (statement.getPredicate.getURI == sameAsURI) {
                  val stSubject = statement.getSubject.getURI
                  val stObject = statement.getObject.getURI
                  val canonicalizedSubject =
                    canonicalizer.canonicalize(stSubject)
                  val canonicalizedObject =
                    canonicalizer.canonicalize(stObject)
                  if (canonicalizedSubject != stSubject) // note: will e.g. apply if the subject is a basic DBpedia URI
                    canonicalizer.add(stObject, canonicalizedSubject) // map object to canonicalized ID of subject
                  if (canonicalizedObject != stObject) // note: will e.g. apply if the object is a basic DBpedia URI
                    canonicalizer.add(stSubject, canonicalizedObject) // map subject to canonicalized ID of object
                }
                counter += 1
                if (counter % 500000 == 0)
                  println(counter + ": " + canonicalizer.tableSize +
                      " stored so far, free mem: " +
                      Runtime.getRuntime.freeMemory())
              }
            })
      }
      canonicalizer.save(canonicalizerFile)
    }
    println("  Total mappings: " + canonicalizer.tableSize)

    println("Integrating KBs")

    integrationViaCanonicalizer(dir, canonicalizer, true, true)
  }

  /**
    * integrate via canonicalizer
    */
  def integrationViaCanonicalizer(dir: File,
                                  canonicalizer: Canonicalizer,
                                  writeMappedKnowledge: Boolean,
                                  writeLexicalKnowledge: Boolean) = {
    val outputStream = new BZip2CompressorOutputStream(
        new BufferedOutputStream(new FileOutputStream(
                new File((if (!writeMappedKnowledge && writeLexicalKnowledge)
                            "kb-entities-lexicon"
                          else "kb-entities-integrated") + ".tsv.bz2"))))
    val outputWriter = new OutputStreamWriter(outputStream, "UTF-8")
    val inputFiles = dir
      .listFiles()
      .filter(f =>
            f.getName.endsWith(".ttl.bz2") &&
            !f.getName.startsWith("interlanguage_links_")
            // skip sameAs links from DBpedia
            && (writeMappedKnowledge || dir.getName != "dbpedia" ||
                f.getName.startsWith("labels_")))
    // if not in writtedMappedKnowledge mode then for DBpedia read only relevant files
    for (inputFile <- inputFiles) {
      println(inputFile)
      processRDF(inputFile, new StreamRDFBase() {
        var counter = 0

        override def triple(statement: org.apache.jena.graph.Triple): Unit = {
          val stSubject = statement.getSubject.getURI
          val stPredicate = statement.getPredicate.getURI
          val stObjectOrig = statement.getObject
          val stObject = stObjectOrig.toString(true)

          val mappedSubject = canonicalizer.canonicalize(stSubject)

          if (writeMappedKnowledge) {
            val mappedPredicate =
              canonicalizer.canonicalizePredicate(stPredicate)
            val mappedObject = canonicalizer.canonicalize(stObject)
            outputWriter.write(mappedSubject + "\t" + mappedPredicate + "\t" +
                mappedObject + "\n")
          }

          if (writeLexicalKnowledge && stPredicate == labelURI)
            outputWriter.write(
                stObject + "\t" + meansRelation + "\t" + mappedSubject + "\n")

          counter += 1
          if (counter % 500000 == 0)
            println(counter)
        }
      })
    }
    outputWriter.close()
  }

  /**
    * integrate GeoNames
    *
    * @param languagesToConsider desired language codes (note that GeoNames also uses some custom one such as "post" for postal codes), the ones
    *                            supplied should be ISO 639-1 codes
    */
  def integrateGeoNames(dir: File,
                        languagesToConsider: Set[String],
                        canonicalizer: Canonicalizer) = {
    println("GeoNames importing")

    val zipFile1 = new ZipFile(new File(dir, "allCountries.zip"))
    val zipEntries1 = zipFile1.getEntries.toList
    val outputStream1 = new BufferedOutputStream(
        new BZip2CompressorOutputStream(
            new FileOutputStream("kb-geo.tsv.bz2")))
    val outputWriter1 = new OutputStreamWriter(outputStream1, "UTF-8")
    for (fileEntry <- zipEntries1
                       .filter(_.getName.endsWith("allCountries.txt"))
                       .headOption) {
      val inputStream = zipFile1.getInputStream(fileEntry)
      val entries = Source.fromInputStream(inputStream, "UTF-8")
        .getLines()
        .drop(1)
        .map(line => line.split("\t"))
        .filter(_.length > 0)
      for (entry <- entries) {
        val geoNamesId = "geonames" + entry(0)
        if (entry(1).length > 0) {
          val name = canonicalizer.getIdFromLinguisticExpression(
              entry(1), "en") // assume English
          outputWriter1.write(
              name + "\t" + meansRelation + "\t" + geoNamesId + "\n")
          outputWriter1.write(
              geoNamesId + "\t" + labelURI + "\t" + name + "\n")
        }
      }
      inputStream.close()
    }
    outputWriter1.close()
    zipFile1.close()

    val zipFile2 = new ZipFile(new File(dir, "alternateNames.zip"))
    val zipEntries2 = zipFile2.getEntries.toList
    val outputStream2 = new BufferedOutputStream(
        new BZip2CompressorOutputStream(
            new FileOutputStream("kb-geo-labels.tsv.bz2")))
    // kb-geo already contains labels. kb-geo-labels gets alternative labels.
    val outputWriter2 = new OutputStreamWriter(outputStream2, "UTF-8")
    for (fileEntry <- zipEntries2
                       .filter(_.getName.endsWith("alternateNames.txt"))
                       .headOption) {
      val inputStream = zipFile2.getInputStream(fileEntry)
      val entries = Source
        .fromInputStream(inputStream, "UTF-8")
        .getLines()
        .drop(1)
        .map(line => line.split("\t"))
        .filter(_.length > 0)
      for (entry <- entries) {
        val geoNamesId = "geonames" + entry(1)
        val languageCode = entry(2)
        if (languagesToConsider.contains(languageCode)) {
          val name =
            canonicalizer.getIdFromLinguisticExpression(entry(3), languageCode)
          outputWriter2.write(
              name + "\t" + meansRelation + "\t" + geoNamesId + "\n")
          outputWriter2.write(
              geoNamesId + "\t" + labelURI + "\t" + name + "\n")
        }
      }
      inputStream.close()
    }
    outputWriter2.close()
    zipFile2.close()
  }


  /**
    * integrate PanLex data sources
    * (Requires reading from several tables, some of which we hold in memory)
    *
    * @param dir
    * @param canonicalizer
    */
  def integratePanLexSources(dir: File, canonicalizer: Canonicalizer) = {
    println("PanLex importing")
    val zipFile = new ZipFile(new File(dir, "panlex-20160701-csv.zip"))
    val zipEntries = zipFile.getEntries.toList
    val acceptableSources: Set[Int] = zipEntries
      .filter(_.getName.endsWith("ap.csv"))
      .headOption
      .map(fileEntry => {
        val inputStream = zipFile.getInputStream(fileEntry)
        case class DataSource(id: Int,
                              title: String,
                              url: String,
                              author: String,
                              publisher: String,
                              date: String,
                              licenseId: String,
                              licenseNotes: String)
        val dataSources = Source
          .fromInputStream(inputStream, "UTF-8")
          .getLines()
          .drop(1)
          .map(line => parseCSVLine(line))
          .filter(_.length > 0)
          .map(line =>
                DataSource(line(0).toInt,
                           line(6),
                           line(3),
                           line(5),
                           line(7),
                           line(8),
                           line(12),
                           line(13)))
          .toList
        val whitelistedLicenses = Set("gp", "gd", "gl")
        val whitelistedLicenseNotes = Set(
            "Tutti i dizionari/liste di parole sono pubblicati sotto una Licenza Creative Commons.",
            "Text is available under the Creative Commons Attribution/Share-Alike License; additional terms may apply.",
            "Los derechos de autor de los contenidos de este sitio se rigen por los términos de La Licencia de Atribución Creative Commons 3.0 (Unported).",
            "Dbnary by Gilles Sérasset is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License.",
            "Text is available under the Creative Commons Attribution-ShareAlike License; additional terms may apply.",
            "This work is licensed under the Creative Commons Attribution-Share Alike 3.0 Unported License.",
            "Текст доступен на условиях лицензии Creative Commons Attribution/Share-Alike, в отдельных случаях могут действовать дополнительные условия."
        )
        inputStream.close()
        val dataSourcesToKeep = dataSources.filter(s =>
              whitelistedLicenses.contains(s.licenseId) ||
              whitelistedLicenseNotes.contains(s.licenseNotes))
        val dataSourcesList = dataSourcesToKeep
          .map(d => (d.title + ", " + d.url).trim)
          .distinct
          .sorted
        println(dataSourcesList.mkString("\n"))
        println("  Acceptable sources (unique): " + dataSourcesList.size)
        // note that this list is shorter than the number of acceptable sources, because there are duplicates, perhaps
        // due to different parts of the data being used
        dataSourcesToKeep.map(_.id).toSet
      })
      .getOrElse(Set())
    println(
        "  Acceptable sources (# PanLex source IDs): " +
        acceptableSources.size)
    println("  Reading language varieties...")
    case class LanguageVarietyEntry(iso639p3Code: String, variety: Int)
    val languageVarieties: Map[Int, LanguageVarietyEntry] = zipEntries
      .filter(_.getName.endsWith("lv.csv"))
      .headOption
      .map(fileEntry => {
        val inputStream = zipFile.getInputStream(fileEntry)
        val results = Source
          .fromInputStream(inputStream, "UTF-8")
          .getLines()
          .drop(1)
          .map(line => line.split(","))
          .filter(entry => entry.length > 0)
          .map(entry =>
                entry(0).toInt -> LanguageVarietyEntry(entry(1),
                                                       entry(2).toInt))
          .toMap
        inputStream.close()
        results
      })
      .getOrElse(Map())
    println("  Reading meanings...")
    val acceptableMeaningMappings: Map[Int, Int] = zipEntries
      .filter(_.getName.endsWith("mn.csv"))
      .headOption
      .map(fileEntry => {
        val inputStream = zipFile.getInputStream(fileEntry)
        val entries = Source
          .fromInputStream(inputStream, "UTF-8")
          .getLines()
          .drop(1)
          .map(line => line.split(","))
          .filter(entry =>
                entry.length > 0 && acceptableSources.contains(entry(1).toInt))
          .map(entry => (entry(0).toInt, entry(1).toInt))
          .toMap
        inputStream.close()
        entries
      })
      .getOrElse(Map())
    val mappingsString = acceptableMeaningMappings
      .map(kv => "panlex:dn:" + kv._1 + "\t" + kv._2)
      .mkString("\n")
    java.nio.file.Files.write(
        new File("panlex-sources.tsv").toPath,
        mappingsString.getBytes(java.nio.charset.StandardCharsets.UTF_8))
    val acceptableMeanings: Set[Int] = acceptableMeaningMappings.keys.toSet
    println("    Size: " + acceptableMeanings.size)
    println("  Reading denotations...")
    val denotations = new mutable.HashMap[Int, mutable.Set[Int]]
    with mutable.MultiMap[Int, Int]
    for (fileEntry <- zipEntries
                       .filter(_.getName.endsWith("dn.csv"))
                       .headOption) {
      val inputStream = zipFile.getInputStream(fileEntry)
      val entries = Source
        .fromInputStream(inputStream, "UTF-8")
        .getLines()
        .drop(1)
        .map(line => line.split(","))
        // schema: denotation-ID,meaning-ID,expression-ID
        .filter(entry =>
              entry.length > 0 && acceptableMeanings.contains(entry(1).toInt))
        .map(entry => (entry(2).toInt -> entry(1).toInt)) // expression -> meaning
      var i = 0
      for (entry <- entries) {
        denotations.addBinding(entry._1, entry._2)
        i += 1
        if (i % 100000 == 0)
          println(i)
      }
      inputStream.close()
    }
    println("  Processing expressions...")
    val outputStream = new BufferedOutputStream(
        new BZip2CompressorOutputStream(
            new FileOutputStream("kb-lexicon.tsv.bz2")))
    val outputWriter = new OutputStreamWriter(outputStream, "UTF-8")
    for (fileEntry <- zipEntries
                       .filter(_.getName.endsWith("ex.csv"))
                       .headOption) {
      val inputStream = zipFile.getInputStream(fileEntry)
      val expressionEntries = Source
        .fromInputStream(inputStream, "UTF-8")
        .getLines()
        .drop(1)
        .map(line => parseCSVLine(line))
        .filter(entry => entry.length > 0)
      var counter = 0
      for (expressionEntry <- expressionEntries) for (meaning <- denotations
                                                                  .getOrElse(
                                                                    expressionEntry(
                                                                        0).toInt,
                                                                    Seq())) {
        val meaningId = "panlex:dn:" + meaning
        val languageVariety = expressionEntry(1).toInt
        for (languageVarietyMap̦̦ping <- languageVarieties.get(
                                            languageVariety)) {
          if (languageVarietyMap̦̦ping.variety == 0) {
            val expression = canonicalizer.getIdFromLinguisticExpression(
                expressionEntry(2), languageVarietyMap̦̦ping.iso639p3Code)
            outputWriter.write(
                expression + "\t" + meansRelation + "\t" + meaningId + "\n")
            outputWriter.write(
                meaningId + "\t" + labelURI + "\t" + expression + "\n")
          }
        }
      }
      inputStream.close()
    }
    outputWriter.close()
    zipFile.close()
  }

}
