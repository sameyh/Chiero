import java.io._

import org.apache.commons.compress.compressors.bzip2.{BZip2CompressorInputStream, BZip2CompressorOutputStream}

import scala.collection.mutable
import scala.io.Source

/**
  * Main Routine for KB Creation
  * 2016-07/08 by Gerard de Melo
  * http://gerard.demelo.org/
  */
object Analysis {
  def getLanguageCode(entityId: String): Option[String] = {
    entityId.lastIndexOf("\"@") match {
      case -1 => None
      case i => Some(entityId.substring(i + 2))
    }
  }

  /**
    * analyse input data
    */
  def analysis(fileGroups: Seq[Seq[File]], relevantLanguages: Seq[String], labelURI: String) = {

    // Analyse entities
    for (fileGroup <- fileGroups) {
      println(fileGroup.map(_.getName).mkString(", "))
      val seenEntities = new mutable.HashSet[String]()
      var entities = 0
      var termsEn = 0
      var termsZh = 0
      var termsCmn = 0
      var termsKo = 0
      var termsOther = 0
      for (file <- fileGroup) {
        val inputStream = new BufferedInputStream(
          new BZip2CompressorInputStream(new FileInputStream(file)))
        for (entry <- Source
          .fromInputStream(inputStream, "UTF-8")
          .getLines()
          .map(_.split("\t"))
          .filter(_.length == 3)) for (entity <- Seq(entry(0),
          entry(2))) // use subject and object
          if (seenEntities.add(entity)) {
            entities += 1
            getLanguageCode(entity) match {
              case Some("en") => termsEn += 1
              case Some("zh") => termsZh += 1
              case Some("cmn") => termsCmn += 1
              case Some("ko") => termsKo += 1
              case Some(s) => termsOther += 1
              case None => // do nothing
            }
          }
        inputStream.close()
      }
      println("  Entities:          " + entities)
      println(
        "  Non-Term Entities: " +
          (entities - (termsEn + termsZh + termsCmn + termsKo + termsOther)))
      println("  Terms (en):        " + termsEn)
      println("  Terms (zh):        " + termsZh)
      println("  Terms (cmn):       " + termsCmn)
      println("  Terms (ko):        " + termsKo)
      println("  Terms (other):     " + termsOther)
    }

    // lexical link analysis
    new File("work/links/lexical/").mkdirs()
    for (fileGroup <- fileGroups.filter(_.length > 0)) {
      val sortedFile = new File("work/" + fileGroup.head.getParentFile, fileGroup.head.getName.replace(".tsv.bz2",
        //(if (fileGroup.length > 1) "-alllabels" else "-labels") +
        "-alllabels" +
          "-sorted.tsv.bz2"))
      if (!sortedFile.exists()) {
        println("Sorting " + fileGroup.map(_.getName).mkString(", "))
        sys.process.Process(Seq("bash", "-c", "bzcat " + fileGroup.mkString(" ") + " | grep rdf-schema#label | sort | bzip2 > " + sortedFile)).!
      }

      println("Scanning " + sortedFile) // TODO: this could use the reducer code
      val outputCrossLingualFn = new File("work/links/lexical/" + fileGroup.head.getName.replace(".tsv.bz2", "-links-crosslingual.unsorted.tsv.bz2"))
      val outputMonoLingualFn = new File("work/links/lexical/" + fileGroup.head.getName.replace(".tsv.bz2", "-links-monolingual.unsorted.tsv.bz2"))
      // TODO: use gzip instead for more speed
      val outputCrossLingual = new OutputStreamWriter(new BufferedOutputStream(new BZip2CompressorOutputStream(new FileOutputStream(outputCrossLingualFn))), "UTF-8")
      val outputMonoLingual = new OutputStreamWriter(new BufferedOutputStream(new BZip2CompressorOutputStream(new FileOutputStream(outputMonoLingualFn))), "UTF-8")
      val stats = new EntityLabelStats(Some(outputCrossLingual), Some(outputMonoLingual), relevantLanguages)
      // read sorted file in sequential order. Keep track of current entity and process batch of labels for each entry
      // whenever there is a change of subject
      val inputStream = new BufferedInputStream(new BZip2CompressorInputStream(new FileInputStream(sortedFile)))
      var currentSubject: String = null
      var currentItems: Seq[String] = null
      for (entry <- Source.fromInputStream(inputStream, "UTF-8").getLines().map(_.split("\t")).filter(_.length > 0)) {
        val stSubject = entry(0)
        val stPredicate = entry(1)
        val stObject = entry(2)
        if (stPredicate == labelURI) {
          if (currentSubject == stSubject)
            currentItems = currentItems :+ stObject
          else {
            if (currentItems != null)
              stats.process(currentItems.distinct) // process last entity
            currentSubject = stSubject
            currentItems = Seq(stObject)
          }
        }
      }
      if (currentSubject != null)
        stats.process(currentItems.distinct) // process final entity
      inputStream.close()
      outputCrossLingual.close()
      outputMonoLingual.close()
      println(stats)
      DataManager.sortOutputFile(outputCrossLingualFn)
      DataManager.sortOutputFile(outputMonoLingualFn)
    }
  }



  /**
    * Entity-specific analysis of relationships
    */
  class EntityLabelStats(outputFileCrossLingual: Option[OutputStreamWriter], outputFileMonolingual: Option[OutputStreamWriter], relevantLanguages: Seq[String]) {
    val relevantLanguageCodesIdx = relevantLanguages.zipWithIndex.toList
    var nWithLang = Array.ofDim[Int](relevantLanguages.length)
    var nTransitions = Array.ofDim[Int](relevantLanguages.length, relevantLanguages.length)

    def process(labels: Seq[String]) = {
      val languageGroups = labels
        .map(label => (label, getLanguageCode(label).getOrElse("")))
        // extract language code
        .groupBy(kv => kv._2).mapValues(group => group.map(_._1))
        .map(identity) // materialize
      val counts: Map[String,Int] = languageGroups
          .map({case (k,v) => k -> v.size})
      // count all language codes
      for ((lang,i) <- relevantLanguageCodesIdx) {
        val n1 = counts.getOrElse(lang, 0)
        if (n1 > 0) {
          nWithLang(i) += 1
          for ((lang2, j) <- relevantLanguageCodesIdx) {
            if (i == j) {
              if (n1 > 1) {
                nTransitions(i)(j) += n1 * (n1 - 1)
                outputFileMonolingual match {
                  case Some(writer) => {
                    val terms = languageGroups.getOrElse(lang, Seq())
                    for (term1 <- terms; term2 <- terms if (term1 != term2))
                      writer.write(term1 + "\t" + term2 + "\n")
                  }
                  case None => {}
                }
              }
            } else {
              val n2 = counts.getOrElse(lang2, 0)
              if (n2 > 0) {
                nTransitions(i)(j) += n1 * n2
                outputFileCrossLingual match {
                  case Some(writer) => {
                    val terms1 = languageGroups.getOrElse(lang, Seq())
                    val terms2 = languageGroups.getOrElse(lang2, Seq())
                    for (term1 <- terms1; term2 <- terms2)
                      writer.write(term1 + "\t" + term2 + "\n")
                  }
                  case None => {}
                }
              }
            }
          }
        }
      }
    }

    override def toString = {
      nWithLang.zipWithIndex.map({case (count,i) => "Entities with language " + relevantLanguages(i) + ": " + count}).mkString("\n") +
        "\n\n" +
        nTransitions.zipWithIndex.flatMap({case (array,i) =>
          array.zipWithIndex.map({case (count,j) => "Links from " + relevantLanguages(i) + " to " + relevantLanguages(j) + ": " + count})})
          .mkString("\n")
    }
  }

}
