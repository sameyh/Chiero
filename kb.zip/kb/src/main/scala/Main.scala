import java.io.File

/**
  * Main Routine for KB Creation
  * 2016-07/08 by Gerard de Melo
  * http://gerard.demelo.org/
  */
object Main {

  val iso639CodesFile = new File("data/iso-639-3_20160525.tab")

  val relevantLanguages = Seq("en", "ko", "zh", "cmn")


  /***********************************************************************************************************/
  def main(args: Array[String]) = {
    // parameters
    val doIntegration = false
    val doAnalysis = false

    println("KB Integration ")
    println("  Max memory: " + Runtime.getRuntime.maxMemory())
    //println("  Current total memory for JVM: " + Runtime.getRuntime.totalMemory())
    //println("  Number of cores: " + Runtime.getRuntime.availableProcessors())

    new File("work").mkdirs()

    if (doIntegration) {
      val canonicalizer = new IntegrateKB.Canonicalizer(iso639CodesFile, relevantLanguages)

      for (datasetDir <- new File("data").listFiles().filter(_.isDirectory)) {
        datasetDir.getName match {
          case "geonames" =>
            // handling GeoNames
            IntegrateKB.integrateGeoNames(datasetDir, Set("ko", "zh", "en"), canonicalizer)
          case "panlex" =>
            // handling PanLex sources
            IntegrateKB.integratePanLexSources(datasetDir, canonicalizer)
          case _ =>
            // default: assume RDF
            IntegrateKB.integrateRDF(datasetDir, canonicalizer)
        }
      }
    }
    val kbFiles =
      new File(".")
        .listFiles()
        .filter(file =>
          file.getName.startsWith("kb-") && file.getName.endsWith(
            ".tsv.bz2") && !file.getName.endsWith(".sorted.tsv.bz2") &&
            !file.getName.endsWith("-sorted.tsv.bz2"))

    CreateLinks.createLinks(kbFiles.filter(_.getName != "kb-entities-integrated.tsv.bz2"), IntegrateKB.meansRelation)
    // note: currently skipping "kb-entities-integrated.tsv.bz2" because it doesn't contain means-relationships

    if (doAnalysis) {
      val kbGroupAssignments = Map(
        "kb-geo.tsv.bz2" -> "geo", "kb-geo-labels.tsv.bz2" -> "geo")
      val kbGroups = kbFiles
        .groupBy(f => kbGroupAssignments.getOrElse(f.getName, f.getName))
        .values
        .map(_.toList.sortBy(_.getName))
        .toSeq
      Analysis.analysis(kbGroups, relevantLanguages, IntegrateKB.labelURI)
    }
  }
}
