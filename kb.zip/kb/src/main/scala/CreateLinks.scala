import java.io._
import java.util.zip.{GZIPInputStream, GZIPOutputStream}

import scala.collection.mutable
import scala.io.Source

/**
  * Link Creation
  * 2016-08 by Gerard de Melo
  * http://gerard.demelo.org/
  */
object CreateLinks {
  def createLinks(kbFiles: Array[File], meansRelation: String) = {
    val termFile = new File("work/termmap.tsv.bz2")
    val meansRelationPrefix = meansRelation + "\t"
    val meansRelationPrefixLen = meansRelationPrefix.length
    def mapper(key: String, value: String): Seq[(String,String)] = {
      if (value.startsWith(meansRelationPrefix))
        Seq((key.replace("\"@cmn", "\"@zh"), value.substring(meansRelationPrefixLen)))
          // lossy language code normalization
      else
        Seq()
    }
    DataManager.mapFiles(kbFiles, termFile, mapper)
    val sortedFile = DataManager.sortOutputFile(termFile)

    val panlexSources = Source.fromFile("panlex-sources.tsv").getLines().map(_.split("\t")).filter(_.length > 0)
        .map(entry => entry(0).substring("panlex:dn:".length).toInt -> entry(1).toInt).toMap
    def sourceId(entityId: String): String = {
      if (entityId.startsWith("\""))
        "<literal>"
      else if (entityId.startsWith("panlex:dn:")) {
        "panlex" + panlexSources.getOrElse(entityId.substring("panlex:dn:".length).toInt, -1)
      } else if (entityId.startsWith("geonames")) {
        "geonames"
      } else {
        "dbpedia" // could also be a number literal, but we count those as being in the same space for now
      }
    }

    val counts = (0 until 5).map(i => mutable.Map[String,Int]().withDefaultValue(0)).toArray
    val countThresholds = Array(0.05, 0.3, 0.5, 0.75, 1.0)
    val outputFile = new File("work/links/predicted.unsorted.tsv.gz")
    var outputWriter = new OutputStreamWriter(new BufferedOutputStream(new GZIPOutputStream(new FileOutputStream(outputFile))), "UTF-8")
    var counter = 0
    val minThreshold = 0.05
    def reducer(key: String, values: Seq[String]) = {
      counter += 1
      if (counter % 50000 == 0)
        println(counter + " " + key)
      val entitiesBySource = values.groupBy(entity => sourceId(entity))
      val maxGroupSize = entitiesBySource.values.map(_.size).max
      for (group1Key <- entitiesBySource.keys; group2Key <- entitiesBySource.keys if group1Key != group2Key) {
        val group1 = entitiesBySource.getOrElse(group1Key, Seq())
        val group2 = entitiesBySource.getOrElse(group2Key, Seq())
        //val score = (1.0/group1.size + 1.0/group2.size)/2.0 // alternative scoring
        val score = 1.0/3 * 1.0/maxGroupSize + 1.0/3 * 1.0/group1.size + 1.0/3 * 1.0/group2.size
        if (score >= minThreshold) {
          for (entity1 <- group1; entity2 <- group2)
            outputWriter.write(entity1 + "\t" + entity2 + "\t" + score + "\n")
          for (i <- 0 until 5)
            if (score >= countThresholds(i))
              counts(i)(group1Key + "-" + group2Key) = counts(i)(group1Key + "-" + group2Key) + group1.size * group2.size
        }
      }
    }
    DataManager.reduceFile(sortedFile, reducer)
    outputWriter.close()
    for (i <- 0 until 5)
      DataManager.writeCounts(countThresholds(i), counts(i), new File("work/links/predicted-report" + countThresholds(i) + ".txt"))
    DataManager.sortOutputFile(outputFile)

    // Note: An optional follow-up operation would be to do another map-reduce step to aggregate all individual links for a given
    // entity pair so that we can obtain their overall weight. However, in some applications, maintaining the fine-grained
    // information may be better.

    // finally, we create a smaller filtered version, that only contains links with weight >=0.5.
    val finalThreshold = 0.5
    outputWriter = new OutputStreamWriter(
      new BufferedOutputStream(new GZIPOutputStream(
        new FileOutputStream("work/links/predicted-" + finalThreshold + ".tsv.gz"))),
      "UTF-8")
    val inputStream = new BufferedInputStream(new GZIPInputStream(
      new FileInputStream("work/links/predicted.unsorted.tsv.gz")))
    var i = 0
    for (line <- Source.fromInputStream(inputStream, "UTF-8").getLines()) {
      val parts = line.split("\t", 3)
      if (parts.length > 0 && parts(2).toDouble >= finalThreshold)
        outputWriter.write(line + "\n")
      i += 1
      if (i % 100000 == 0)
        println(i + " " + line)
    }
    inputStream.close()
    outputWriter.close()
  }
}
