Knowledge Base Integration and Linking Code
Copyright (c) 2016 Gerard de Melo
