* Contents

Makefile	Makefile for compling coling 2016.tex in pdflatex
README.txt	This file
acl.bst		BibTeX `acl' style file
coling2016.dot	Microsoft Word template file for Coling 2016
coling2016.pdf	PDF file for Coling 2016
coling2016.sty	LaTeX style file for Coling 2016
coling2016.tex	LaTeX sample file for Coling 2016
