import numpy as np
cnt = 0
dic = {}
rdic = {}
fin = open('base_vec_d_100.txt', 'r')
part = fin.readline().strip().split()
dim = int(part[1])
vocab_size = int(part[0])
vec1 = np.zeros((vocab_size, dim))
vec2 = np.zeros((vocab_size, dim))
for line in fin:
    part = line.strip().split()
    dic[part[0]] = cnt
    rdic[cnt] = part[0]
    vec1[cnt, :] = part[1:]
    cnt += 1
fin.close()

fin = open('vec.txt', 'r')
fin.readline()
cnt = 0
for line in fin:
    part = line.strip().split()
    vec2[cnt, :] = part[1:]
    cnt += 1
fin.close()

def cosi(idx1, idx2, vec):
    ans = np.inner(vec[idx1, :], vec[idx2, :])
    ans /= np.linalg.norm(vec[idx1, :])
    ans /= np.linalg.norm(vec[idx2, :])
    return ans
ans = np.zeros((2, vocab_size, 20))
dis = -np.ones((2, vocab_size, 20))
def topk(x, vec, id):
    for i in xrange(vocab_size):
        if i == x:
            continue
        tmp = cosi(i, x, vec)
        if tmp > np.min(ans[id, x, :]):
            idx = np.argmin(ans[id, x, :])
            ans[id, x, idx] = i
            dis[id, x, idx] = tmp

fin = open('belist.txt', 'r')
print 'the word and its 20 nearest neighbors'
print 'first line word2vec'
print 'second line joint'
for line in fin:
    part = line.strip()
    x = dic[part[0]]
    topk(x, vec1, 0)
    topk(x, vec2, 1)
    print part
    for i in xrange(20):
        print rdic[ans[0, x, i]],
    print
    for i in xrange(20):
        print rdic[ans[1, x, i]],
    print
fin.close()

