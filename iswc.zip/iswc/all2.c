#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define EXP_TABLE_SIZE 1000
#define MAX_EXP 6
#define MAX_STRING_LENGTH 1000

typedef double real;

int dim = 50, vocab_size = 10000, rel_num = 25, inst_num = 3192424, total_iter = 10;
real starting_alpha = 0.02;
real *vec, *rel, *prob, *expTable;
int *inst;

real norm(real* v, int d){
	int i;
	real ans = 0;
	for(i = 0; i < d; i++){
		ans += v[i] * v[i];
	}
	return ans;
}

void normalize(real* v, int d){
	int i = 0;
	unsigned long long next_random = 1;
	real n = norm(v, d);
	if(n == 0){
		for(i = 0; i < d; i++){
			next_random = next_random * (unsigned long long)25214903917 + 11;
			v[i] = (((next_random & 0xFFFF) / (real)65536) - 0.5) / d;
		}
		n = norm(v, d);
	}
	for(i = 0; i < d; i++){
		v[i] /= n;
	}
}

/*void loadvec(){
	int i, j, k, w;
	unsigned long long next_random = 1;
	FILE *fin = fopen("normvec3.txt", "r");
	fscanf(fin, "%d %d", &dim, &vocab_size);
	posix_memalign((void **)&vec, 128, vocab_size * dim * sizeof(real));
	posix_memalign((void **)&rel, 128, rel_num * dim * dim * sizeof(real));
	for(i = 0; i < vocab_size; i++){
		fscanf(fin, "%d", &w);
		for(j = 0; j < dim; j++){
			fscanf(fin, "%lf", &vec[w * dim + j]);
		}
		normalize(vec + w * dim, dim);
	}
	for(i = 0; i < rel_num; i++){
		for(j = 0; j < dim; j++){
			for(k = 0; k < dim; k++){
				next_random = next_random * (unsigned long long)25214903917 + 11;
				rel[i * dim * dim + j *dim +k] = (((next_random & 0xFFFF) / (real)65536) - 0.5) / dim;
			}
		}
		normalize(rel + i * dim * dim, dim * dim);
	}
	fclose(fin);

}*/
void initvec(){
    int i, j, k;
    unsigned long long next_random = 1;
    char w[MAX_STRING_LENGTH];
    FILE *fin = fopen("base_vec.txt", "r");
    posix_memalign((void **)&vec, 128, vocab_size * dim * sizeof(real));
	posix_memalign((void **)&rel, 128, rel_num * dim * dim * sizeof(real));
	for(i = 0; i < vocab_size; i++){
        fscanf(fin, "%s", w);
        for(j = 0; j < dim; j++){
			fscanf(fin, "%lf", &vec[i * dim + j]);
		}
		normalize(vec + i * dim, dim);
	}
	for(i = 0; i < rel_num; i++){
		for(j = 0; j < dim; j++){
			for(k = 0; k < dim; k++){
				next_random = next_random * (unsigned long long)25214903917 + 11;
				rel[i * dim * dim + j *dim +k] = (((next_random & 0xFFFF) / (real)65536) - 0.5) / dim;
			}
		}
		normalize(rel + i * dim * dim, dim * dim);
	}
	fclose(fin);
}


void loadinst(){
	int i;
	inst = (int*)malloc(3 * inst_num * sizeof(int));
	prob = (real*)malloc(inst_num * sizeof(real));
	FILE *fin = fopen("pair3", "r");
	for(i = 0; i < inst_num; i++){
		fscanf(fin, "%d %d %d %lf", &inst[i * 3], &inst[i * 3 + 1], &inst[i * 3 + 2], &prob[i]);
	}
}

inline void VM(real *v, real *m, real* ans) {
	long long a, b;
	for (a = 0; a < dim; a++){
		ans[a] = 0;
		for(b = 0; b < dim; b++){
			ans[a] += v[b] * m[b * dim + a];
		}
	}
}

inline void MV(real *v, real *m, real *ans) {
	long long a, b;
	for (a = 0; a < dim; a++){
		ans[a] = 0;
		for(b = 0; b < dim; b++){
			ans[a] += m[a*dim+b]*v[b];
		}
	}
}

void shuffle(int* idx, int n){
	int i, j, tmp;
	for(i = 0; i < n; i++){
		j = rand() % (n - i) + i;
		tmp = idx[j];
		idx[j] = idx[i];
		idx[i] = tmp;
	}
}

void test(){
    char fname[MAX_STRING_LENGTH];
    sprintf(fname, "common_test_%d_%d_%lf", total_iter, dim, starting_alpha);
	FILE *fout = fopen(fname, "w");
	fprintf(stderr, "evaluation\n");
	real *vm = (real*)malloc(dim*sizeof(real)), vmv;
	int i, k, tp = 0, fp = 0, tn = 0, fn =0, left, rn, right;
	for(i = 0; i < inst_num; i += 100){
		left = inst[3 * i];
		rn = inst[3 * i + 1];
		right = inst[3 * i + 2];
		if(prob[rn] < 0.3)
            continue;
		VM(vec + left * dim, rel + rn * dim * dim, vm);
		vmv = 0;
		for(k = 0; k < dim; k++){
			vmv += vm[k] * vec[right * dim + k];
		}
		if(vmv > 0)//to do cross validation to choose the threshold
			tp++;
		else
			fn++;
		fprintf(fout, "1 %d %lf\n", rn, vmv);
		vmv = 0;
		if(rand()%2 == 0){
			right = rand()%vocab_size;
			for(k = 0; k < dim; k++){
				vmv += vm[k] * vec[right * dim + k];
			}

		} else{
			left = rand()%vocab_size;
			VM(vec + left * dim, rel + rn * dim * dim, vm);
			for(k = 0; k < dim; k++){
				vmv += vm[k] * vec[right * dim + k];
			}
		}
		if(vmv < 0)
			tn++;
		else
			fp++;
		fprintf(fout, "0 %d %lf\n", rn, vmv);
	}
	fprintf(stderr, "tp %d, fp %d, tn %d, fn %d\n", tp, fp, tn, fn);
	free(vm);
}

/*void eval2(){
	int i, j, k, w;
	unsigned long long next_random = 1;
	FILE *fin = fopen("normvec3.txt", "r");
	fscanf(fin, "%d %d", &dim, &vocab_size);
	for(i = 0; i < vocab_size; i++){
		fscanf(fin, "%d", &w);
		for(j = 0; j < dim; j++){
			fscanf(fin, "%lf", &vec[w * dim + j]);
		}
		normalize(vec + w * dim, dim);
	}
	FILE *fout = fopen("kb_eval_w2v", "w");
	eval(fout);
	fclose(fout);
}*/

void validation(){
    char fname[MAX_STRING_LENGTH];
    sprintf(fname, "common_val_%d_%d_%lf", total_iter, dim, starting_alpha);
	FILE *fout = fopen(fname, "w");
	real *vm = (real*)malloc(dim*sizeof(real)), vmv;
	int i, k, left, rn, right;
	for(i = 1; i < inst_num; i += 100){
		left = inst[3 * i];
		rn = inst[3 * i + 1];
		right = inst[3 * i + 2];
		if(prob[rn] < 0.3)
            continue;
		VM(vec + left * dim, rel + rn * dim * dim, vm);
		vmv = 0;
		for(k = 0; k < dim; k++){
			vmv += vm[k] * vec[right * dim + k];
		}
		fprintf(fout, "1 %d %lf\n", rn, vmv);
		vmv = 0;
		if(rand()%2 == 0){
			right = rand()%vocab_size;
			for(k = 0; k < dim; k++){
				vmv += vm[k] * vec[right * dim + k];
			}

		} else{
			left = rand()%vocab_size;
			VM(vec + left * dim, rel + rn * dim * dim, vm);
			for(k = 0; k < dim; k++){
				vmv += vm[k] * vec[right * dim + k];
			}
		}
		fprintf(fout, "0 %d %lf\n", rn, vmv);
	}
	free(vm);
	fclose(fout);
}

void train(){
	int i, j, k, l, left_idx, rel_idx, right_idx, label, tmp, pair_count = 0, iter = total_iter;
	real *vm = (real*)malloc(dim*sizeof(real));
	real *mv = (real*)malloc(dim*sizeof(real));
	real vmv, g;
	real alpha = starting_alpha;
	int *idx = (int*)malloc(inst_num * sizeof(int));
	for(i = 0; i < inst_num; i++){
		idx[i] = i;
	}
	while(iter--){
		shuffle(idx, inst_num);
		for(i = 0; i < inst_num; i++){
			if(idx[i] % 100 == 0 || idx[i] % 100 == 1)
				continue;
			pair_count++;
			if(pair_count % 1000 == 0){
				alpha = starting_alpha * (1 - pair_count / (total_iter * inst_num + 1));
				if(alpha < starting_alpha * 0.0001)
					alpha = starting_alpha * 0.0001;
			}
			left_idx = inst[idx[i] * 3];
			rel_idx = inst[idx[i] * 3 + 1];
			right_idx = inst[idx[i] * 3 + 2];
			if(prob[rel_idx] < 0.3)
                continue;
			for(j = 0; j < 6; j++){
				if(j == 0){
					label = 1;
				}
				else{
					label = 0;
					tmp = rand()%2;
					if(tmp == 1){
						left_idx = rand() % vocab_size;
					}
					else{
						right_idx = rand() % vocab_size;
					}
				}
				VM(vec + left_idx * dim, rel + rel_idx * dim * dim, vm);
				MV(vec + right_idx * dim, rel + rel_idx * dim * dim, mv);
				vmv = 0;
				for(k = 0; k < dim; k++){
					vmv += vm[k] * vec[right_idx * dim + k];
				}
				if (vmv > MAX_EXP) g = (label - 1) * prob[idx[i]] * alpha;
				else if (vmv < -MAX_EXP) g = (label - 0) * prob[idx[i]] * alpha;
				else g = alpha * prob[idx[i]] * (label - expTable[(int)((vmv + MAX_EXP) * (EXP_TABLE_SIZE / MAX_EXP / 2))]);
				for(k = 0; k < dim; k++){
					for(l = 0; l < dim; l++){
						rel[rel_idx * dim *dim + k * dim + l] += g * vec[left_idx * dim + k] * vec[right_idx * dim + l];
					}
				}
				if(i % 100000 == 0)
					fprintf(stderr, "%dth %d vmv g %lf %lf\n", i, label, vmv, g);
				for(k = 0; k < dim; k++){
					vec[left_idx * dim + k] += g * mv[k];
				}
				for(k = 0; k < dim; k++){
					vec[right_idx * dim + k] += g * vm[k];
				}
				normalize(vec + left_idx * dim, dim);
				normalize(vec + right_idx * dim, dim);
			}
		}
	}
}

/*void save_params(){
	FILE* fvec = fopen("ckbvec3", "w");
	int i , j, k, base;
	for(i = 0; i < vocab_size; i++){
		for(j = 0; j < dim; j++){
			fprintf(fvec, "%lf ", vec[i * dim + j]);
		}
		fprintf(fvec, "\n");
	}
	fclose(fvec);
	FILE *fmat = fopen("ckbmat3", "w");
	for(i = 0; i < rel_num; i++){
		base = i * dim * dim;
		for(j = 0; j < dim; j++){
			for(k = 0; k < dim; k++){
				fprintf(fmat, "%lf ", rel[base + j * dim + k]);
			}
			fprintf(fmat, "\n");
		}
		fprintf(fmat, "\n");
	}
	fclose(fmat);
}*/

int ArgPos(char *str, int argc, char **argv) {
  int a;
  for (a = 1; a < argc; a++) if (!strcmp(str, argv[a])) {
    if (a == argc - 1) {
      printf("Argument missing for %s\n", str);
      exit(1);
    }
    return a;
  }
  return -1;
}


int main(int argc,char **argv){
	int i;
	if ((i = ArgPos((char *)"-size", argc, argv)) > 0) dim = atoi(argv[i + 1]);
    if ((i = ArgPos((char *)"-iter", argc, argv)) > 0) total_iter = atoi(argv[i + 1]);
	if ((i = ArgPos((char *)"-alpha", argc, argv)) > 0) starting_alpha = atof(argv[i + 1]);
	//FILE *fout1 = fopen("kb_fval1", "w");
	//FILE *fout2 = fopen("kb_fval2", "w");
	expTable = (real *)malloc((EXP_TABLE_SIZE + 1) * sizeof(real));
	for (i = 0; i < EXP_TABLE_SIZE; i++) {
		expTable[i] = exp((i / (real)EXP_TABLE_SIZE * 2 - 1) * MAX_EXP); // Precompute the exp() table
		expTable[i] = expTable[i] / (expTable[i] + 1);                   // Precompute f(x) = x / (x + 1)
	}
	srand(time(NULL));
	initvec();
	fprintf(stderr, "loaded vec successfully\n");
	loadinst();
	fprintf(stderr, "loaded inst successfully\n");
	train();
	validation();
	test();
	fprintf(stderr, "finished\n");
	//save_params();
	//eval2();
	return 0;
}



