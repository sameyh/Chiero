from __future__ import division
import numpy as np
fin = open('base_vec.txt', 'r')
part = fin.readline().strip().split()
dim = int(part[1])
cnt = 0
size = 10000
vec = np.zeros((size, dim))
dic = {}
for line in fin:
	part = line.strip().split()
	dic[cnt] = part[0]
	vec[cnt] = part[1:]
	cnt += 1
	if cnt >= size:
		break
fin.close()
ans = np.zeros(size)
dis = np.zeros(size)
for i in xrange(size):
	dis[i] = np.inf
	for j in xrange(size):
		if i == j:
			continue
		tmp = np.linalg.norm(vec[i, :] - vec[j, :])
		if dis[i] > tmp:
			dis[i] = tmp
			ans[i] = j
mdis = np.max(dis)
fout = open('nn_pair', 'w')
for i in xrange(size):
	h = dic[i]
	t = dic[ans[i]]
	p = 1 - dis[i] / mdis
	fout.write('%s %s %f\n' %(h, t, p))
fout.close()