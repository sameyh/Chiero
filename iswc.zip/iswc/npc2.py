fin = open('base_vec_d_50.txt', 'r')
part = fin.readline().strip().split()
dim = int(part[1])
size = 600000
dic = {}
cnt = 0
for line in fin:
    part = line.strip().split()
    dic[part[0]] = cnt
    cnt += 1
fin.close()

fin = open('aaai11.cleaner.categorized.txt', 'r')
fout = open('pair_cleaner', 'w')
rel = {}
cnt = 0
for line in fin:
    part = line.strip().split('\t')
    if part[0] not in dic or part[2] not in dic:
        continue
    if part[1] not in rel:
        rel[part[1]] = cnt
        cnt += 1
    h = dic[part[0]]
    r = rel[part[1]]
    t = dic[part[2]]
    f = float(part[3])
    fout.write('%d %d %d %f\n' %(h, r, t, f))
fin.close()
fout.close()

print cnt
