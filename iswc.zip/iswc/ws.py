import numpy as np
cnt = 0
dic = {}
fin = open('base_vec_d_50_1.txt', 'r')
part = fin.readline().strip().split()
dim = int(part[1])
vocab_size = int(part[0])
vec1 = np.zeros((vocab_size, dim))
vec2 = np.zeros((vocab_size, dim))
for line in fin:
    part = line.strip().split()
    dic[part[0]] = cnt
    vec1[cnt, :] = part[1:]
    cnt += 1
fin.close()

fin = open('vec50_0.002.txt', 'r')
fin.readline()
cnt = 0
for line in fin:
    part = line.strip().split()
    vec2[cnt, :] = part[1:]
    cnt += 1
fin.close()

def cosi(idx1, idx2, vec):
    ans = np.inner(vec[idx1, :], vec[idx2, :])
    ans /= np.linalg.norm(vec[idx1, :])
    ans /= np.linalg.norm(vec[idx2, :])
    return ans
fin = open('wordsim353_agreed.txt', 'r')
for i in xrange(11):
    fin.readline()
for line in fin:
    part = line.strip().split('\t')
    idx1 = dic[part[1]]
    idx2 = dic[part[2]]
    print float(part[3]), cosi(idx1, idx2, vec1), cosi(idx1, idx2, vec2)

