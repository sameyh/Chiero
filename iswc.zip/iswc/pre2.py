files = ['verb', 'noun', 'adj', 'adv']
fout = open('pair', 'w')
for fname in files:
    fin = open(fname, 'r')
    for line in fin:
        part = line.strip().split()
        num = len(part)
        if num == 1:
            continue
        for i in xrange(num):
            for j in xrange(i + 1, num):
                fout.write('%s %s\n' %(part[i], part[j]))
    fin.close()
fout.close()

