fin = open('base_vec_d_50.txt', 'r')
fin.readline()
dic = {}
cnt = 0
for line in fin:
	part = line.strip().split()
	dic[part[0]] = cnt
	cnt += 1
fin.close()
fin = open('rel', 'r')
rel = {}
for line in fin:
	part = line.strip().split('\t')
	rel[part[0]] = int(part[1])
fin.close()

fin = open('aaai11_sr_gold.txt', 'r')
for line in fin:
	part = line.strip().split('\t')
	if part[0] not in dic or part[2] not in dic or part[1] not in rel:
		continue
	print dic[part[0]], rel[part[1]], dic[part[2]]

