comcorp = open('spo_conf', 'r')
wodcorp = open('pair', 'r')
veccorp = open('base_vec.txt', 'r')
alcorp = open('alcorp', 'w')
wdic = {}
rdic = {}
wcnt = 0
rcnt = 0
for line in comcorp:
    h = 0
    r = 0
    l = 0
    part = line.strip().split('\t')
    part[0] = part[0].replace(' ', '_ ')
    part[2] = part[2].replace(' ', '_')
    if part[0] not in wdic:
        wdic[part[0]] = wcnt
        wcnt += 1
    h = wdic[part[0]]
    if part[2] not in wdic:
        wdic[part[2]] = wcnt
        wcnt += 1
    l = wdic[part[2]]
    if part[1] not in rdic:
        rdic[part[1]] = rcnt
        rcnt += 1
    r = rdic[part[1]]
    alcorp.write('%d %d %d %f\n' %(h, r, l, float(part[3])))
comcorp.close()

r = rcnt
p = 1.0
for line in wodcorp:
    part = line.strip().split()
    if part[0] not in wdic:
        wdic[part[0]] = wcnt
        wcnt += 1
    h = wdic[part[0]]
    if part[1] not in wdic:
        wdic[part[1]] = wcnt
        wcnt += 1
    l = wdic[part[1]]
    alcorp.write('%d %d %d %f\n' %(h, r, l, p))
rcnt += 1
wodcorp.close()
alcorp.close()
print rcnt, wcnt

inivec = open('inivec', 'w')
veccorp.readline()
cnt = 0
size = 10000
for line in veccorp:
    cnt += 1
    part = line.strip().split()
    if part[0] in wdic:
        inivec.write('%s' %line)
    if cnt >= size:
        break
inivec.close()

