#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define MAX_STRING_LENGTH 1000
typedef double real;
int dim = 50, vocab_size, rel_num = 24, inst_num = 1158141, total_iter = 500, margin = 1;
real starting_alpha = 0.001, alpha;
real *vec, *rel;
int *inst;
FILE *logfile;

real norm(real* v, int d){
	int i;
	real ans = 0;
	for(i = 0; i < d; i++){
		ans += v[i] * v[i];
	}
	return ans;
}

void normalize(real* v, int d){
	int i = 0;
	unsigned long long next_random = 1;
	real n = norm(v, d);
	if(n == 0){
		for(i = 0; i < d; i++){
			next_random = next_random * (unsigned long long)25214903917 + 11;
			v[i] = (((next_random & 0xFFFF) / (real)65536) - 0.5) / d;
		}
		n = norm(v, d);
	}
	for(i = 0; i < d; i++){
		v[i] /= n;
	}
}

void loadvec(){
	int i, j, k;
	unsigned long long next_random = 1;
	char w[MAX_STRING_LENGTH];
    sprintf(w, "base_vec_d_%d.txt", dim);
    FILE *fin = fopen(w, "r");
	fscanf(fin, "%d %d", &vocab_size, &dim);
	posix_memalign((void **)&vec, 128, vocab_size * dim * sizeof(real));
	posix_memalign((void **)&rel, 128, rel_num * dim * sizeof(real));
	for(i = 0; i < vocab_size; i++){
		fscanf(fin, "%s", &w);
		for(j = 0; j < dim; j++){
			fscanf(fin, "%lf", &vec[i * dim + j]);
		}
		normalize(vec + i * dim, dim);
	}
	fprintf(logfile, "in load vec\n");
	for(i = 0; i < rel_num; i++){
		for(j = 0; j < dim; j++){
			next_random = next_random * (unsigned long long)25214903917 + 11;
			rel[i * dim + j] = (((next_random & 0xFFFF) / (real)65536) - 0.5) / dim;
		}
		normalize(rel + i * dim, dim);
	}
	fclose(fin);
}


void loadinst(){
	int i;
	inst = (int*)malloc(3 * inst_num * sizeof(int));
	FILE *fin = fopen("pair11", "r");
	for(i = 0; i < inst_num; i++){
		fscanf(fin, "%d %d %d", &inst[i * 3], &inst[i * 3 + 1], &inst[i * 3 + 2]);
	}
}


void shuffle(int* idx, int n){
	int i, j, tmp;
	for(i = 0; i < n; i++){
		j = rand() % (n - i) + i;
		tmp = idx[j];
		idx[j] = idx[i];
		idx[i] = tmp;
	}
}

real cal_sum(int h, int r, int l){
	int i;
	real sum = 0;
	for(i = 0; i < dim; i++){
		sum += fabs(vec[h*dim+i] + rel[r*dim+i] - vec[l*dim+i]);
	}
	return sum;
}

inline void gradient(int ha, int ra, int la, int hb, int rb, int lb){
	int i;
	real tmp;
	for(i = 0; i < dim; i++){
		tmp = vec[dim*ha+i] + rel[dim*ra+i] - vec[dim*la+i];
		if(tmp > 0)
			tmp = 1;
		else
			tmp = -1;
		rel[dim*ra+i] -= alpha * tmp;
		vec[dim*ha+i] -= alpha * tmp;
		vec[dim*la+i] += alpha * tmp;
		tmp = vec[dim*hb+i] + rel[dim*rb+i] - vec[dim*lb+i];
		if(tmp > 0)
			tmp = 1;
		else
			tmp = -1;
		rel[dim*rb+i] += alpha * tmp;
		vec[dim*hb+i] += alpha * tmp;
		vec[dim*lb+i] -= alpha * tmp;
	}
}


void train(){
	real loss = 0, tmp;
	int ha, ra, la, hb, rb, lb, lr;
	int i, pair_count = 0, iter = 0;
	int *idx = (int*)malloc(inst_num * sizeof(int));
	for(i = 0; i < inst_num; i++){
		idx[i] = i;
	}
	alpha = starting_alpha;
	while(iter++ < total_iter){
		fprintf(logfile, "iter %d ", iter);
		loss = 0;
		shuffle(idx, inst_num);
		for(i = 0; i < inst_num; i++){
			if(idx[i] % 10 == 0 || idx[i] % 10 == 1)
				continue;
			pair_count++;
			if(pair_count % 1000 == 0){
				alpha = starting_alpha * (1 - pair_count / (total_iter * inst_num + 1));
				if(alpha < starting_alpha * 0.0001)
					alpha = starting_alpha * 0.0001;
			}
			ha = inst[idx[i] * 3];
			ra = inst[idx[i] * 3 + 1];
			la = inst[idx[i] * 3 + 2];
			hb = ha;
			rb = ra;
			lb = la;
			lr = rand()%2;
			if(lr == 1){
				hb = rand() % vocab_size;
			} else{
				lb = rand() % vocab_size;
			}
			tmp = cal_sum(ha, ra, la) + margin - cal_sum(hb, rb, lb);
			if(tmp > 0){
				loss += tmp;
				gradient(ha, ra, la, hb, rb, lb);
			}
			normalize(vec + ha * dim, dim);
			normalize(vec + la * dim, dim);
			normalize(rel + ra * dim, dim);
			if(lr == 1)
				normalize(vec + hb * dim, dim);
			else
				normalize(vec + lb * dim, dim);
		}
		fprintf(logfile, "loss: %lf\n", iter, loss);
	}
}

void validation(){
    char fname[MAX_STRING_LENGTH];
    sprintf(fname, "transe_val_dim_%d_iter_%d_alpha_%lf", dim, total_iter, starting_alpha);
	FILE *fout = fopen(fname, "w");
	fprintf(logfile, "validation\n");
	int i, h, r, l;
	real score;
	for(i = 1; i < inst_num; i += 10){
		h = inst[3 * i];
		r = inst[3 * i + 1];
		l = inst[3 * i + 2];
		score = cal_sum(h, r, l);
		fprintf(fout, "1 %d %d %d %lf\n", h, r, l, score);
		if(rand()%2 == 0){
			h = rand()% vocab_size;
		} else{
			l = rand()% vocab_size;
		}
		score = cal_sum(h, r, l);
		fprintf(fout, "0 %d %d %d %lf\n", h, r, l, score);
	}
	fclose(fout);
}


void test(){
    char fname[MAX_STRING_LENGTH];
    sprintf(fname, "transe_test_dim_%d_iter_%d_alpha_%lf", dim, total_iter, starting_alpha);
	FILE *fout = fopen(fname, "w");
	fprintf(logfile, "testing...\n");
	int i, h, r, l;
	real score;
	for(i = 0; i < inst_num; i += 10){
		h = inst[3 * i];
		r = inst[3 * i + 1];
		l = inst[3 * i + 2];
		score = cal_sum(h, r, l);
		fprintf(fout, "1 %d %d %d %lf\n", h, r, l, score);
		if(rand()%2 == 0){
			h = rand()% vocab_size;
		} else{
			l = rand()% vocab_size;
		}
		score = cal_sum(h, r, l);
		fprintf(fout, "0 %d %d %d %lf\n", h, r, l, score);
	}
	fclose(fout);
}

void goldtest(){
    char fname[MAX_STRING_LENGTH];
    sprintf(fname, "gold_transe_test_%d_%d_%lf", total_iter, dim, starting_alpha);
	FILE *fin = fopen("gold_eval", "r"), *fout = fopen(fname, "w");
	fprintf(logfile, "evaluation\n");
	real score;
	int h, r, l;
	fprintf(logfile, "testing gold...\n");
	while(!feof(fin)){
        fscanf(fin, "%d %d %d", &h, &r, &l);
        score = cal_sum(h, r, l);
		fprintf(fout, "1 %d %d %d %lf\n", h, r, l, score);
		if(rand()%2 == 0){
			h = rand()% vocab_size;
		} else{
			l = rand()% vocab_size;
		}
		score = cal_sum(h, r, l);
		fprintf(fout, "0 %d %d %d %lf\n", h, r, l, score);
	}
	fprintf(logfile, "finished\n");
	fclose(fout);
}
int ArgPos(char *str, int argc, char **argv) {
  int a;
  for (a = 1; a < argc; a++) if (!strcmp(str, argv[a])) {
    if (a == argc - 1) {
      printf("Argument missing for %s\n", str);
      exit(1);
    }
    return a;
  }
  return -1;
}

int main(int argc, char **argv){
    int i;
	if ((i = ArgPos((char *)"-size", argc, argv)) > 0) dim = atoi(argv[i + 1]);
    if ((i = ArgPos((char *)"-iter", argc, argv)) > 0) total_iter = atoi(argv[i + 1]);
	if ((i = ArgPos((char *)"-alpha", argc, argv)) > 0) starting_alpha = atof(argv[i + 1]);
	char flogname[MAX_STRING_LENGTH];
	sprintf(flogname, "log_dim_%d_iter_%d_alpha_%lf", dim, total_iter, starting_alpha);
	logfile = fopen(flogname, "w");
	loadvec();
	fprintf(logfile, "load vec success\n");
	loadinst();
	fprintf(logfile, "load inst success\n");
	train();
	validation();
	test();
	goldtest();
	fprintf(logfile, "finished\n");
	return 0;
}
