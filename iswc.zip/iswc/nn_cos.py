from __future__ import division
import numpy as np
fin = open('base_vec_d_50.txt', 'r')
part = fin.readline().strip().split()
dim = int(part[1])
cnt = 0
size = 10000
vec = np.zeros((size, dim))
dic = {}
for line in fin:
	part = line.strip().split()
	dic[cnt] = part[0]
	vec[cnt] = part[1:]
	cnt += 1
	if cnt >= size:
		break
fin.close()
k = 5
ans = np.zeros((size, k))
dis = -np.ones((size, k))
for i in xrange(size):
	if i % 100 == 0:
		print i,
	for j in xrange(size):
		if i == j:
			continue
		tmp = np.inner(vec[i, :], vec[j, :])
		tmp /= np.linalg.norm(vec[i, :])
		tmp /= np.linalg.norm(vec[j, :])
		if min(dis[i, :]) < tmp:
			idx = dis[i, :].argmin()
			dis[i, idx] = tmp
			ans[i, idx] = j

fout = open('nn_cos_pair', 'w')
for i in xrange(size):
	for j in xrange(k):
		h = dic[i]
		t = dic[ans[i, j]]
		p = dis[i, j]
		fout.write('%s %s %f\n' %(h, t, p))
fout.close()
print '\nfinished'
