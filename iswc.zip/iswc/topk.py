from __future__ import division
import numpy as np

fin = open('vec50_0.002.txt', 'r')
part = fin.readline().split()
vocab_size = int(part[0])
dim = int(part[1])
dic = {}
rdic = {}
cnt = 0
vec = np.zeros((vocab_size, dim))
for line in fin:
    part = line.strip().split()
    dic[part[0]] = cnt
    rdic[cnt] = part[0]
    vec[cnt] = part[1:]
    cnt += 1
fin.close()

fin = open('rel2', 'r')
rel = {}
rrel = {}
for line in fin:
    part = line.strip().split('\t')
    rel[part[0]] = int(part[1])
    rrel[int(part[1])] = part[0]
fin.close()

rel_num = 25
mat = np.zeros((rel_num, dim, dim))
fin = open('joint_mat_dim_50_iter_45_alpha_0.002000', 'r')
rel_cnt = 0
cnt = 0
for line in fin:
    if line == '\n':
        continue
    part = line.strip().split()
    mat[rel_cnt, cnt] = part
    cnt += 1
    if cnt >= dim:
        cnt = 0
        rel_cnt += 1

fin.close()

def sigmoid(x):
    return 1 / (1 + np.exp(-x))
while True:
    choose = raw_input('continue:y or n?\n')
    if choose == 'n':
        break
    t = 0
    w1 = raw_input('left word:\n')
    if w1 == '':
        t = 1
    elif w1 not in dic:
        print 'error not in dictionary'
        continue

    r = raw_input('relation type:\n')
    if r == '' and t == 0:
        t = 1
    elif r not in rel:
        print 'error type not exists'
        continue
    w2 = raw_input('right word:\n')
    if w2 == '' and t == 0:
        t = 1
    elif w2 not in dic:
        print 'error: not in dictionary'
        continue
    if t == 0:
        w1_idx = dic[w1]
        w2_idx = dic[w2]
        r_idx = rel[r]
        tmp = np.dot(vec[w1_idx], mat[r_idx])
        score = np.inner(tmp, vec[w2_idx])
        print score#sigmoid(score)
    else:
        k = int(raw_input('k:\n'))
        if w1 == '':
            tmp = np.dot(mat[rel[r]], vec[dic[w2]])
            scores = [(i, np.inner(vec[i], tmp)) for i in xrange(vocab_size)]
            scores = sorted(scores, key = lambda x: x[1], reverse = True)
            for i in xrange(k):
                print rdic[scores[i][0]], scores[i][1]#sigmoid(scores[i][1])
        if w2 == '':
            tmp = np.dot(vec[dic[w1]], mat[rel[r]])
            scores = [(i, np.inner(tmp, vec[i])) for i in xrange(vocab_size)]
            scores = sorted(scores, key = lambda x: x[1], reverse = True)
            for i in xrange(k):
                print rdic[scores[i][0]], scores[i][1]#sigmoid(scores[i][1])
        if r == '':
            if k >= rel_num:
                print 'error: k too big'
                continue
            w1_idx = dic[w1]
            w2_idx = dic[w2]
            scores = [(i, np.inner(np.dot(vec[w1_idx], mat[i]), vec[w2_idx])) for i in xrange(rel_num)]
            scores = sorted(scores, key = lambda x: x[1], reverse = True)
            for i in xrange(k):
                print rrel[scores[i][0]], scores[i][1]#sigmoid(scores[i][1])
