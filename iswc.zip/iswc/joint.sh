for a in 0.0001 0.0002 0.0005 0.002
do
    ./joint_cleaner -train ~/nlp/cjq/data.txt -output vec50_cleaner_$a.txt -size 50 -rel-alpha $a -sample 1e-4 -negative 5 -hs 0 -binary 0 -cbow 1 -iter 3 -min-count 100 -read-vocab vocab.txt
done
