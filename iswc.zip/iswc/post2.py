from __future__ import division
import numpy as np

dic = {}
fin = open('words2', 'r')
for line in fin:
	part = line.strip().split()
	dic[part[0]] = int(part[1])
fin.close()
vocab_size = 295093
dim = 50
vec1 = np.zeros((vocab_size, dim))
vec2 = np.zeros((vocab_size, dim))
cnt = 0
fin = open('base_vec_d_50_1.txt', 'r')
fin.readline()
for line in fin:
	part = line.strip().split()
	vec1[cnt, :] = part[1:]
	cnt += 1
fin.close()

cnt = 0
fin = open('vec50_1.txt', 'r')
fin.readline()
for line in fin:
	part = line.strip().split()
	vec2[cnt, :] = part[1:]
	cnt += 1
fin.close()

def calsim(a, b, vec):
	ans = np.inner(vec[a, :], vec[b, :])
	ans /= np.linalg.norm(vec[a, :])
	ans /= np.linalg.norm(vec[b, :])
	return ans
fin = open('cosine_wTax_pf5_long.dat', 'r')
fin.readline()
fout = open('concept_similarity2', 'w')
cnt = 0
for line in fin:
	part = line.strip().split()
	if part[0] not in dic or part[1] not in dic:
		continue
	if float(part[2]) < 0.5:
		break
	cnt += 1
	w1 = dic[part[0]]
	w2 = dic[part[1]]
	sim1 = calsim(w1, w2, vec1)
	sim2 = calsim(w1, w2, vec2)
	fout.write('%s\t%s\t%f\t%f\t%f\n'%(part[0], part[1], float(part[2]), sim1, sim2))
fout.close()
fin.close()
print 'finished total pair', cnt

