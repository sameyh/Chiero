fin = open('base_vec.txt', 'r')
part = fin.readline().strip().split()
dim = int(part[1])
size = 10000
dic = {}
cnt = 0
for line in fin:
	part = line.strip().split()
	dic[part[0]] = cnt
	cnt += 1
	if  cnt >= size:
		break
fin.close()
fin = open('spo_conf', 'r')
fout = open('pair3', 'w')
rel = {}
cnt = 0
ent_cnt = 0
for line in fin:
	part = line.strip().split('\t')
	if part[0] not in dic or part[2] not in dic:
		continue
	if part[1] not in rel:
		rel[part[1]] = cnt
		cnt += 1
	h = dic[part[0]]
	r = rel[part[1]]
	t = dic[part[2]]
	fout.write('%d %d %d %f\n' %(h, r, t, float(part[3])))
	ent_cnt += 1
fin.close()
print 'ext', ent_cnt

rel['similarAs'] = cnt
r = cnt
cnt += 1
p = 1.0
fin = open('pair', 'r')
ent_cnt = 0
for line in fin:
	part = line.strip().split()
	if part[0] not in dic or part[1] not in dic:
		continue
	h = dic[part[0]]
	t = dic[part[1]]
	fout.write('%d %d %d %f\n' %(h, r, t, p))
	ent_cnt += 1
fin.close()
print 'WD', ent_cnt

fin = open('nn_pair', 'r')
rel['nearestNeighbor'] = cnt
r = cnt
cnt += 1
ent_cnt = 0
for line in fin:
	part = line.strip().split()
	h = dic[part[0]]
	t = dic[part[1]]
	fout.write('%d %d %d %f\n' %(h, r, t, float(part[2])))
	ent_cnt += 1
fout.close()
print 'Vec', ent_cnt

print 'rel num', cnt
frel = open('rel', 'w')
for k, v in rel.items():
	frel.write('%s\t%d\n' %(k, v))
frel.close()
print 'finished'
