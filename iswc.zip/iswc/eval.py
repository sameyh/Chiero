from __future__ import division
import numpy as np
fin = open('vec_dim_50_iter_40_alpha_0.020000', 'r')
vocab_size = 295093
dim = 50
vec = np.zeros((vocab_size, dim))
cnt = 0
for line in fin:
	vec[cnt, :] = line.strip().split()
	cnt += 1
fin.close()
mat = np.zeros((25, dim, dim))
fin = open('mat_dim_50_iter_40_alpha_0.020000', 'r')
cnt1 = 0
cnt2 = 0
for line in fin:
	if line == '\n':
		continue
	mat[cnt1, cnt2, :] = line.strip().split()
	cnt2 += 1
	if cnt2 >= 49:
		cnt1 += 1
		cnt2 = 0
	if cnt1 > 24:
		break
fin.close()
tp = 0
fp = 0
tn = 0
fn = 0
fin = open('gold', 'r')
for line in fin:
	part = line.strip().split()
	h = int(part[0])
	r = int(part[1])
	t = int(part[2])
	tmp = np.dot(vec[h, :], mat[r])
	s = np.inner(tmp, vec[t, :])
	print 1, s
	if s > 0:
		tp += 1
	else:
		fp += 1
	idx = np.random.randint(2)
	if idx == 1:
		h = np.random.randint(vocab_size)
	else:
		t = np.random.randint(vocab_size)
	tmp = np.dot(vec[h, :], mat[r])
	s = np.inner(tmp, vec[t, :])
	if s < 0:
		tn += 1
	else:
		fn += 1
	print 0, s
fin.close()
accuracy = 0.5 * (tp + tn) / (tp + fp)
print tp, fp, tn, fn
print 'rough accuracy', accuracy
