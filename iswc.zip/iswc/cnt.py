from collections import defaultdict
fin = open('aaai11_sr_union.txt')
rel = defaultdict(int)
for line in fin:
    part = line.strip().split()
    rel[part[1]] += 1
for k, v in rel.items():
    print k, v
