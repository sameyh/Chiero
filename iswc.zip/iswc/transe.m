A = importdata('transe_val_dim_50_iter_500_alpha_0.001000');
figure
hold on
for i = 1:2000
    if mod(i, 2) == 1
        plot((i+1)/2, A(i,5),'bo','MarkerSize',2.5);
    else
        plot(i/2, A(i,5),'rd','MarkerSize',2.5);
    end
end
legend('pos', 'neg');
xlabel('TransE model');
hold off
tp = 0;
fp = 0;
tn = 0;
fn = 0;
res = zeros(100,1);
for th = 1:100
    tp = 0;
    tn = 0;
    fp = 0;
    fn = 0;
for i = 1:2:40524
    if A(i,5) < th
        tp = tp + 1;
    else
        fn = fn + 1;
    end
end
for i = 2:2:40524
    if A(i,5) < th
        fp = fp + 1;
    else
        tn = tn + 1;
    end
end
res(th,1) = (tp+tn)/40524;
end
figure
plot(res);