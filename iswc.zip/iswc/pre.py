import os
files = os.listdir(os.getcwd())
for name in files:
    if name.startswith('data.'):
        fin = open(name, 'r')
        for x in xrange(29):
            fin.readline()
        fout = open(name[5:], 'w')
        for line in fin:
            part = line.strip().split()
            n = int(part[3], 16)
            for i in xrange(n):
                fout.write('%s '%part[4+2*i])
            fout.write('\n')
        fin.close()
        fout.close()


