for i in 5 10 20 40
do
    for a in 0.001 0.01 0.02 0.04
    do
        for d in 30 50 100
        do
            ./all -iter $i -alpha $a -size $d &
        done
    done
done

