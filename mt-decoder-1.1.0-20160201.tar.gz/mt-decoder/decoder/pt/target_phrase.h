#pragma once

#include <vector>

#include "util/types.h"
#include "lm/vocab.h"

namespace herbal {

    class SourceRange;
    
    template <typename T>
    class SomePiece {
      public:
        typedef T value_type;

        SomePiece(){}
        SomePiece(const T* data, size_t size) : data_(data), size_(size) {}

        const T& operator[](size_t i) const {
          return data_[i];
        }

        const T* data() const {
          return data_;
        }

        size_t size() const {
          return size_;
        }

        const T* begin() const {
          return data_;
        }

        const T* end() const {
          return data_ + size_;
        }

      protected:
        const T* data_;
        size_t size_;
    };

    class PhrasePiece : public SomePiece<lm::Word> {
      public:
        PhrasePiece() {}
        PhrasePiece(const lm::Word* data, size_t size) : SomePiece(data, size) {}
    };

    class ScorePiece : public SomePiece<float> {
      public:
        ScorePiece() {}
        ScorePiece(const float* data, size_t size) : SomePiece(data, size) {}
    };

    struct Alignment {
      Byte i;
      Byte j;
    };

    class AlignmentPiece : public SomePiece<Alignment> {
      public:
        AlignmentPiece() {}
        AlignmentPiece(const Alignment* data, size_t size) : SomePiece(data, size) {}
    };

    class TargetPhrase {
      public:
        TargetPhrase() : range_(0) {}

        TargetPhrase(PhrasePiece pp, ScorePiece sp, AlignmentPiece ap)
        : pp_(pp), sp_(sp), ap_(ap), range_(0) {}

        void Set(PhrasePiece pp, ScorePiece sp, AlignmentPiece ap) {
          pp_ = pp;
          sp_ = sp;
          ap_ = ap;
        }

        const PhrasePiece& GetPhrase() const {
          return pp_;
        }

        const ScorePiece& GetScores() const {
          return sp_;
        }

        const AlignmentPiece& GetAlignment() const {
          return ap_;
        }

        template <class OStream>
        friend OStream& operator<<(OStream& o, const TargetPhrase& tp) {
          for(auto& t : tp.GetPhrase())
            o << t << " ";
          o << "||| ";
          for(auto& s : tp.GetScores())
            o << s << " ";
          o << "||| ";
          for(auto& a : tp.GetAlignment())
            o << (uint32_t)a.i << "-" << (uint32_t)a.j << " ";

          return o;
        }

        void SetRange(const SourceRange* range) {
          range_ = range;
        }

        const SourceRange* GetRange() const {
          return range_;
        }

        float GetSortScore() const {
          return sp_[0];
        }
        
      private:
        PhrasePiece pp_;
        ScorePiece sp_;
        AlignmentPiece ap_;
        const SourceRange* range_;
    };

    class TargetPhraseVocab {
      public:
        TargetPhraseVocab(const TargetPhrase& tp, const lm::FromWordVocab& vocab)
        : tp_(tp), vocab_(vocab) {}

        template <class OStream>
        friend OStream& operator<<(OStream& o, const TargetPhraseVocab& tp) {
          for(auto& t : tp.tp_.GetPhrase())
            o << tp.vocab_[t] << " ";
          o << "||| ";
          for(auto& s : tp.tp_.GetScores())
            o << s << " ";
          o << "||| ";
          for(auto& a : tp.tp_.GetAlignment())
            o << (uint32_t)a.i << "-" << (uint32_t)a.j << " ";

          return o;
        }

      private:
        const TargetPhrase& tp_;
        const lm::FromWordVocab& vocab_;
    };

    class TargetPhraseDecoder : public SomePiece<Byte> {
      public:
        TargetPhraseDecoder(const Byte* data, size_t size)
        : SomePiece(data, size), pos_(0), done_(false) {}

        TargetPhraseDecoder& operator>>(TargetPhrase& tp) {

          if(not done_) {
            size_t size = (*this)[pos_];
            pos_++;
            PhrasePiece pp((PhrasePiece::value_type*)(data_ + pos_), size);
            pos_ += pp.size() * sizeof(PhrasePiece::value_type);

            ScorePiece sp((ScorePiece::value_type*)(data_ + pos_), 2);
            pos_ += sp.size() * sizeof(ScorePiece::value_type);

            size = (*this)[pos_];
            pos_++;
            AlignmentPiece ap((AlignmentPiece::value_type*)(data_ + pos_), size);
            pos_ += ap.size() * sizeof(AlignmentPiece::value_type);

            tp.Set(pp, sp, ap);
          }

          return *this;
        }

        operator bool() {
            bool predone = done_;
            done_ = pos_ >= size();
            return !predone;
        }

      private:
        size_t pos_;
        bool done_;
    };

    typedef TargetPhrase* TargetPhrasePtr;
    typedef std::vector<TargetPhrasePtr> TargetPhrases;
    
}
