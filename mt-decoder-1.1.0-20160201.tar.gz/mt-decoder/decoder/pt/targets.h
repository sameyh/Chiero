#pragma once

#include <algorithm>
#include <vector>
#include <cstring>

#include "dec/god.h"
#include "util/blob.h"
#include "util/exception.h"
#include "util/string_piece.h"
#include "pt/byte_map.h"
#include "pt/target_phrase.h"

namespace herbal {

class Targets : public util::Blobbed {
  public:
    TargetPhrases operator()(uint64_t pos) {
      try {
        return DecodeBytes(byteMap_[pos]);  
      }
      catch(util::Exception& e) {
        return TargetPhrases();
      }
    }

  private:
    TargetPhrases DecodeBytes(const util::ManyChunksC8 bytes) {
      TargetPhrases tps;
      TargetPhraseDecoder tpd(bytes.data(), bytes.size());
      TargetPhrase* tp = God::Create<TargetPhrase>();
      while(tpd >> *tp) {
        tps.push_back(tp);
        tp = God::Create<TargetPhrase>();
      }
      return tps;
    }

    void MapBlob(util::Blob& blob) {
      blob
        >> byteMap_;
    }

    ByteMap byteMap_;
};

}
