#pragma once

#include <algorithm>

#include "util/blob.h"
#include "util/exception.h"

namespace herbal {

template <class Collection>
class FakeIterator {
  public:
    FakeIterator(const Collection& c)
    : pos_(0), coll_(c)
    { }

    FakeIterator(const Collection& c, size_t pos)
    : pos_(pos), coll_(c)
    { }

    FakeIterator& operator++() {
      if(pos_ < coll_.size())
        pos_++;
      return *this;
    }

    bool operator==(const FakeIterator& si) const {
      return pos_ == si.pos_;
    }

    bool operator!=(const FakeIterator& si) const {
      return pos_ != si.pos_;
    }

    typename Collection::value_type& operator*() {
      value_ = coll_[pos_];
      return value_;
    }

  private:
    size_t pos_;
    const Collection& coll_;
    typename Collection::value_type value_;
};

class ByteMap : public util::Blobbed {
  public:
    typedef util::ManyChunksC8 value_type;
    typedef FakeIterator<ByteMap> iterator;

    value_type operator[](uint64_t pos) const {
      THROW_IF(pos >= mapSize_, "Out of range!");

      uint64_t startByte = byteMap_[pos];
      uint64_t endByte = byteSize_;
      if(pos + 1 < mapSize_)
        endByte = byteMap_[pos + 1];

      return value_type(bytes_.data() + startByte, endByte - startByte);
    }

    iterator begin() const {
      return iterator(*this);
    }

    iterator end() const {
      return iterator(*this, mapSize_);
    }

    size_t size() const {
      return mapSize_;
    }

    size_t Size() const {
      return mapSize_;
    }

  private:
    void MapBlob(util::Blob& blob) {
      blob
        >> mapSize_
        >> byteSize_;

      blob
        >> byteMap_(mapSize_)
        >> bytes_(byteSize_);
    }

    util::ChunkC64 mapSize_;
    util::ChunkC64 byteSize_;
    util::ManyChunksC64 byteMap_;
    value_type bytes_;
};

}
