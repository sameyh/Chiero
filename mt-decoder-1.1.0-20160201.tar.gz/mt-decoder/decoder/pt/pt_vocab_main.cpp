#include <string>
#include <iostream>
#include <ios>
#include <vector>
#include <boost/program_options.hpp>

#include "lm/vocab.h"
#include "util/string_piece.h"
#include "util/string_piece_split.h"
#include "hash/chd_builder.h"


int main(int argc, char** argv) {
  namespace po = boost::program_options;
  po::options_description cmdline_options("Allowed options");

  bool help = false;
  bool binary = false;

  cmdline_options.add_options()
    ("binary,b", po::value(&binary)->zero_tokens()->default_value(false),
     "Create and dump binary vocab file")
    ("help,h", po::value(&help)->zero_tokens()->default_value(false),
     "Print this help message and exit")
  ;

  po::variables_map vm;
  try {
    po::store(po::command_line_parser(argc,argv).
              options(cmdline_options).run(), vm);
    po::notify(vm);
  }
  catch (std::exception& e) {
    std::cout << "Error: " << e.what() << std::endl << std::endl;

    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }

  if (help) {
    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }

  std::ios_base::sync_with_stdio(false);
  size_t count = 0;
  std::string line;

  herbal::lm::GrowVocab vocab;

  while(std::getline(std::cin, line)) {
    herbal::util::StringPiece s(line.data(), line.length());
    std::vector<herbal::util::StringPiece> fields;
    herbal::util::split(fields, s, " ||| ");

    herbal::util::StringPiece source = fields[0];
    herbal::util::StringPiece target = fields[1];

    std::vector<herbal::util::StringPiece> srcTokens;
    split(srcTokens, source, " ");
    for(auto& s : srcTokens)
      vocab[s];

    std::vector<herbal::util::StringPiece> trgTokens;
    split(trgTokens, target, " ");
    for(auto& t : trgTokens)
      vocab[t];

    count++;
    if(count % 100000 == 0)
      std::cerr << ".";
    if(count % 10000000 == 0)
      std::cerr << "[" << count << "]" << std::endl;
  }

  std::cerr << std::endl;

  herbal::util::ScopedFile myStdout(stdout);
  if(binary) {
    herbal::lm::CHDVocabBuilder chdVocabBuilder(vocab.GetVocab());
    chdVocabBuilder >> myStdout;
  }
  else
    vocab.PrettyDump(myStdout);
}

