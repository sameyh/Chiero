
#include "sources.h"

namespace herbal {
  const uint64_t Sources::NotFound = std::numeric_limits<uint64_t>::max();
}