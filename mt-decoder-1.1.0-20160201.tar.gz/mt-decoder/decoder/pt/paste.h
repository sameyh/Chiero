#pragma once

#include <algorithm>

#include "util/blob.h"
#include "pt/sources.h"
#include "pt/targets.h"
#include "dec/ff/ff_header.h"
#include "dec/ff/ff_language_model.h"
#include "dec/god.h"

namespace herbal {

class Paste : public util::Blobbed {
  public:

    template <class Key>
    TargetPhrases operator()(Key& key) {
      if(key.size() == 1) {
        if (key.data()[0] == lm::wBOS) {
          return BOS();
        }
        if (key.data()[0] == lm::wEOS) {
          return EOS();
        }
      }
      
      if(key.size() > maxSourcePhraseLength_)
        return TargetPhrases();
      
      uint64_t pos = sources_[key];
      if(pos != Sources::NotFound)
        return targets_(pos);
      else {
        if(key.size() == 1)
          return UNK(key);
        else
          return TargetPhrases();
      }
    }

  private:
    
    TargetPhrases BOS() {
      TargetPhrases tpBOS;
      PhrasePiece bos(&lm::wBOS, 1);
      ScorePiece bosScorePiece(bosScore_, 2);
      AlignmentPiece ap(&oneone_, 1);
      tpBOS.emplace_back(God::Create<TargetPhrase>(bos, bosScorePiece, ap));
      return tpBOS;
    }
    
    TargetPhrases EOS() {
      TargetPhrases tpEOS;
      PhrasePiece eos(&lm::wEOS, 1);
      ScorePiece eosScorePiece(eosScore_, 2);
      AlignmentPiece ap(&oneone_, 1);
      tpEOS.emplace_back(God::Create<TargetPhrase>(eos, eosScorePiece, ap));
      return tpEOS;
    }
    
    TargetPhrases UNK() {
      PhrasePiece key(&lm::wUNK, 1);
      TargetPhrases tps;
      return UNK(key);
    }

    void ScoreUNK(TargetPhrasePtr tp) {
      // UNK_PROP = WP * -1 + PP * 1;
      // REST_COST = WLM * LM(copied unk) - UNK_PROP
      
      float lmprobs = 0;
      
      for(auto& ff : God::GetFFs()) {
        if (ff->GetFFType() == FFType::LanguageModel
            || ff->GetFFType() == FFType::WordClassLanguageModel) {
          lm::NGram ngram(tp->GetPhrase().data(), tp->GetPhrase().size());
          float prob = std::static_pointer_cast<FFLanguageModel>(ff)->QueryProb(ngram);
          lmprobs += prob * ff->GetWeights()[0];
        }
      }
      
      const ScorePiece& sp = tp->GetScores();
      
      const_cast<float&>(sp.data()[0]) = penalties_;
      const_cast<float&>(sp.data()[1]) = lmprobs - sp[0];
    }
    
    template <class Key>
    TargetPhrases UNK(const Key& key) {
      PhrasePiece unk((lm::Word*)key.data(), key.size());
 
      float* unkScores = God::Memory<float>(2);
      ScorePiece sp(unkScores, 2);
      
      AlignmentPiece ap(&oneone_, 1);
      TargetPhrases tps;
      tps.emplace_back(God::Create<TargetPhrase>(unk, sp, ap));
      ScoreUNK(tps.back());
      
      return tps;
    }

    void MapBlob(util::Blob& blob) {
      blob
        >> header_
        >> penalties_
        >> maxSourcePhraseLength_
        >> sources_
        >> targets_;
    }

    FFHeader header_;
    util::Chunk<float> penalties_;
    util::Chunk<uint64_t> maxSourcePhraseLength_;
    Sources sources_;
    Targets targets_;

    float bosScore_[2] = { 0.0, 0.0 };
    float eosScore_[2] = { 0.0, 0.0 };

    Alignment oneone_ = { 0, 0 };

    TargetPhrases tpUNK_;
    TargetPhrases tpBOS_;
    TargetPhrases tpEOS_;
  };

}
