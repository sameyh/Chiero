#pragma once

#include <algorithm>

#include "util/blob.h"
#include "pt/builder/sources_builder.h"
#include "pt/builder/targets_builder.h"

namespace herbal {

class PasteBuilder : public util::Blob {
  public:
     
    PasteBuilder() {}
    
    template <class Keys, class Translations>
    PasteBuilder(const Keys& keys, const Translations& trans) {
      Build(keys, trans);
    }
    
    template <class Keys, class Translations>
    PasteBuilder& Build(const Keys& keys, const Translations& trans) {
      
      SourcesBuilder sources_builder(keys);
      TargetsBuilder targets_builder(trans);
      
      Allocate(sources_builder.size() + targets_builder.size());
      
      *this
        << sources_builder
        << targets_builder;
      
      Rewind();
      
      return *this;
    }
};
    
}