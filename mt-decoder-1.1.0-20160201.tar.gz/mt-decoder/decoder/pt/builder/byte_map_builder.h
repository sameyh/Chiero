#pragma once

#include <algorithm>
#include <vector>
#include <iterator>

#include "util/blob.h"
#include "util/scoped_file.h"

namespace herbal {

class ByteMapBuilder : public util::Blob {
  public:
    void AppendPos() {
      byteMap_ << bytes_.Size();
    }

    template <typename T>
    void AppendData(T* data, size_t size) {
      bytes_.Write((Byte*)data, size * sizeof(T));
    }

    bool Write(util::ScopedFile& sf) {
      sf << byteMap_.Size() / sizeof(uint64_t) << bytes_.Size();

      util::Blob mapper1, mapper2;
      byteMap_ >> mapper1 >> sf;
      bytes_   >> mapper2 >> sf;

      return true;
   }

    ByteMapBuilder& operator>>(util::ScopedFile& sf) {
      Write(sf);
      return *this;
    }

    util::Blob& operator>>(util::Blobbed& blobbed) {
      mappedFile_.reset(new util::ScopedFile);
      Write(*mappedFile_);
      Map(*mappedFile_);
      return Blob::operator>>(blobbed);
    }

  private:
    util::ScopedFile byteMap_;
    util::ScopedFile bytes_;
};

}
