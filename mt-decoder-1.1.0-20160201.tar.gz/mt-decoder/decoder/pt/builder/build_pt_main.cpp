#include <string>
#include <iostream>
#include <ios>
#include <vector>
#include <boost/program_options.hpp>
#include <boost/lexical_cast.hpp>

#include "pt/paste.h"
#include "pt/builder/sources_builder.h"
#include "pt/sources.h"
#include "pt/builder/byte_map_builder.h"

#include "util/string_piece.h"
#include "util/string_piece_split.h"

#include "util/blob.h"
#include "util/bytes.h"

#include "lm/vocab.h"

#include "dec/ff/ff_factory.h"
#include "dec/ff/ff_header_builder.h"


using namespace herbal;

void packSource(std::vector<lm::Word>& sourceWords, util::StringPiece& source,
                std::unique_ptr<lm::Vocab>& vocab) {
  std::vector<util::StringPiece> srcTokens;
  util::split(srcTokens, source, " ");
  for(auto& tok : srcTokens)
      sourceWords.push_back((*vocab)[tok]);
}

float queryFF(TargetPhrase& targetPhrase, FeatureFunctionPtr& ff) {
  FFStatePtr state = ff->EmptyState();
  FFStatePtr nextState = ff->EmptyState();
  return ff->Score(state, &targetPhrase, nextState);
}

float packAndScoreTarget(util::Bytes& targetBytes,
                util::StringPiece& target,
                util::StringPiece& scores,
                util::StringPiece& alignment,
                std::unique_ptr<lm::Vocab>& vocab,
                const std::vector<float>& weights,
                std::vector<FeatureFunctionPtr>& ffs) {

  std::vector<util::StringPiece> trgTokens;
  util::split(trgTokens, target, " ");

  targetBytes.pack((Byte)trgTokens.size());
  std::vector<lm::Word> targetWords;

  for (auto& tok : trgTokens) {
    lm::Word word = (*vocab)[tok];
    targetBytes.pack(word);
    targetWords.push_back(word);
  }

  std::vector<util::StringPiece> scoreTokens;
  util::split(scoreTokens, scores, " ");
  float sum = 0;
  size_t i = 0;

  // tm scores
  for(auto& score : scoreTokens)
    sum += weights[i++] * log(boost::lexical_cast<float>(score));

  float penalties = 0;
  // word-penalty
  penalties += weights[i++] * -(int)trgTokens.size();
  // prase-penalty
  penalties += weights[i++] * 1;
  
  TargetPhrase targetPhrase(
          PhrasePiece(targetWords.data(), targetWords.size()),
          ScorePiece(), AlignmentPiece()
  );

  // lm-score (part of future score)
  float ffScore = 0.0;
  for (auto& ff: ffs) {
    ffScore += queryFF(targetPhrase, ff);
  }

  sum += penalties;
  ffScore -= penalties;

  targetBytes.pack(sum);
  targetBytes.pack(ffScore);

  std::vector<util::StringPiece> alignTokens;
  util::split(alignTokens, alignment, " ");
  targetBytes.pack((Byte)alignTokens.size());
  for(auto& align : alignTokens) {
    std::vector<util::StringPiece> ij;
    util::split(ij, align, "-");
    targetBytes.pack((Byte)boost::lexical_cast<size_t>(ij[0]));
    targetBytes.pack((Byte)boost::lexical_cast<size_t>(ij[1]));
  }

  return sum + ffScore;
}

void getOptions(
   int argc,
   char** argv,
   std::string& ptPath,
   std::string& vocabPath,
   std::vector<std::string>& lmPaths,
   std::vector<float>& tmWeights,
   float& wordPenalty,
   float& phrasePenalty) {
  namespace po = boost::program_options;
  po::options_description cmdline_options("Allowed options");

  bool help = false;

  cmdline_options.add_options()
    ("output,o", po::value(&ptPath)->required(),
     "Path to output phrase table")
    ("vocab,v", po::value(&vocabPath)->required(),
     "Path to common vocabulary")
    ("lm,l", po::value<std::vector<std::string>>(&lmPaths)->multitoken(),
     "Path to lms for scoring")
    ("tm-weights", po::value<std::vector<float> >(&tmWeights)->multitoken(),
     "Translation model weights")
    ("word-penalty", po::value<float>(&wordPenalty),
     "Word penalty weight")
    ("phrase-penalty", po::value<float>(&phrasePenalty),
     "Phrase penalty weight")
    ("help,h", po::value(&help)->zero_tokens()->default_value(false),
     "Print this help message and exit")
  ;

  po::variables_map vm;
  try {

    po::store(po::parse_command_line(argc, argv, cmdline_options,
                                     po::command_line_style::unix_style ^
                                     po::command_line_style::allow_short), vm);
    po::notify(vm);
  }

  catch (std::exception& e) {
    std::cout << "Error: " << e.what() << std::endl << std::endl;

    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }

  if (help) {
    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }
}

int main(int argc, char** argv) {
  std::string ptPath;
  std::string vocabPath;
  std::vector<std::string> lmPaths;
  std::vector<float> tmWeights;
  float wordPenalty = 0;
  float phrasePenalty = 0;

  getOptions(argc, argv, ptPath, vocabPath, lmPaths, tmWeights, wordPenalty, phrasePenalty);

  std::vector<float> weights;
  for(auto& weight: tmWeights) {
    weights.push_back(weight);
  }
  weights.push_back(wordPenalty);
  weights.push_back(phrasePenalty);

  float penalties = 0;
  penalties += wordPenalty * -1;
  penalties += phrasePenalty * 1;

  FFFactory ffFactory;
  std::vector<FeatureFunctionPtr> ffs;
  std::vector<std::unique_ptr<util::Blob>> lmBlobs;
  std::vector<std::unique_ptr<util::ScopedFile>> lmFiles;

  for (auto& lmPath : lmPaths) {
    std::cout << "LM: " << lmPath << std::endl;
    if (lmPath.size() > 0) {
      lmFiles.emplace_back(new util::ScopedFile(lmPath));
      lmBlobs.emplace_back(new util::Blob());
      lmBlobs.back()->Map(*lmFiles.back());
      ffs.push_back(ffFactory.Load(0, *lmBlobs.back()));
    }
  }

  std::unique_ptr<lm::Vocab> vocab;
  util::Blob vocabBlob;
  std::unique_ptr<util::ScopedFile> vocabFile;
  if(vocabPath.size() > 0) {
    vocabFile.reset(new util::ScopedFile(vocabPath));
    vocabBlob.Map(*vocabFile);
    vocab.reset(new lm::CHDVocab());
    vocabBlob >> *(lm::CHDVocab*)vocab.get();
  } else {
    vocab.reset(new lm::GrowVocab());
  }

  std::ios_base::sync_with_stdio(false);

  ByteMapBuilder sourceByteMapBuilder;
  ByteMapBuilder targetByteMapBuilder;

  size_t count = 0;
  size_t countSource = 0;
  std::string lastSource;

  size_t maxSourcePhraseLength = 0;

  std::vector<std::pair<float,util::Bytes>> targetBytesCollection;

  std::string line;
  while(std::getline(std::cin, line)) {
    util::StringPiece s(line.data(), line.length());
    std::vector<util::StringPiece> fields;
    split(fields, s, " ||| ");

    if(lastSource.empty() || lastSource != fields[0]) {
      std::sort(targetBytesCollection.begin(), targetBytesCollection.end());

      size_t c = 0;
      for(auto& scoredTp : targetBytesCollection) {
        if (c >= 20) break;
        targetByteMapBuilder.AppendData(scoredTp.second.data(),
                                        scoredTp.second.size());
        c++;
      }
      targetBytesCollection.clear();

      sourceByteMapBuilder.AppendPos();
      std::vector<lm::Word> sourceWords;
      packSource(sourceWords, fields[0], vocab);

      if(sourceWords.size() > maxSourcePhraseLength)
        maxSourcePhraseLength = sourceWords.size();

      sourceByteMapBuilder.AppendData(sourceWords.data(), sourceWords.size());
      lastSource = fields[0].as_string();
      countSource++;

      targetByteMapBuilder.AppendPos();
    }

    util::Bytes targetBytes;
    float score = packAndScoreTarget(targetBytes,
                                     fields[1], fields[2], fields[3],
                                     vocab, weights, ffs);
    targetBytesCollection.emplace_back(-score, targetBytes);

    count++;
    if(count % 20000 == 0) {
      std::cout << ".";
    }
    if(count % 1000000 == 0) {
      std::cout << countSource << "/" << count << std::endl;
    }
  }
  std::sort(targetBytesCollection.begin(), targetBytesCollection.end());
  size_t c = 0;
  for(auto& tp : targetBytesCollection) {
    if (c >= 20) break;
    targetByteMapBuilder.AppendData(tp.second.data(), tp.second.size());
    c++;
  }

  util::ScopedFile sf(ptPath, util::SF_WRITE);
  FFHeaderBuilder(FFType::PhraseTable, weights) >> sf;

  sf << penalties;
  sf << maxSourcePhraseLength;

  ByteMap sources;
  sourceByteMapBuilder >> sources;
  SourcesBuilder(sources) >> sf;

  targetByteMapBuilder >> sf;
}

