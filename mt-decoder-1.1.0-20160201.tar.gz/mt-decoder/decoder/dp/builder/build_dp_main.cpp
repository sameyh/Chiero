#include <string>
#include <iostream>
#include <ios>
#include <vector>
#include <boost/program_options.hpp>

#include "util/string_piece.h"
#include "util/string_piece_split.h"
#include "util/blob.h"
#include "util/bytes.h"

#include "dec/ff/ff_header_builder.h"
#include "dec/ff/ff_type.h"

using namespace herbal;


int main(int argc, char** argv) {
    namespace po = boost::program_options;
    po::options_description cmdline_options("Allowed options");

    bool help = false;

    float distortionPenaltyWeight = 0;
    std::string outputPath;

    cmdline_options.add_options()
        ("output,o", po::value(&outputPath)->required(),
         "Path to output file")
        ("weights,w", po::value(&distortionPenaltyWeight)->required(),
         "Reordering Model weights")
        ("help,h", po::value(&help)->zero_tokens()->default_value(false),
         "Print this help message and exit")
        ;

    po::variables_map vm;
    try {
        po::store(po::command_line_parser(argc, argv).
                options(cmdline_options).run(), vm);
        po::notify(vm);
    }
    catch (std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl << std::endl;

        std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
        std::cout << cmdline_options << std::endl;
        exit(0);
    }

    if (help) {
        std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
        std::cout << cmdline_options << std::endl;
        exit(0);
    }

    std::vector<float> weight;
    weight.push_back(distortionPenaltyWeight);

    util::ScopedFile sf(outputPath, util::SF_WRITE);
    FFHeaderBuilder(FFType::DistortionPenalty, weight) >> sf;

    return 0;
}

