#pragma once
#include <iostream>

namespace herbal {

/**
  * @brief  Lexical Reordering Scores
  */
template <typename T>
class LRScores
{
    public:

        /**
         * @brief Reordering types
         *
         * There are three reordering types:
         *  * monotonious (M)
         *  * swapped (S)
         *  * discontinious (D)
         *
         */
        enum ReorderingTypes {M, S, D};

        /**
         * @brief Constructor.
         *
         * @param scores[6] LR scores.
         */
        LRScores(T scores[6]) {
            std::copy(scores, scores + ScoreNumber, scores_);
        }

        /**
         * @brief Default constructor. Set all scores to zero.
         */
        LRScores() {
            memset(scores_, 0.0, ScoreNumber);
        }

        /**
         * @brief operator []. Return a score at given index.
         *
         * @param index Index of a score.
         *
         * @return  score.
         */
        inline const T& operator[](size_t index) const {
            return scores_[index];
        }

        /**
         * @brief Get a pointer to the first element.
         *
         * @return  A pointer to the first element.
         */
        const T* begin() const {
            return scores_;
        }

        /**
         * @brief Return a pointer to the end.
         *
         * @return pointer to the end.
         */
        const T* end() const {
            return scores_ + ScoreNumber;
        }

        /**
         * @brief Return a reordering type given range of two phrases.
         *
         * @param pBegin beginning position of the first phrase.
         * @param pEnd end position of the first phrase.
         * @param nBegin beginning position of the second phrase.
         * @param nEnd end position of the second phrase.
         *
         * @return  Reordering type of the phrases.
         */
        inline static ReorderingTypes GetReorderingType(
                const size_t& pBegin, const size_t& pEnd,
                const size_t& nBegin, const size_t& nEnd)
        {
            if (pEnd + 1 == nBegin) {return M;}
            else if (nEnd + 1 == pBegin) { return S;}
            else {return D;}
        }

        /**
         * @brief Return a score due to reordering type of phrases - the backward score.
         *
         * @param pBegin beginning position of the first phrase.
         * @param pEnd end position of the first phrase.
         * @param nBegin beginning position of the second phrase.
         * @param nEnd end position of the second phrase.
         *
         * @return Backward score.
         */
        inline T ScoreBackward (
                const size_t& pBegin, const size_t& pEnd,
                const size_t& nBegin, const size_t& nEnd) const
        {
            return scores_[GetReorderingType(pBegin, pEnd, nBegin, nEnd)];
        }

        /**
         * @brief Return a score due to reordering type of phrases - the forward score.
         *
         * @param pBegin beginning position of the first phrase.
         * @param pEnd end position of the first phrase.
         * @param nBegin beginning position of the second phrase.
         * @param nEnd end position of the second phrase.
         *
         * @return Forward score.
         */
        inline T ScoreForward(
                const size_t& pBegin, const size_t& pEnd,
                const size_t& nBegin, const size_t& nEnd) const
        {
            return scores_[ScoreNumber/2 + GetReorderingType(pBegin, pEnd, nBegin, nEnd)];
        }

        /**
         * @brief Print scores.
         */
        void print() const {
            for(size_t i = 0; i < ScoreNumber - 1; ++i) {
                std::cout << scores_[i] << " ";
            }
            std::cout << scores_[ScoreNumber - 1];
        }

        friend std::ostream& operator<<(std::ostream& stream,
                                        const LRScores<T> scores) {
            for(size_t i = 0; i < ScoreNumber - 1; ++i) {
                stream << scores.scores_[i] << " ";
            }
            stream << scores.scores_[ScoreNumber - 1];
            return stream;
        }



    private:
        T scores_[6];
    public:
        static const size_t ScoreNumber = 6;

};

}
