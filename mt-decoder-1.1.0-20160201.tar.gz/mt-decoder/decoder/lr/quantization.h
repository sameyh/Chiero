#pragma once
#include <vector>
#include <string>
#include <algorithm>

#include "lr/lr_scores.h"
#include "lr/lr_table.h"

namespace herbal {

class Quantization {
  public:
    Quantization():
        buckets_(BucketsNumber),
        bucketSizes_(BucketsNumber),
        centroids_(BucketsNumber),
        min_value_(1000),
        max_value_(-1000) {}

    void Compute(const void* table) {
      FindBounds(table);
      range_ = max_value_ - min_value_;
      FillBuckets(table);
      ComputeCentroids();
    }

    size_t GetBucketIndex(const float& score) const {
      return std::floor(BucketsNumber * (score - min_value_) / range_ );
    }

    const std::vector<float> GetCentroids() const {
      return centroids_;
    }

    static const size_t BucketsNumber = (1 << 8);

  protected:
    virtual void FillBuckets(const void* table) = 0;
    virtual void FindBounds(const void* table) = 0;


    void AddData(const float& score) {
      size_t index = GetBucketIndex(score);
      buckets_[index] += score;
      ++bucketSizes_[index];
    }

    void UpdateBounds(const float& score) {
        min_value_ = std::min(score, min_value_);
        max_value_ = std::max(score, max_value_);
    }


  private:
    std::vector<float> buckets_;
    std::vector<size_t> bucketSizes_;
    std::vector<float> centroids_;
    float min_value_;
    float max_value_;
    float range_;

    void ComputeCentroids() {
      for (size_t i = 0; i < BucketsNumber; ++i) {
        centroids_[i] = buckets_[i] / bucketSizes_[i];
      }
    }


};

}
