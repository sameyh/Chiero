#pragma once
#include <iostream>

#include "util/blob.h"

#include "lr/lr_scores.h"

namespace herbal {

class LRTableBase: public util::Blobbed
{
  public:
    enum class LRTableType : uint8_t {
      Normal,
      Quantized};

    const LRScores<float> operator[](const size_t& index) const {
        // std::cerr << "KEY: " << index << std::endl;
      return GetScores(index);
    }

    virtual LRScores<float> GetScores(const size_t& index) const = 0;
};

}
