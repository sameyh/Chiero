#pragma once

#include <algorithm>
#include <iterator>
#include <cstring>
#include <cstdlib>

#include "util/progress.h"
#include "util/scoped_file.h"

namespace herbal {
namespace util {

const size_t SORT_GB = 1024ul * 1024ul * 1024ul;
const size_t SORT_MB = 1024ul * 1024ul;
const size_t SORT_KB = 1024ul;

size_t SORT_MEMORY = 2 * SORT_GB;

bool SetSortMemory(const char* memstr) {
  size_t factor;
  char unit;
  size_t matched = std::sscanf(memstr, "%lu%c", &factor, &unit);
  if(matched == 2) {
    SORT_MEMORY = factor;
    switch(unit) {
      case 'G': SORT_MEMORY *= SORT_GB; break;
      case 'M': SORT_MEMORY *= SORT_MB; break;
      case 'K': SORT_MEMORY *= SORT_KB; break;
      case 'g': SORT_MEMORY *= SORT_GB; break;
      case 'm': SORT_MEMORY *= SORT_MB; break;
      case 'k': SORT_MEMORY *= SORT_KB; break;
    }
  }
  else if(matched) {
    SORT_MEMORY = factor * SORT_GB;
  }
  
  return matched > 0;
}

template<class InputIterator>
size_t SortFits() {
  return SORT_MEMORY /
    sizeof(typename std::iterator_traits<InputIterator>::value_type);
}

template<class InputIterator>
bool SortInMemory(InputIterator first, InputIterator last) {
  return std::distance(first, last) <= SortFits<InputIterator>();
}

template<class InputIterator>
size_t MergeSortProgress(InputIterator first, InputIterator last) {
  return (2ul << int(ceil(log(std::distance(first, last) /
                              (double)SortFits<InputIterator>()) / log(2)))) - 1;
}

template<class InputIterator, class OutputIterator,
         class Sorter, class Compare, class Progress>
void MergeSort(InputIterator first, InputIterator last,
                OutputIterator out,
                Sorter sorter, Compare comp,
                Progress &progress) {
  
  size_t len = std::distance(first, last);
  
  if(len < 2)
    return;
  
  typedef typename
  std::iterator_traits<InputIterator>::value_type ValType;
  
  if(!SortInMemory(first, last)) {
    InputIterator middle = first + std::distance(first, last) / 2;
    
    ScopedFile buffer1;
    MergeSort(first, middle,
              ScopedFile::OutputIterator<ValType>(buffer1),
              sorter, comp, progress);
    
    ScopedFile buffer2;
    MergeSort(middle, last,
              ScopedFile::OutputIterator<ValType>(buffer2),
              sorter, comp, progress);
    
    std::merge(buffer1.begin<ValType>(), buffer1.end<ValType>(),
               buffer2.begin<ValType>(), buffer2.end<ValType>(),
               out, comp);
  }
  else {
    ValType* buffer = std::get_temporary_buffer<ValType>(len).first;
    std::copy(first, last, std::raw_storage_iterator<ValType*, ValType>(buffer));
    sorter(buffer, buffer + len, comp);
    std::copy(buffer, buffer + len, out);
    std::return_temporary_buffer(buffer);
  }
  ++progress;
}

template<class InputIterator, class OutputIterator>
void MergeSort(InputIterator first, InputIterator last,
               OutputIterator out, Progress &progress) {
  MergeSort(first, last, out,
            std::sort<InputIterator, std::less<typename std::iterator_traits<InputIterator>::value_type>>,
            std::less<typename std::iterator_traits<InputIterator>::value_type>(),
            progress);
}

template<class InputIterator, class OutputIterator>
void MergeSort(InputIterator first, InputIterator last,
               OutputIterator out) {
  size_t progress = 0;
  MergeSort(first, last, out,
            std::sort<InputIterator, std::less<typename std::iterator_traits<InputIterator>::value_type>>,
            std::less<typename std::iterator_traits<InputIterator>::value_type>(),
            progress);
}

template<class InputIterator, class OutputIterator, class Compare>
void MergeSort(InputIterator first, InputIterator last,
               OutputIterator out, Compare compare) {
  size_t progress = 0;
  MergeSort(first, last, out,
            std::sort<InputIterator, Compare>,
            compare, progress);
}

template<class InputIterator, class OutputIterator,
         class Compare, class Progress>
void MergeSort(InputIterator first, InputIterator last,
               OutputIterator out, Compare compare,
               Progress &progress) {
  MergeSort(first, last, out,
            std::sort<InputIterator, Compare>,
            compare, progress);
}

template<class InputIterator, class OutputIterator>
void StableMergeSort(InputIterator first, InputIterator last,
                     OutputIterator out, Progress &progress) {
  MergeSort(first, last, out,
            std::stable_sort<InputIterator, std::less<typename std::iterator_traits<InputIterator>::value_type>>,
            std::less<typename std::iterator_traits<InputIterator>::value_type>(),
            progress);
}

template<class InputIterator, class OutputIterator>
void StableMergeSort(InputIterator first, InputIterator last,
                     OutputIterator out) {
  size_t progress = 0;
  MergeSort(first, last, out,
            std::stable_sort<InputIterator, std::less<typename std::iterator_traits<InputIterator>::value_type>>,
            std::less<typename std::iterator_traits<InputIterator>::value_type>(),
            progress);
}

template<class InputIterator, class OutputIterator, class Compare>
void StableMergeSort(InputIterator first, InputIterator last,
                     OutputIterator out, Compare compare) {
  size_t progress = 0;
  MergeSort(first, last, out,
            std::stable_sort<InputIterator, Compare>,
            compare, progress);
}

template<class InputIterator, class OutputIterator,
         class Compare, class Progress>
void StableMergeSort(InputIterator first, InputIterator last,
                     OutputIterator out, Compare compare,
                     Progress &progress) {
  MergeSort(first, last, out,
            std::stable_sort<InputIterator, Compare>,
            compare, progress);
}


}
}