#pragma once

#include "util/string_piece.h"
#include <boost/functional/hash.hpp>

namespace herbal {
  namespace util {

    void split(std::vector<StringPiece>& c,
               const StringPiece& s,
               const StringPiece& sep);

  }
}
