#pragma once

#include <vector>
#include <memory>
#include <boost/pool/object_pool.hpp>
#include <boost/pool/pool.hpp>

#include "util/types.h"

namespace herbal {

class Pool {
  public:
    virtual ~Pool() {}
};

template <class T>
class TypedPool : public Pool {
  public:
    template <class ...Args>
    T* Construct(Args&&... args) {
      return pool_.construct(std::forward<Args>(args)...);
    }
    
  private:
    boost::object_pool<T> pool_;
};

class Pools {
  public:
    
    Pools()
    : bytes_(sizeof(Byte)) {}
    
    ~Pools() {
      for(auto p : pools_)
        delete p;
    }
    
    template <class T, class ...Args>
    T* Construct(Args&&... args) {
      size_t poolIdx = makePool<T>();
      return static_cast<TypedPool<T>*>(pools_[poolIdx])->Construct(std::forward<Args>(args)...);
    }

    void* Memory(size_t length) {
      void* memory = bytes_.ordered_malloc(length);
      std::memset(memory, 0, length);
      return memory;
    }
    
    void ClearAll() {
      for(auto p : pools_)
        delete p;
      pools_.clear();
      bytes_.purge_memory();  
    }
  
  private:
    template <class T>
    inline size_t makePool() {
      thread_local size_t poolIdx = pools_.size();
      if(poolIdx >= pools_.size()) {
#ifdef DEBUG
        std::cerr << "Creating pool for " << poolIdx << std::endl;
#endif
        pools_.resize(poolIdx + 1);
        pools_[poolIdx] = new TypedPool<T>();
      }
      return poolIdx;
    }

    std::vector<Pool*> pools_;
    boost::pool<> bytes_;
};
    
}
