#include "blob.h"

namespace herbal {
namespace util {
    
    Blob& operator>>(ScopedFile& sf, Blob& blob) {
        blob.Map(sf);
        return blob;
    }
}
}
