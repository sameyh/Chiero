#pragma once

#include <cstdio>
#include <cstdlib>
#include <utility>
#include <vector>

#include "util/types.h"

namespace herbal {    
  namespace util {
       
    class Bytes {
      public:
        typedef Byte value_type;
        
        Byte* data() {
          return data_.data();
        }
        
        size_t size() {
          return data_.size();
        }
        
        const Byte* data() const {
          return data_.data();
        }
        
        size_t size() const {
          return data_.size();
        }
        
        template <typename T>
        void pack(T value) {
          size_t addSize = sizeof(T);
          size_t prevSize = data_.size();
          data_.resize(prevSize + addSize);
          std::memcpy(data() + prevSize, &value, addSize);
        }
        
        bool operator<(const Bytes& o) const {
          if(size() != o.size())
            return size() < o.size();
          else
            return std::memcmp(data(), o.data(), size()) == -1;
        }
        
      private:
        std::vector<Byte> data_;
    };
    
  }
}