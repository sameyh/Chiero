#include "bit_wrapper.h"
#include "exception.h"

namespace herbal {
namespace util {

BitWrapper::BitWrapper(std::vector<uint8_t>& data)
  : m_data(data), m_bitSize(m_bits * m_data.size())
{}

bool BitWrapper::GetBit(size_t i) {
  UTIL_THROW_IF2(i >= m_bitSize, "GetBit: bit position i out of bonds");

  const size_t bytePos = i >> m_exp;
  const size_t bitRest = i & (m_bits - 1);

  return (m_data[bytePos] & (1U << bitRest));
}

void BitWrapper::SetBit(size_t i) {
  UTIL_THROW_IF2(i >= m_bitSize, "SetBit: bit position i out of bonds");
  ChangeBit(i, true);
}

void BitWrapper::ClearBit(size_t i) {
  UTIL_THROW_IF2(i >= m_bitSize, "ClearBit: bit position i out of bonds");
  ChangeBit(i, false);
}

void BitWrapper::ChangeBit(size_t i, bool value) {
  UTIL_THROW_IF2(i >= m_bitSize, "ChangeBit: bit position i out of bonds");

  const size_t bytePos = i >> m_exp;
  const size_t bitRest = i & (m_bits - 1);

  if(value)
    m_data[bytePos] |= (1U << bitRest);
  else
    m_data[bytePos] &= ~(1U << bitRest);
}

void BitWrapper::FlipBit(size_t i) {
  UTIL_THROW_IF2(i >= m_bitSize, "FlipBit: bit position i out of bonds");

  const size_t bytePos = i >> m_exp;
  const size_t bitRest = i & (m_bits - 1);

  m_data[bytePos] ^= (1U << bitRest);
}

uint64_t BitWrapper::GetBits(size_t i, size_t length) {
  UTIL_THROW_IF2(i >= m_bitSize, "GetBits: bit position i out of bonds");
  UTIL_THROW_IF2((length > 64 || i + length > m_bitSize), "GetBits: length too big");

  size_t bytePos = i >> m_exp;
  size_t bitRest = i & (m_bits - 1);

  uint64_t value = 0;
  size_t totalShift = 0;

  // Handle possibly shifted first byte
  if(bitRest) {
    value = m_data[bytePos++] >> bitRest;
    totalShift += m_bits - bitRest;
  }

  // Handle remaining bytes
  while(totalShift < length) {
    uint64_t tempValue = m_data[bytePos++];
    value |= tempValue << totalShift;
    totalShift += m_bits;
  }

  if (length < 64) {
    // Cut value to specified number of bits
    value &= ((uint64_t(1) << length) - 1);
  }

  return value;
}

void BitWrapper::SetBits(size_t i, uint64_t value, size_t length) {
  UTIL_THROW_IF2(i >= m_bitSize, "SetBits: bit position i out of bonds");
  UTIL_THROW_IF2(length > 64 || i + length > m_bitSize, "SetBits: length too big");

  if (length < 64) {
    // Cut value to specified number of bits
    value &= ((uint64_t(1) << length) - 1);
  }

  size_t bytePos = i >> m_exp;
  size_t bitRest = i & (m_bits - 1);

  m_data[bytePos++] |= value << bitRest;
  value >>= m_bits - bitRest;

  // Set remaining bits
  while(value) {
    m_data[bytePos++] |= value;
    value >>= m_bits;
  }
}

void BitWrapper::ClearBits(size_t i, uint64_t value, size_t length) {
  UTIL_THROW_IF2(i >= m_bitSize, "ClearBits: bit position i out of bonds");
  UTIL_THROW_IF2(length > 64 || i + length > m_bitSize, "ClearBits: length too big");

  if (length < 64) {
    // Cut value to specified number of bits
    value &= ((uint64_t(1) << length) - 1);
  }

  size_t bytePos = i >> m_exp;
  size_t bitRest = i & (m_bits - 1);

  m_data[bytePos++] &= ~(value << bitRest);
  value >>= m_bits - bitRest;

  // Set remaining bits
  while(value) {
    m_data[bytePos++] &= ~value;
    value >>= m_bits;
  }
}

void BitWrapper::PushBits(uint64_t value, const size_t length) {
  UTIL_THROW_IF2(length > 64, "PushBits: length > 64");

  if (length < 64) {
    // Cut value to specified number of bits
    value &= ((uint64_t(1) << length) - 1);
  }

  // Calculate bit left in last byte
  const uint8_t bitRest = m_bitSize & (m_bits - 1);
  size_t totalShift = 0;

  // Add new byte if no bits left in last byte
  if(!bitRest && length)
    m_data.push_back(0);

  // Fill last byte
  m_data.back() |= value << bitRest;
  // Shift by filled bits
  value >>= m_bits - bitRest;
  totalShift += m_bits - bitRest;

  // Add remaining bytes
  while(totalShift < length) {
    m_data.push_back(value);
    value >>= m_bits;
    totalShift += m_bits;
  }

  // Increase total number of bits by length
  m_bitSize += length;
}

void BitWrapper::PushBit(bool bit) {
  const uint8_t bitRest = m_bitSize & (m_bits - 1);
  if(!bitRest)
    m_data.push_back(0);

  if(bit)
    m_data.back() |= 1U << bitRest;

  ++m_bitSize;
}

std::vector<uint8_t>& BitWrapper::GetContainer() {
  return m_data;
}

void BitWrapper::Resize(size_t bitSize) {
  size_t byteSize = (bitSize + (m_bits - 1)) >> m_exp;
  m_data.resize(byteSize, 0);

  // Unset dangling bits
  if(m_bitSize > bitSize && byteSize != 0) {
    //size_t bitRest = bitSize & (m_bits - 1);
    m_data.back() &= (1U << bitSize) - 1;
  }

  m_bitSize = bitSize;
}

size_t BitWrapper::GetBitSize() const {
  return m_bitSize;
}

size_t BitWrapper::GetByteSize() const {
  return m_data.size();
}

}
}
