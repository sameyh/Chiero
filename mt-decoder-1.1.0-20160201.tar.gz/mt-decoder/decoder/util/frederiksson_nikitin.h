#pragma once

#include <vector>
#include <bitset>

#include "bit_wrapper.h"

//TODO: Make this faster with bit twiddling hack
template <typename Int>
inline uint8_t CodeLength(Int x) {
  uint8_t res = 0;
  while(x > 1) {
    x >>= 1;
    ++res;
  }
  return res;
}

template <typename Int>
inline uint64_t IntCode(Int x, size_t length) {
  return x - ((1U << length) - 1U);
}

void FrederikssonNikitin(const std::vector<uint32_t>& valueTable,
                         std::vector<uint8_t>& compressedTable) {
  std::vector<uint8_t> lengths;
  lengths.reserve(valueTable.size());
  
  uint64_t totalLength = 0; 
  for(auto& value : valueTable) {
    if(value > 0) {
      lengths.push_back(CodeLength(value + 1));
      totalLength += lengths.back();
    }
  }
  
  BitWrapper wrapped(compressedTable);
  wrapped.Resize(totalLength);
  
  size_t currentPos = 0;
  for(size_t i = 0; i < valueTable.size(); ++i) {
    if(valueTable[i] != 0) {
      valueTableBits.SetBits(currentPos, IntCode(valueTable[i], lengths[i]), lengths[i]);
      currentPos += lengths[i];
    }
  }
  
  //BitWrapper lengthTableBits(lengthTable);
}