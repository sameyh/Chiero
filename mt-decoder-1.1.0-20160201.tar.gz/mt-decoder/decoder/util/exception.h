#pragma once

#include <exception>
#include <sstream>
#include <string>


namespace herbal {
namespace util {

class Exception : public std::exception {
  public:
    Exception() throw();
    virtual ~Exception() throw();

    Exception(const Exception&);

    const char *what() const throw();

    void SetInfo(
        const char *file,
        unsigned int line,
        const char *func,
        const char *condition,
        const char *message);

  private:
    std::stringstream stream_;
    mutable std::string text_;
};

#define THROW_IF(Condition, Message) \
do { \
  if (__builtin_expect (!!(Condition), 0)) { \
    util::Exception _exception; \
    _exception.SetInfo(__FILE__, __LINE__, __PRETTY_FUNCTION__, #Condition, #Message); \
    throw _exception; \
  } \
} while (0)

} // namespace util
}
