#pragma once

#include <algorithm>

#include "util/blob.h"
#include "util/exception.h"
#include "hash/random_hash.h"
#include "hash/displacement.h"
#include "hash/buckets.h"

namespace herbal {

template <class RandomHash>
class CHDBuilder : public util::Blob {
  public:

    CHDBuilder() {}

    template <class KeysOrTuples>
    CHDBuilder(const KeysOrTuples& keys, double c = 0.9) {
      Build(keys, c);
    }

    template <class Keys>
    CHDBuilder& Build(const Keys& keys, double c = 0.9, bool verbose = true) {
      Buckets<RandomHash, Keys> buckets(keys, c, verbose);
      Allocate(buckets.Bytes());

      size_t iteration = 10;
      bool success = false;
      while(!success) {
        if(verbose)
          std::cerr << "Creating PH first - " << iteration
                    << " iterations left." << std::endl;
        --iteration;

        util::Chunk32 seed;
        util::Chunk64 n, m, r;

        *this >> seed >> n >> m >> r;
        n = keys.size();

        THROW_IF(!buckets.SplitIntoBuckets(seed, m, r),
                       "Mapping failed. Check for duplicate keys");

        util::ManyChunks32 displaceTable(r);
        util::ManyChunks32 rankTable(m - n);
        *this >> displaceTable >> rankTable;

        buckets.Sort();
        success = buckets.Search(displaceTable, rankTable);
        THROW_IF(!success && iteration == 0,
                       "Too many iterations");

        Rewind();
      }
      if(verbose)
        std::cerr << "Success" << std::endl;
      return *this;
    }
};

}
