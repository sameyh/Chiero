#pragma once

#include <iostream>
#include <vector>
#include <algorithm>

#include "util/exception.h"
#include "hash/random_hash.h"
#include "hash/displacement.h"

namespace herbal {

const size_t keysPerBucket = 4;
const size_t maxProbes = 1ul << 20;

struct BucketItem {
    uint64_t f;
    uint64_t h;
};

bool operator==(const BucketItem& b1, const BucketItem& b2);

typedef std::vector<BucketItem> Bucket;

template<class RandomHash, class Keys>
class Buckets {
  public:
    Buckets(const Keys& keys, double c = 0.9, bool verbose = true)
    : keys_(keys),
      n_(keys_.size()),
      m_(n_ / c + 1),
      r_(m_ / keysPerBucket + 1),
      seed_(0),
      buckets_(r_),
      maxBucketSize_(0),
      verbose_(verbose)
    {}

    size_t Bytes() {
        size_t bytes = sizeof(seed_) + sizeof(n_) + sizeof(m_) + sizeof(r_);
        bytes += (r_ + m_ - n_) * sizeof(uint32_t);
        return bytes;
    }

    // TODO: make this space-efficient, vector of vectors is no good.
    template <typename Seed, typename Size>
    bool SplitIntoBuckets(Seed& seed, Size& m, Size& r) {
      Clear();

      int iteration = 100;
      bool success = false;

      if(verbose_)
        std::cerr << "Splitting " << n_ << " keys into "
                  << r_ << " buckets (" << m_ << " bins). " << std::endl;

      while(!success) {
        seed_ = rand() % m_;
        --iteration;

        try {
          for(auto& key : keys_) {
            HashTuple tuple;
            RandomHash::Hash(seed_, key, tuple);
            THROW_IF(!AddTuple(tuple), "Collision detected");
          }
          success = true;
        }
        catch(util::Exception &ce) {
          std::cerr << ce.what() << std::endl;
          if(iteration > 0) {
            if(verbose_)
                std::cerr << "Restarting, " << iteration
                          << " iterations left." << std::endl;
          }
          else
            return false;

          Clear();
        }
      }

      seed = seed_;
      m = m_;
      r = r_;

      return success;
    }

    // TODO: make this space-efficient, vector of vectors is no good.
    template <typename Size>
    bool SplitIntoBuckets(Size& m, Size& r) {
      Clear();

      if(verbose_)
        std::cerr << "Splitting " << n_ << " keys into "
                  << r_ << " buckets (" << m_ << " bins). " << std::endl;

      for(auto& tuple : keys_)
        THROW_IF(!AddTuple(tuple), "Collision detected");

      m = m_;
      r = r_;

      return true;
    }

    void Sort() {
      if(verbose_)
        std::cerr << "Splitting buckets by size" << std::endl;

      bySizes_.resize(maxBucketSize_ + 1);
      for(size_t i = 0; i < buckets_.size(); ++i) {
        bySizes_[buckets_[i].size()].push_back(i);
      }
    }

    // Search with entropy-trick
    template <class Table>
    bool Search(Table& displaceTable, Table& rankTable) {
      if(verbose_)
        std::cerr << "Searching for displacement values" << std::endl;
      // to avoid allocation during push_back in PlaceBucket
      placed_.reserve(maxBucketSize_);
      std::vector<bool> occupied(m_, false);

      for(size_t currSize = maxBucketSize_; currSize > 0; --currSize) {
        size_t displaceIndex = 0;

        // repeat until all buckets could be placed
        while(!bySizes_[currSize].empty()) {
          std::vector<size_t> notPlaced;
          for(auto& bucketIndex : bySizes_[currSize]) {
            size_t d0 = 0, d1 = 0;
            GetDisplacement(displaceIndex, d0, d1);
            if(PlaceBucket(bucketIndex, d0, d1, occupied))
              displaceTable[bucketIndex] = displaceIndex;
            else
              notPlaced.push_back(bucketIndex);
          }

          bySizes_[currSize].swap(notPlaced);
          displaceIndex++;

          if(!(displaceIndex < maxProbes && displaceIndex < m_ * m_))
            return false;
        }
      }

      // Get unoccupied values
      for(size_t i = 0, j = 0; i < m_; ++i)
        if(!occupied[i])
          rankTable[j++] = i;

      return true;
    }

  private:

    bool PlaceBucket(size_t i, size_t d0, size_t d1, std::vector<bool>& occupied) {
      placed_.clear();
      // try to place all elements in non-occupied bins
      for(auto& item : buckets_[i]) {
        size_t position = (item.f + d0 * item.h + d1) % m_;
        if(!occupied[position]) {
          occupied[position] = true;
          placed_.push_back(position);
        }
        else
          break;
      }
      // erase placed elements if not all placed
      if(placed_.size() != buckets_[i].size()) {
        for(auto& position : placed_)
          occupied[position] = false;
        // failed
        return false;
      }
      // success
      return true;
    }

    void Clear() {
      for(auto& b : buckets_)
        b.clear();

      maxBucketSize_ = 0;
      bySizes_.clear();
    }

    inline bool AddTuple(const HashTuple& tuple) {
      Bucket& b = buckets_[tuple.g % r_];
      BucketItem item = {
        tuple.f % m_,
        tuple.h % (m_ - 1) + 1
      };

      if(find(b.begin(), b.end(), item) != b.end())
        return false;

      b.push_back(item);
      if(b.size() >= maxBucketSize_)
        maxBucketSize_ = b.size();

      return true;
    }

    const Keys& keys_;

    uint64_t n_; // number of keys
    uint64_t m_; // range of PH
    uint64_t r_; // number of buckets

    uint32_t seed_;

    std::vector<Bucket> buckets_;

    // for sorting
    size_t maxBucketSize_;
    std::vector<std::vector<size_t>> bySizes_;

    // just a helper
    std::vector<size_t> placed_;
    bool verbose_;
};

}
