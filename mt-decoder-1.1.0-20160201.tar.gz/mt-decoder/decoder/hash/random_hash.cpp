#include "hash/random_hash.h"

namespace herbal {
  
  uint32_t PreHashed::seed_ = 0;
  
}