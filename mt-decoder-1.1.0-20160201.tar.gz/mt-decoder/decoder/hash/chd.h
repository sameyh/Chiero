#pragma once

#include <algorithm>

#include "util/blob.h"
#include "hash/random_hash.h"
#include "hash/displacement.h"

namespace herbal {

template <class RandomHash>
class CHD : public util::Blobbed {
  public:
        
    template <class Key>
    uint64_t operator[](Key& key) const {
      HashTuple tuple;
      RandomHash::Hash(seed_, key, tuple);
      return (*this)[tuple];
    }
    
    inline uint64_t operator[](const HashTuple tuple) const {
      uint64_t g = tuple.g %  r_;
      uint64_t f = tuple.f %  m_;
      uint64_t h = tuple.h % (m_ - 1) + 1;
  
      uint64_t displace = displaceTable_[g];
      uint64_t probe0 = 0;
      uint64_t probe1 = 0;
      GetDisplacement(displace, probe0, probe1);
      
      uint64_t position = (f + h * probe0 + probe1) % m_;
      
      /*
      uint64_t shift = std::distance(rankTable_.begin(),
                                     std::upper_bound(rankTable_.begin(),
                                                      rankTable_.end(),
                                                      position));
                                                      */
      uint64_t shift = tempRankTable_[position];
      return position - shift;
    }
    
    uint32_t GetSeed() const {
      return seed_;
    }
    
    uint64_t GetN() const {
      return n_;
    }

  private:
    
    void MapBlob(util::Blob& blob) {
      blob
        >> seed_
        >> n_
        >> m_
        >> r_;
      
      blob
        >> displaceTable_(r_)
        >> rankTable_(m_ - n_);
        
      // @TODO: remove this later by implementing correct compression!
      tempRankTable_.resize(m_);
      size_t j = 0;
      for(size_t i = 0; i < m_; i++) {
        while(i > rankTable_[j] && j < m_ - n_) j++;
        tempRankTable_[i] = j;
      }
        
    }
    
    util::Chunk32 seed_;
    util::Chunk64 n_;
    util::Chunk64 m_;
    util::Chunk64 r_;
  
    util::ManyChunks32 displaceTable_;
    util::ManyChunks32 rankTable_;
    
    std::vector<uint32_t> tempRankTable_;
};
    
}