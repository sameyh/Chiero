#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE SourcesTests
#include <boost/test/unit_test.hpp>

#include <boost/progress.hpp>

#include <iostream>
#include <string>

#include "pt/sources.h"
#include "pt/builder/sources_builder.h"

BOOST_AUTO_TEST_CASE(Sources)
{
  std::vector<std::string> keys = {"this", "is", "a", "key",
                                   "for", "the", "MPH"};
  
  herbal::Sources sources;
  herbal::SourcesBuilder sources_builder(keys);
  sources_builder >> sources;

  size_t i = 0;
  for(auto& key : keys)
    BOOST_CHECK_EQUAL(sources[key], i++);

  std::string oov("NOT IN HASH");
  BOOST_CHECK_EQUAL(sources[oov], herbal::Sources::NotFound);
}
