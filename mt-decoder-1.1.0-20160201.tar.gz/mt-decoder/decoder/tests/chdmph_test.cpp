#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE CHDPHTests
#include <boost/test/unit_test.hpp>

#include <boost/progress.hpp>

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <ctime>
#include <cstdlib>

#include "hash/chd.h"
#include "hash/chd_builder.h"

BOOST_AUTO_TEST_CASE(SmallMPH)
{
  std::vector<std::string> keys = {"this", "is", "a", "key", "for", "the", "MPH"};
  
  srand(time(NULL));
  
  herbal::CHD<herbal::Murmur> hash;
  herbal::CHDBuilder<herbal::Murmur> builder(keys, 0.9);
  builder >> hash;
  
  std::cerr << "Hashing keys" << std::endl;
  std::vector<uint32_t> hashes;
  for(auto& key : keys) {
    uint64_t h = hash[key];
    hashes.push_back(h);
  }
  std::cerr << "Sorting hashes" << std::endl;
  std::sort(hashes.begin(), hashes.end());
  
  std::cerr << "Checking for perfectness and minimality" << std::endl;
  for(size_t i = 0; i < hashes.size(); ++i)
    BOOST_CHECK_EQUAL(i, hashes[i]);
}

BOOST_AUTO_TEST_CASE(BigMPH)
{
  std::vector<std::string> keys;
  std::ifstream in;
  
  in.open("test_keys.txt");
  std::string line;
  while(std::getline(in, line))
    keys.push_back(line);
  in.close();
  
  srand(time(NULL));
  
  herbal::CHDBuilder<herbal::Murmur> builder(keys, 0.99);
  
  std::cerr << "Hashing keys" << std::endl;
  std::vector<uint32_t> hashes;
  {
    herbal::CHD<herbal::Murmur> hash;
    builder >> hash;
    boost::progress_timer t;
    for(auto& key : keys) {
      uint64_t h = hash[key];
      hashes.push_back(h);
    }
  }
  
  std::cerr << "Sorting hashes" << std::endl;
  std::sort(hashes.begin(), hashes.end());
  
  std::cerr << "Checking for perfection and minimality" << std::endl;
  for(size_t i = 0; i < hashes.size(); ++i)
    BOOST_CHECK_EQUAL(i, hashes[i]);

}

BOOST_AUTO_TEST_CASE(WriteReadMPH)
{
  std::vector<std::string> keys;
  std::ifstream in;
  
  in.open("test_keys.txt");
  std::string line;
  while(std::getline(in, line))
    keys.push_back(line);
  in.close();
  
  srand(time(NULL));
  
  herbal::CHD<herbal::Murmur> hash1;
  herbal::CHDBuilder<herbal::Murmur> builder(keys, 0.99);
  builder >> hash1;
  
  std::cerr << "Saving first MPH" << std::endl;
  {
    boost::progress_timer t;
    builder.Write("binary.mph");
  }
  
  std::cerr << "Loading second MPH" << std::endl;
  herbal::util::Blob blob2;
  herbal::CHD<herbal::Murmur> hash2;
  {
    boost::progress_timer t;
    blob2.Read("binary.mph");
    blob2 >> hash2;
  }
  
  std::cerr << "Comparing hashes for all keys" << std::endl;
  {
    boost::progress_timer t;
    for(auto& key : keys)
      BOOST_CHECK_EQUAL(hash1[key], hash2[key]);
  }

}

BOOST_AUTO_TEST_CASE(WriteMapMPH)
{
  std::vector<std::string> keys;
  std::ifstream in;
  
  in.open("test_keys.txt");
  std::string line;
  while(std::getline(in, line))
    keys.push_back(line);
  in.close();
  
  srand(time(NULL));
  
  herbal::CHD<herbal::Murmur> hash1;
  herbal::CHDBuilder<herbal::Murmur> builder;
  builder.Build(keys, 0.99) >> hash1;

  std::cerr << "Saving first MPH" << std::endl;
  {
    boost::progress_timer t;
    hash1.Write("binary.mph");
  }
  
  std::cerr << "Loading second MPH" << std::endl;
  
  herbal::util::ScopedFile hash2File("binary.mph");
  herbal::util::Blob blob2;
  herbal::CHD<herbal::Murmur> hash2;
  {
    boost::progress_timer t;
    hash2File >> blob2 >> hash2;
  }

  std::vector<size_t> hashes;
  std::cerr << "Comparing hashes for all keys" << std::endl;
  {
    boost::progress_timer t;
    for(auto& key : keys) {
      size_t h1 = hash1[key]; 
      hashes.push_back(h1);
      BOOST_CHECK_EQUAL(h1, hash2[key]);
    }
  }

  std::cerr << "Sorting hashes" << std::endl;
  std::sort(hashes.begin(), hashes.end());
  
  std::cerr << "Checking for perfection and minimality" << std::endl;
  for(size_t i = 0; i < hashes.size(); ++i)
    BOOST_CHECK_EQUAL(i, hashes[i]);

  
}
