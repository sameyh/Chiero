#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE UtilTests
#include <boost/test/unit_test.hpp>

#include <vector>

#include "util/bit_wrapper.h"
#include "util/exception.h"

BOOST_AUTO_TEST_CASE(EmptyWrapper)
{
    std::vector<uint8_t> empty;
    herbal::util::BitWrapper emptyBW(empty);
    
    BOOST_CHECK_THROW(emptyBW.GetBit(0), herbal::util::Exception);
    BOOST_CHECK_THROW(emptyBW.SetBit(0), herbal::util::Exception);
    BOOST_CHECK_THROW(emptyBW.FlipBit(0), herbal::util::Exception);
    BOOST_CHECK_THROW(emptyBW.ClearBit(0), herbal::util::Exception);
    BOOST_CHECK_THROW(emptyBW.ChangeBit(0, true), herbal::util::Exception);
    BOOST_CHECK_THROW(emptyBW.GetBits(0, 0), herbal::util::Exception);
    BOOST_CHECK_THROW(emptyBW.GetBits(1, 0), herbal::util::Exception);
    BOOST_CHECK_THROW(emptyBW.SetBits(0, 0, 5), herbal::util::Exception);
    BOOST_CHECK_THROW(emptyBW.SetBits(1, 0, 5), herbal::util::Exception);
    BOOST_CHECK_THROW(emptyBW.ClearBits(0, 0, 5), herbal::util::Exception);
    BOOST_CHECK_THROW(emptyBW.ClearBits(1, 0, 5), herbal::util::Exception);
    BOOST_CHECK(emptyBW.GetContainer() == empty);
    BOOST_CHECK_EQUAL(0, emptyBW.GetBitSize());
    BOOST_CHECK_EQUAL(0, emptyBW.GetByteSize());
}

BOOST_AUTO_TEST_CASE(OutOfBounds)
{
    std::vector<uint8_t> bitVector(4, 0xFF); //111...
    herbal::util::BitWrapper bw(bitVector);
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 32);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 4);

    BOOST_CHECK_THROW(bw.GetBit(999), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.SetBit(999), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.FlipBit(999), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.ClearBit(999), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.ChangeBit(999, true), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.GetBits(999, 0), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.SetBits(999, 0, 0), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.ClearBits(999, 0, 0), herbal::util::Exception);

    BOOST_CHECK_THROW(bw.SetBit(32), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.SetBit(33), herbal::util::Exception);
    BOOST_CHECK_NO_THROW(bw.SetBit(31));

    BOOST_CHECK_EQUAL(bw.GetBit(30), true);
    BOOST_CHECK_EQUAL(bw.GetBit(31), true);
    BOOST_CHECK_THROW(bw.GetBit(32), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.GetBit(33), herbal::util::Exception);

    BOOST_CHECK_NO_THROW(bw.ClearBit(31)); //011...
    BOOST_CHECK_EQUAL(bw.GetBit(31), false);
    BOOST_CHECK_THROW(bw.ClearBit(32), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.ClearBit(33), herbal::util::Exception);

    BOOST_CHECK_NO_THROW(bw.FlipBit(31)); //111...
    BOOST_CHECK_EQUAL(bw.GetBit(31), true);
    BOOST_CHECK_THROW(bw.FlipBit(32), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.FlipBit(33), herbal::util::Exception);

    BOOST_CHECK_NO_THROW(bw.ChangeBit(31, false)); //011...
    BOOST_CHECK_EQUAL(bw.GetBit(31), false);
    BOOST_CHECK_THROW(bw.ChangeBit(32, false), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.ChangeBit(33, false), herbal::util::Exception);

    BOOST_CHECK_EQUAL(bw.GetBits(29, 3), 3U);
    BOOST_CHECK_THROW(bw.GetBits(29, 4), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.GetBits(32, 1), herbal::util::Exception);

    BOOST_CHECK_NO_THROW(bw.SetBits(29, 6U, 3)); //111...
    BOOST_CHECK_EQUAL(bw.GetBits(29, 3), 7U);
    BOOST_CHECK_THROW(bw.SetBits(29, 0U, 4), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.SetBits(32, 0U, 0), herbal::util::Exception);

    BOOST_CHECK_NO_THROW(bw.ClearBits(29, 6U, 3)); //001...
    BOOST_CHECK_THROW(bw.ClearBits(29, 0U, 4), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.ClearBits(32, 0U, 1), herbal::util::Exception);

    std::vector<uint8_t> resultVector;
    resultVector.push_back(0xFF);
    resultVector.push_back(0xFF);
    resultVector.push_back(0xFF);
    resultVector.push_back(0x3F);
    BOOST_CHECK(bw.GetContainer() == resultVector);

    std::vector<uint8_t> bigVector(20, 0xFF);
    herbal::util::BitWrapper bigBW(bigVector);
    BOOST_CHECK_EQUAL(bigBW.GetBitSize(), 20*8);

    BOOST_CHECK_EQUAL(bigBW.GetBits(29, 64), (uint64_t) 0xFFFFFFFFFFFFFFFF);
    BOOST_CHECK_NO_THROW(bigBW.ClearBits(29, (uint64_t) -1, 64));
    BOOST_CHECK_EQUAL(bigBW.GetBits(29, 6), (uint64_t) 0);
    BOOST_CHECK_NO_THROW(bigBW.SetBits(29, (uint64_t) -1, 64));
    BOOST_CHECK_EQUAL(bigBW.GetBits(29, 64), (uint64_t) 0xFFFFFFFFFFFFFFFF);

    BOOST_CHECK_EQUAL(bigBW.GetBits(29, 63), (uint64_t) 0x7FFFFFFFFFFFFFFF);
    BOOST_CHECK_EQUAL(bigBW.GetBits(29, 63), (uint64_t) 0x7FFFFFFFFFFFFFFF);
    BOOST_CHECK_NO_THROW(bigBW.ClearBits(29, (uint64_t) -1, 63));
    BOOST_CHECK_EQUAL(bigBW.GetBits(29, 63), (uint64_t) 0);

    BOOST_CHECK_NO_THROW(bigBW.SetBits(29, (uint64_t) -1, 63));
    BOOST_CHECK_EQUAL(bigBW.GetBits(29, 63), (uint64_t) 0x7FFFFFFFFFFFFFFF);

    BOOST_CHECK_THROW(bigBW.GetBits(29, 65), herbal::util::Exception);
    BOOST_CHECK_THROW(bigBW.SetBits(29, 0U, 65), herbal::util::Exception);
    BOOST_CHECK_THROW(bigBW.ClearBits(29, 0U, 65), herbal::util::Exception);
    BOOST_CHECK_THROW(bigBW.GetBits(29, 650), herbal::util::Exception);
    BOOST_CHECK_THROW(bigBW.SetBits(29, 0U, 650), herbal::util::Exception);
    BOOST_CHECK_THROW(bigBW.ClearBits(29, 0U, 650), herbal::util::Exception);
}

BOOST_AUTO_TEST_CASE(Resizing)
{
    std::vector<uint8_t> empty;
    herbal::util::BitWrapper bw(empty);

    bw.Resize(0);  
    BOOST_CHECK(bw.GetContainer() == empty);
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 0);

    bw.Resize(100);
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 100);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 13);
    BOOST_CHECK(bw.GetContainer() == std::vector<uint8_t>(13, 0));

    bw.Resize(0);  
    BOOST_CHECK(bw.GetContainer() == empty);
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 0);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 0);

    bw.PushBits(0x7F7F, 16); // 0111 1111 0111 1111
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 16);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 2);
    bw.Resize(15); // x111 1111 0111 1111
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 15);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 2);
    BOOST_CHECK_EQUAL(bw.GetBits(0, 15), 0x7F7F);

    bw.Resize(14); // xx11 1111 0111 1111
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 14);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 2);
    BOOST_CHECK_EQUAL(bw.GetBits(0, 14), 0x3F7F);

    bw.Resize(6); // xx11 1111
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 6);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 1);
    BOOST_CHECK_EQUAL(bw.GetBits(0, 6), 0x3F);

    bw.Resize(4); // 1111
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 4);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 1);
    BOOST_CHECK_EQUAL(bw.GetBits(0, 4), 0xF);

    bw.Resize(6); // xx00 1111
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 6);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 1);
    BOOST_CHECK_EQUAL(bw.GetBits(0, 6), 0xF);

    bw.Resize(16); // 0000 0000 0000 1111
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 16);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 2);
    BOOST_CHECK_EQUAL(bw.GetBits(0, 6), 0xF);
}

BOOST_AUTO_TEST_CASE(Pushing)
{
    std::vector<uint8_t> empty;
    herbal::util::BitWrapper bw(empty);

    bw.PushBit(true);
    bw.PushBit(false);
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 2);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 1);

    BOOST_CHECK_EQUAL(bw.GetBit(0), true);
    BOOST_CHECK_EQUAL(bw.GetBit(1), false);

    bw.Resize(0);
    bw.PushBits(0xF034, 8);
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 8);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 1);
    BOOST_CHECK(bw.GetContainer() == std::vector<uint8_t>(1, 0x34));

    bw.PushBits(0xFF, 0);
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 8);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 1);
    BOOST_CHECK(bw.GetContainer() == std::vector<uint8_t>(1, 0x34));

    BOOST_CHECK_THROW(bw.PushBits(0, 65), herbal::util::Exception);
    BOOST_CHECK_THROW(bw.PushBits(0, 165), herbal::util::Exception);
    BOOST_CHECK_NO_THROW(bw.PushBits(0, 64));
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 72);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 9);

    bw.Resize(0);
    bw.PushBits(0xFF, 4);
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 4);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 1);
    BOOST_CHECK(bw.GetContainer() == std::vector<uint8_t>(1, 0xF));
    bw.PushBits(0xFA, 4);
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 8);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 1);
    BOOST_CHECK_EQUAL(bw.GetBits(4, 4), 0xA);

    bw.PushBit(true);
    bw.PushBit(true);
    BOOST_CHECK_EQUAL(bw.GetBitSize(), 10);
    BOOST_CHECK_EQUAL(bw.GetByteSize(), 2);
    BOOST_CHECK_EQUAL(bw.GetBit(8), true);
    BOOST_CHECK_EQUAL(bw.GetBit(9), true);
}

BOOST_AUTO_TEST_CASE(Modifying)
{
    std::vector<uint8_t> vec(4, 0xF0);
    herbal::util::BitWrapper bw(vec); // 1111 0000...
    bw.FlipBit(31); // 0111...
    bw.FlipBit(29); // 0101...
    BOOST_CHECK_EQUAL(bw.GetBits(28, 4), 0x5);
    bw.ClearBit(28); // 0100...
    bw.ClearBit(29);
    bw.SetBit(30);
    bw.SetBit(31); // 1100...
    BOOST_CHECK_EQUAL(bw.GetBits(28, 4), 0xC);

    bw.Resize(10); // 0011 1100 0011 1100 00
    bw.ChangeBit(9, false);
    bw.ChangeBit(8, true);
    bw.ChangeBit(7, true);
    bw.ChangeBit(6, false);
    BOOST_CHECK_EQUAL(bw.GetBits(6, 4), 0x6);

    BOOST_CHECK_EQUAL(bw.GetBits(0, 10), 0x1B0); // 01 1011 0000
    bw.ClearBits(2, 0xFF, 4); // 01 1000 0000
    bw.SetBits(6, 0xFF, 4); // 11 1100 0000
    BOOST_CHECK_EQUAL(bw.GetBits(0, 10), 0x3C0);
    
    bw.ClearBits(4, 0xF5, 4); // 11 1000 0000
    BOOST_CHECK_EQUAL(bw.GetBits(0, 10), 0x380);

    bw.SetBits(5, 0xF5, 4); // 11 1010 0000
    BOOST_CHECK_EQUAL(bw.GetBits(0, 10), 0x3A0);
}
