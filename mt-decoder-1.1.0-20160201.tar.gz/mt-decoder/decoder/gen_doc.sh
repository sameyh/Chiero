#!/bin/bash -ex
doxygen
