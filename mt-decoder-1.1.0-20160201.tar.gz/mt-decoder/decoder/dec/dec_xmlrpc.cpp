/*
 * dec_xmlrpc.cpp
 *
 *  Created on: Nov 23, 2015
 *      Author: mchochowski
 */


#include <cassert>
#include <stdexcept>
#include <iostream>
#include <unistd.h>

#include <string>
#include <boost/program_options.hpp>
#include "dec/god.h"
#include "dec/translation_task.h"

using namespace std;
using namespace herbal;

#include <xmlrpc-c/base.hpp>
#include <xmlrpc-c/registry.hpp>
#include <xmlrpc-c/server_abyss.hpp>

typedef std::map<std::string, xmlrpc_c::value> params_t;

class TranslateMethod : public xmlrpc_c::method {
public:
    TranslateMethod() {
        // signature and help strings are documentation -- the client
        // can query this information with a system.methodSignature and
        // system.methodHelp RPC.
        this->_signature = "S:S";
            // method's result and two arguments are integers
        this->_help = "Does translation";
    }
    void
    execute(xmlrpc_c::paramList const& paramList,
            xmlrpc_c::value *   const  retvalP) {

        const params_t params = paramList.getStruct(0);
        paramList.verifyEnd(1);
        params_t::const_iterator si = params.find("text");
        if (si == params.end()) {
          throw xmlrpc_c::fault(
            "Missing source text",
            xmlrpc_c::fault::CODE_PARSE);
        }
        const string source((xmlrpc_c::value_string(si->second)));

        TranslationTask translationTask(0, source);
        translationTask.Translate();
        std::string translation = translationTask.GetTranslation();

        map<string, xmlrpc_c::value> retData;
        pair<string, xmlrpc_c::value> text("text", xmlrpc_c::value_string(translation));
        retData.insert(text);

        *retvalP = xmlrpc_c::value_struct(retData);

    }
};



int
main(int ac, char* av[]) {

    God::Init(ac, av);

    try {
        xmlrpc_c::registry serviceRegistry;

    	xmlrpc_c::methodPtr const translator(new TranslateMethod);
        serviceRegistry.addMethod("translate", translator);

        xmlrpc_c::serverAbyss server(
            xmlrpc_c::serverAbyss::constrOpt()
            .registryP(&serviceRegistry)
            .portNumber(God::Get<int>("port"))
			.maxConn(40));


        server.run();
        // xmlrpc_c::serverAbyss.run() never returns
        assert(false);
    } catch (exception const& e) {
        cerr << "Something failed.  " << e.what() << endl;
    }
    return 0;
}
