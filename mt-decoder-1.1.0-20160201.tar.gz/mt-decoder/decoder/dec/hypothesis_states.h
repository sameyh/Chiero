#pragma once

#include <vector>
#include "dec/ff/feature_function.h"
#include "dec/god.h"

namespace herbal {

/**
 * @brief: Container class for feature function states of a hypothesis
 */
class HypothesisStates {
  public:
   
    /**
     * @brief Constructor
     */
    HypothesisStates() {
      for(auto& ff : God::GetFFs())
        states_.push_back(ff->EmptyState());
    }
    
    /**
     * @brief Set the state of specific feature function
     *
     * @param i feature function index
     * @param ffstate state to set as new value
     */
    void SetState(size_t i, FFStatePtr ffstate) {
      states_[i] = ffstate;
    }
    
    /**
     * @brief Get the state of specific feature function
     *
     * @param i feature function index
     *
     * @return State at for feature function i
     */
    FFStatePtr GetState(size_t i) {
      return states_[i];
    }
    
    /**
     * @brief Calculate hash value for all states
     *
     * @param seed intial external hash value
     */
    size_t HashCombine(size_t seed) {
      for(auto& state : states_)
        seed = state->HashCombine(seed);
      return seed;
    }
    
  private:
    // @TODO get rid of this vector in favor of pools, this is probably a
    // performance bottle-neck in multi-threading (Repeated blocking
    // memory-allocation)
    std::vector<FFStatePtr> states_;
};

}