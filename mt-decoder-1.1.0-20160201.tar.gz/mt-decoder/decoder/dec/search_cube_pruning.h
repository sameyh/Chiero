#pragma once

#include "dec/search.h"

namespace herbal {

class Sentence;

/**
 * @brief Cube pruning search algorithm
 *
 * Separate class that performs the main decoding steps using the Cube Pruning
 * algorithm.
 */
class SearchCubePruning : public Search {
  public:
  
    /**
     * @param The main decoding function.
     *
     * Fills the stacks with translation hypotheses. 
     *
     * @param sentence Input sentence object
     * @param translationOptions Translation options for all source ranges and
     * heuristic penalties used to guide the search.
     */
    void Decode(Sentence& sentence,
                const TranslationOptions& translationOptions);
};

}
