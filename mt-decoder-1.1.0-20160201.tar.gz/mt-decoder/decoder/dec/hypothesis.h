#pragma once

#include "pt/target_phrase.h"
#include "dec/coverage.h"
#include "dec/hypothesis_states.h"
#include "dec/source_range.h"

namespace herbal {

class Hypothesis;
typedef Hypothesis* HypothesisPtr;

/**
 * @brief Cube coordinates for cube pruning
 */
struct CubeCoord {
    CubeCoord(const size_t tx, const size_t ty)
        : x(tx), y(ty) {}
  size_t x;
  size_t y;
};

/**
 * @brief Main class for hypothesis calculation and extension
 *
 * Every translation step is encoded as a hypothesis. Hypotheses always point
 * back to their parent hypothesis. Transaltion and decoding is scoring of
 * hypothesis extensions. 
 *
 */
class Hypothesis {
  public:
    
    /**
     * @brief Constructor for empty hypothesis
     *
     * @param length Source sentence size
     */
    Hypothesis(size_t length)
    : cost_(0.0), restCost_(0.0),
      prevHyp_(nullptr), currentTargetPhrase_(nullptr),
      coverage_(length),
      cubeCoord_(0,0), hash_(0)
    {}

    /**
     * @brief Constructor for extending hypothesis
     *
     * @param h Previous hypothesis
     * @param tp Target phrase used to extend the hypothesis and prodce the
     * current one. 
     */
    Hypothesis(const HypothesisPtr& h, const TargetPhrasePtr& tp)
    : cost_(h->GetCost()), restCost_(0.0),
      prevHyp_(h), currentTargetPhrase_(tp),
      coverage_(h->GetCoverage()),
      cubeCoord_(0,0), hash_(0)
    {
      cost_ += tp->GetScores()[0];

      size_t start = tp->GetRange()->Start();
      size_t end   = tp->GetRange()->End();
      coverage_.SetCovered(start, end);

      for (auto& ff : God::GetFFs()) {
        size_t ffindex = ff->GetIndex();
        float ffscore = ff->Score(h->GetState(ffindex), tp, GetState(ffindex));
        cost_ += ffscore;
      }

      // Hash coverage and states for recombination
      hash_ = 0;
      hash_ = coverage_.HashCombine(hash_);
      hash_ = states_.HashCombine(hash_);
    }

    /**
     * @return Parent hypothesis used to construct the current one.
     */
    const HypothesisPtr& PrevHypothesis() const {
      return prevHyp_;
    }

    /**
     * @return target phrase used to extend the current hypothesis.
     */
    const TargetPhrasePtr& CurrTargetPhrase() const {
      return currentTargetPhrase_;
    }

    /**
     * @return The source word coverage vector.
     */
    const Coverage& GetCoverage() const {
      return coverage_;
    }

    /**
     * @return The current accurate cost.
     */
    float GetCost() const {
      return cost_;
    }

    /**
     * @return The estimated rest cost.
     */
    float GetRestCost() const {
      return restCost_;
    }

    /**
     * @return The total cost used for search.
     */
    float TotalCost() const {
      return GetCost() + GetRestCost();
    }

    /**
     * @brief Set the rest cost.
     */
    void SetRestCost(float restCost) {
      restCost_ = restCost;
    }
    
    /**
     * @param i The feature function index.
     *
     * @return The vector of current feature function states.
     */
    FFStatePtr GetState(size_t i) {
      return states_.GetState(i);
    }

    /**
     * @return The vector of current feature function states.
     */
    HypothesisStates& GetStates() {
      return states_;
    }

    /**
     * @brief Return the precalculated hash value for this hypothesis.
     */
    size_t Hash() {
      return hash_;
    }

    /**
     * @brief Get the cube pruning coordinates.
     */
    CubeCoord& GetCubeCoords() {
      return cubeCoord_;
    }

    /**
     * @brief Set the cube pruning coordinates.
     */
    void SetCubeCoords(size_t x, size_t y) {
      cubeCoord_ = {x, y};
    }

    /**
     * @brief Prints a hypothesis to a stream, for debugging.
     */
    template <class OStream>
    friend OStream& operator<<(OStream& o, const Hypothesis& hyp) {
      o << hyp.hash_ << " (" << hyp.cubeCoord_.x << "," << hyp.cubeCoord_.y << ") : ";

      if(hyp.currentTargetPhrase_ != 0)
        o << *hyp.currentTargetPhrase_ << "||| ";
      else
        o << "NULL ||| ";

      o << hyp.GetCost() << " " << hyp.TotalCost() << " ||| "
        << hyp.coverage_;
      return o;
    }


  private:
    float cost_;
    float restCost_;

    const HypothesisPtr prevHyp_;
    const TargetPhrasePtr currentTargetPhrase_;

    Coverage coverage_;
    HypothesisStates states_;

    CubeCoord cubeCoord_;

    size_t hash_;
};

}
