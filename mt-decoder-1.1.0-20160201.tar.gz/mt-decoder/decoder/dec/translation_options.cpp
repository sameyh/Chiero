#include "dec/translation_options.h"
#include "dec/god.h"
#include "lm/ngram.h"
#include "pt/paste.h"

namespace herbal {

TranslationOptions::TranslationOptions(const Sentence& sentence)
 : sentence_(sentence)
{
  size_t len = sentence_.Length();
  wordRanges_.resize(len, std::vector<SourceRangePtr>(len));
  CollectTranslationOptions();
  CalculateFutureScores();
}

void TranslationOptions::CollectTranslationOptions() {
  const size_t max_phrase_length = God::Get<size_t>("max-phrase-length");
  for(size_t i = 0; i < sentence_.Length(); ++i) {
    for(size_t l = 0; l < max_phrase_length && i + l < sentence_.Length(); ++l) {
      lm::NGram source(sentence_.GetSource().data() + i, l + 1);
      TargetPhrases tps = God::GetTranslationModel()(source);
#ifdef DEBUG
      std::cerr << i << " " << i+l << " : ";
      for(auto& w : source) {
        std::cerr << w << " (" << God::GetVocab()[w] << ") ";
      }
      std::cerr << std::endl;
      for(auto& tp : tps) {
        std::cerr << "\t" << TargetPhraseVocab(*tp, God::GetVocab()) << std::endl;
      }
#endif
      if(tps.size() > 0) {
        wordRanges_[i][i + l] = God::Create<SourceRange>();
        wordRanges_[i][i + l]->SetRange(i, i + l, &sentence_.GetSource());
        wordRanges_[i][i + l]->SetTargetPhrases(tps);
      }
    }
  }
}

float TranslationOptions::GetFutureScorePerCoverage(const Coverage& coverage) const {
  float restCost = 0;
  size_t start = coverage.FirstGap();
  while(start < coverage.GetSize()) {
    if(!coverage.IsCovered(start)) {
      size_t end = start + 1;
      while(end < coverage.GetSize() && !coverage.IsCovered(end))
        end++;
      restCost += (*this)(start, end-1)->GetFutureScore();
      start = end;
    }
    else
      start++;
  }
  return restCost;
}

float TranslationOptions::GetFutureScorePerCoverage(const Coverage& coverage,
                                                    size_t exStart, size_t exEnd) const {
  float restCost = 0;
  size_t start = coverage.FirstGap();
  while(start < coverage.GetSize()) {
    if(!coverage.IsCovered(start) && (start < exStart || start > exEnd)) {
      size_t end = start + 1;
      while(end < coverage.GetSize() && !coverage.IsCovered(end))
        end++;
      restCost += (*this)(start, end-1)->GetFutureScore();
      start = end;
    }
    else
      start++;
  }
  return restCost;
}

const Ranges& TranslationOptions::GetRanges(const HypothesisPtr& hyp) {
  size_t hash = hyp->GetCoverage().Hash();
  auto it = rangesCache_.find(hash);
  if(it == rangesCache_.end()) {
    size_t length = this->GetSentence().Length();
    const Coverage& coverage = hyp->GetCoverage();

    size_t firstGap = 0;
    if(coverage.NumCovered() == 0) {
      // Handle BOS
      rangesCache_[hash].emplace_back(0, 0);
    }
    else if(coverage.NumCovered() == length - 1) {
    // Handle EOS
      rangesCache_[hash].emplace_back(length - 1, length - 1);
    }
    else {
      // @TODO: check impact of "first gap" vs. "end"
      int distortionLimit = God::Get<size_t>("distortion");
      size_t hypEnd = hyp->CurrTargetPhrase()->GetRange()->End();
      firstGap = hyp->GetCoverage().FirstGap();
      for(size_t start = firstGap; start < length - 1; ++start) {
        if(hyp->GetCoverage().IsCovered(start))
          continue;
        if(abs(hypEnd - start + 1) <= distortionLimit) {
          for(size_t end = start; end < length - 1; ++end) {
            if(!(*this)(start, end)->GetTargetPhrases().empty()) {
              if(!hyp->GetCoverage().IsCovered(start, end)) {
                if(firstGap == start)
                  rangesCache_[hash].emplace_back(start, end);
                // make sure there are no gaps that cannot be filled later
                else if (abs(end - firstGap + 1) <= distortionLimit)
                  rangesCache_[hash].emplace_back(start, end);
              }
            }
          }
        }
      }
    }
    return rangesCache_[hash];
  }
  else
    return it->second;
}

float TranslationOptions::GetFutureScore(size_t start, size_t length) {
  if(wordRanges_[start][length] == nullptr)
    wordRanges_[start][length] = God::Create<SourceRange>();
  return wordRanges_[start][length]->GetFutureScore();
}

void TranslationOptions::SetFutureScore(size_t start, size_t length, float score) {
  wordRanges_[start][length]->SetFutureScore(score);
}

void TranslationOptions::CalculateFutureScores() {
  for(size_t length = 1; length < sentence_.Length(); ++length) {
    for(size_t start = 0; start < sentence_.Length() - length; ++start) {
      size_t end = start + length;
      for(size_t i = start; i < end; ++i) {
        float ffs1 = GetFutureScore(start, i);
        float ffs2 = GetFutureScore(i + 1, end);
        float costSum = ffs1 + ffs2;
        if(costSum > GetFutureScore(start, end))
          SetFutureScore(start, end, costSum);
      }
    }
  }
}

}
