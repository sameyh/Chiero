#include "dec/stack_cube_pruning.h"

namespace herbal {
  
Partition::Partition(const Coverage& coverage, size_t start, size_t end,
                     const TranslationOptions& translationOptions)
: start_(start), end_(end), translationOptions_(translationOptions), restCost_(0.0) {
  SetFutureScorePerCoverage(coverage, start_, end_);
}

void Partition::SetFutureScorePerCoverage(const Coverage& coverage, size_t exStart, size_t exEnd) { 
  restCost_ = translationOptions_.GetFutureScorePerCoverage(coverage, exStart, exEnd);
}

HypothesisPtr Partition::Best() {
  const TargetPhrases& targetPhrases = translationOptions_(start_, end_)->GetTargetPhrases();
  if(!prevHyps_.empty() && !targetPhrases.empty()) {
    HypothesisPtr hyp00 = God::Create<Hypothesis>(const_cast<const HypothesisPtr&>(prevHyps_[0]), targetPhrases[0]);
    hyp00->SetCubeCoords(0, 0);
    hyp00->SetRestCost(restCost_);
#ifdef DEBUG
    std::cerr << "Creating best: " << *hyp00 << std::endl;
    std::cerr << "         from: " << *prevHyps_[0] << std::endl;
    std::cerr << "         and:  " << *targetPhrases[0] << std::endl;
#endif
    return hyp00;
  }
  return HypothesisPtr(0);
}

void Partition::QueueNeighbours(const HypothesisPtr& hyp, Queue& queue) {
#ifdef DEBUG
    std::cerr << "Neighbours of: " << *hyp << std::endl;
#endif
  auto& coords = hyp->GetCubeCoords();
  const TargetPhrases& targetPhrases = translationOptions_(start_, end_)->GetTargetPhrases();
  if(coords.y + 1 < targetPhrases.size()) {
    HypothesisPtr hypXYp1 = God::Create<Hypothesis>(prevHyps_[coords.x], targetPhrases[coords.y + 1]);
    hypXYp1->SetCubeCoords(coords.x, coords.y + 1);
    hypXYp1->SetRestCost(restCost_);

#ifdef DEBUG
    std::cerr << "Creating neig: " << *hypXYp1 << std::endl;
    std::cerr << "         from: " << *prevHyps_[coords.x] << std::endl;
    std::cerr << "         and:  " << *targetPhrases[coords.y + 1] << std::endl;
    std::cerr << "Queueing: " << *hypXYp1 << std::endl;
#endif
    queue.push(hypXYp1);
  }
  if(coords.x + 1 < prevHyps_.size()) {
    HypothesisPtr hypXp1Y = God::Create<Hypothesis>(prevHyps_[coords.x + 1], targetPhrases[coords.y]);
    hypXp1Y->SetCubeCoords(coords.x + 1, coords.y);
    hypXp1Y->SetRestCost(restCost_);
#ifdef DEBUG
    std::cerr << "Creating neig: " << *hypXp1Y << std::endl;
    std::cerr << "         from: " << *prevHyps_[coords.x + 1] << std::endl;
    std::cerr << "         and:  " << *targetPhrases[coords.y] << std::endl;
    std::cerr << "Queueing: " << *hypXp1Y << std::endl;
#endif
    queue.push(hypXp1Y);
  }
}

void Partition::Insert(HypothesisPtr& hyp) {
  prevHyps_.push_back(hyp);
}

const HypothesisPtr& Queue::top() {
  return queue_.top();
}

void Queue::pop() {
  return queue_.pop();
}

void Queue::push(const HypothesisPtr& hyp) {
  auto it = bestCosts_.find(hyp->Hash());
  if(it == bestCosts_.end() || it->second < hyp->TotalCost()) {
    queue_.push(hyp);
    bestCosts_[hyp->Hash()] = hyp->TotalCost();
  }
}

bool Queue::empty() {
  return queue_.empty();
}

void StackCubePruning::DivideIntoPartitions(const TranslationOptions& translationOptions) {
  for(auto& hyp : stack_) {
    for(const Range& range : const_cast<TranslationOptions&>(translationOptions).GetRanges(hyp)) {
      size_t hash = hyp->GetCoverage().Hash();
      boost::hash_combine(hash, range.first);
      boost::hash_combine(hash, range.second);
      auto it = partitions_.find(hash);
      if(it == partitions_.end())
        it = partitions_.emplace(hash,
                                 std::move(Partition(hyp->GetCoverage(), range.first, range.second, translationOptions))).first;
      it->second.Insert(hyp);
    }
  }
}

Partitions& StackCubePruning::GetPartitions() {
  return partitions_;
}

void StackCubePruning::QueueNeighbours(const HypothesisPtr& hyp, Queue& queue) {
  size_t hash = hyp->PrevHypothesis()->GetCoverage().Hash();
  size_t start = hyp->CurrTargetPhrase()->GetRange()->Start();
  size_t end = hyp->CurrTargetPhrase()->GetRange()->End();
  boost::hash_combine(hash, start);
  boost::hash_combine(hash, end);
  auto it = partitions_.find(hash);
  if(it != partitions_.end())
    it->second.QueueNeighbours(hyp, queue);
}

}
