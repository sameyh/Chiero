#pragma once

#include <vector>
#include <tuple>
#include <queue>
#include <unordered_map>

#include "util/pdqsort.h"
#include "dec/hypothesis.h"
#include "dec/translation_options.h"

namespace herbal {
  
  /**
   * @brief Main stack for searching, used in Stack-decoding and as a base-class
   * in Cube-pruning.
   */
  class Stack {
    public:
      typedef std::vector<HypothesisPtr> vector_type;

      /**
       * @brief Add hypothesis to current stack
       *
       * @param h The current hypothesis.
       * @return True if successful.
       */
      bool Insert(HypothesisPtr h);
      
      /**
       * @brief Return the current best hypothesis
       *
       * @return Best hypothesis
       */
      HypothesisPtr Best() const;
      
      /**
       * @brief Checks if stack is empty.
       *
       * @return True if stack is empty.
       */
      bool Empty() const;

      vector_type::const_iterator begin() const;
      vector_type::const_iterator end() const;

      /**
       * @brief Performs hypothesis recombination and prunes stack to size. 
       */
      void Prune();
      
      /**
       * @brief Returns number of hypotheses in stack.
       *
       * @return Number of hypothesis in stack.
       */
      size_t GetSize();

    protected:    
      void SortAndRecombine();
      void SortAndPrune();

      vector_type stack_;
  };

  typedef std::shared_ptr<Stack> StackPtr;
  typedef std::vector<StackPtr> Stacks;
}
