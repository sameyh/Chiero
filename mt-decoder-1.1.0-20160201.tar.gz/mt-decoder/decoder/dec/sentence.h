#pragma once

#include "lm/vocab.h"
#include "util/string_piece.h"

namespace herbal {

/**
 * @brief Class that holds sentence-related information
 *
 * This class contains the string version of the sentence to be translated,
 * a tokenized verson, a version mapped to word ids, and finally a translation.
 */
class Sentence {
  public:
    friend class Search;
    
    typedef std::vector<lm::Word> source_type;
    typedef std::vector<std::pair<lm::Word, size_t>> translation_type;
   
    /**
     * @brief Constructor
     *
     * @param line String version of to-be-translated input sentence
     */
    Sentence(const std::string& line);
    
    /**
     * @return The word id sequence version of the source sentence
     */
    const source_type& GetSource() const;
    
    /**
     * @return The original string version of the source
     */
    const std::string& GetSourceString() const;
    
    /**
     * @return The word id version of the 1-best translation
     */
    const translation_type& GetTranslation() const;
    
    /**
     * @return The string version of the 1-best translation
     */
    const std::string GetTranslationString() const;
    
    /**
     * @return the length of the source sentence in tokens
     */
    size_t Length() const;
    
  private:
    
    const std::string line_;
    std::vector<util::StringPiece> lineTokens_;
    source_type source_;
    translation_type target_;
};

}