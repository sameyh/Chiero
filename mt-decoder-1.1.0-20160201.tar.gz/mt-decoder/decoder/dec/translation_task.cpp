#include "dec/translation_task.h"

#include "dec/god.h"
#include "dec/search_cube_pruning.h"
#include "dec/search_stack_decoding.h"

namespace herbal {

TranslationTask::~TranslationTask() {
  God::Purge();
}

TranslationTask::TranslationTask(size_t no, const std::string& line)
: no_(no),
  sentence_(line),
  translationOptions_(sentence_) {}

void TranslationTask::Translate() {
  std::cerr << "Translating line " << no_ << " : "
    << sentence_.GetSourceString() << std::endl;
  
  switch ((SearchType) God::Get<size_t>("search")) {
    case SearchType::CubePruning :
      Decode<SearchCubePruning>();
      break;
    case SearchType::StackDecoding :
      Decode<SearchStackDecoding>();
      break;
    default:
      Decode<SearchCubePruning>();
      break;
  }
}

const std::string TranslationTask::GetTranslation() const {
  return sentence_.GetTranslationString();    
}

}
