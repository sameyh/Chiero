#pragma once

#include <limits>

#include "pt/target_phrase.h"
#include "pt/targets.h"
#include "lm/vocab.h"

namespace herbal {

  typedef std::vector<lm::Word> RawSentence;
  
  class SourceRange {
    public:
      SourceRange()
      : sourceStart_(0), sourceEnd_(0), sourceSentence_(0),
        restCost_(-std::numeric_limits<float>::infinity()) {}

      void SetRange(size_t start, size_t end, const RawSentence* sourceSentence) {
        sourceStart_ = start;
        sourceEnd_ = end;
        sourceSentence_ = sourceSentence;
      }

      float GetFutureScore() const {
        return restCost_;
      }

      const TargetPhrases& GetTargetPhrases() const {
        return targetPhrases_;
      }

      void SetFutureScore(float score) {
        restCost_ = score;
      }

      void SetTargetPhrases(TargetPhrases tps) {
        targetPhrases_ = tps;
        for(auto& tp : targetPhrases_)
          tp->SetRange(this);
        restCost_ = 0;
        restCost_ += targetPhrases_.front()->GetScores()[0];
        restCost_ += targetPhrases_.front()->GetScores()[1];
      }

      size_t Start() const {
        return sourceStart_;
      }

      size_t End() const {
        return sourceEnd_;
      }

      const lm::Word* begin() const {
          return &(*sourceSentence_)[sourceStart_];
      }

      const lm::Word* end() const {
          return &(*sourceSentence_)[sourceEnd_ + 1];
      }

      const RawSentence* GetSentence() const {
        return sourceSentence_;
      }

    private:
      size_t sourceStart_;
      size_t sourceEnd_;
      const RawSentence* sourceSentence_;
      float restCost_;
      TargetPhrases targetPhrases_;
  };
  
  typedef SourceRange* SourceRangePtr;
}
