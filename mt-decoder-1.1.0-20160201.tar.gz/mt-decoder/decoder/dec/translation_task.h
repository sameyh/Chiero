#pragma once

#include <vector>

#include "dec/sentence.h"
#include "dec/translation_options.h"
#include "lm/vocab.h"

namespace herbal {

/**
 * @brief Class for managing a single deocding task
 */
class TranslationTask {
  public:
    /**
     * @brief Constructor
     *
     * @param no Running number of translations
     * @param line String representation of input to be translated
     */
    TranslationTask(size_t no, const std::string& line);
    
    /**
     * @brief Destructor
     */
    ~TranslationTask();
    
    /**
     * @brief Run the translation process
     */
    void Translate();
        
    /**
     * @brief Retrieve final 1-best translation as string
     */
    const std::string GetTranslation() const;
    
  private:
    template <class Search>
    void Decode() {
      Search search;
      search.Decode(sentence_, translationOptions_);
      search.BackTrack(sentence_);
    }
 
    size_t no_;
    Sentence sentence_;
    TranslationOptions translationOptions_;
};

}
