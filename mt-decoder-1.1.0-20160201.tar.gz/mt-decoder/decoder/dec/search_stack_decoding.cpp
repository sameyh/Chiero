#include "dec/search_stack_decoding.h"

namespace herbal {

void SearchStackDecoding::Decode(Sentence& sentence,
                                 const TranslationOptions& translationOptions) {
  
  HypothesisPtr empty(God::Create<Hypothesis>(sentence.Length()));
  stacks_.resize(sentence.Length() + 1);
  for(auto& stack : stacks_)
    stack.reset(new Stack());
  stacks_.front()->Insert(empty);
  
  size_t sno = 0;
  for(auto& stack : stacks_) {
    stack->Prune();
#ifdef DEBUG
    std::cerr << sno << std::endl;
#endif
    for(auto& hyp : *stack) {
#ifdef DEBUG
      std::cerr << *hyp << std::endl;
#endif
      for(auto& range : const_cast<TranslationOptions&>(translationOptions).GetRanges(hyp)) {
        const TargetPhrases& targetPhrases
          = translationOptions(range.first, range.second)->GetTargetPhrases();
        for(auto& tp : targetPhrases) {
          HypothesisPtr newHyp = God::Create<Hypothesis>(hyp, tp);
          float restCost = translationOptions.GetFutureScorePerCoverage(newHyp->GetCoverage());
          newHyp->SetRestCost(restCost);
#ifdef DEBUG
          std::cerr << "\t" << *newHyp << std::endl;
#endif
          stacks_[newHyp->GetCoverage().NumCovered()]->Insert(newHyp);
        }  
      }
    }
    sno++;
  }
}

}

