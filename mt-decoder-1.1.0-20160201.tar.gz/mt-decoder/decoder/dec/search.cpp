#include "dec/search.h"

namespace herbal {

void Search::BackTrackRec(const HypothesisPtr& hyp,
                          Sentence& sentence) {
  if(hyp->PrevHypothesis() != nullptr) {
    BackTrackRec(hyp->PrevHypothesis(), sentence);
  }
  if(hyp->CurrTargetPhrase() != nullptr) {
    TargetPhrasePtr tp = hyp->CurrTargetPhrase();
#ifdef DEBUG
    std::cerr << *hyp << std::endl;
#endif
    for(auto& w : tp->GetPhrase()) {
      sentence.target_.emplace_back(w, tp->GetRange()->Start());
#ifdef DEBUG
      std::cerr << w << " (" << tp->GetRange()->Start() << ") "; 
#endif
    }
#ifdef DEBUG
    std::cerr << std::endl; 
#endif
  }
}

void Search::BackTrack(Sentence& sentence) {
  if(!stacks_.back()->Empty()) {
    HypothesisPtr best = stacks_.back()->Best();
#ifdef DEBUG
    std::cerr << "Backtracking: " << std::endl;
#endif
    BackTrackRec(best, sentence);
  }
}
  
}

