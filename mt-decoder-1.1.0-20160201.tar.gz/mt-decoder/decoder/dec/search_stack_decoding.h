#pragma once

#include "dec/search.h"

namespace herbal {

class Sentence;

/**
 * @brief Stack decoding search algorithm
 *
 * Separate class that performs the main decoding steps using the Stack decoding
 * algorithm.
 */
class SearchStackDecoding : public Search {
  public:
  
    /**
     * @brief Decoding function for stack-decoding implementation.
     *
     * @param sentence Input sentence object
     * @param translationOptions Translation options for all source ranges and
     * heuristic penalties used to guide the search.
     */
    void Decode(Sentence& sentence,
                const TranslationOptions& translationOptions);
};

}
