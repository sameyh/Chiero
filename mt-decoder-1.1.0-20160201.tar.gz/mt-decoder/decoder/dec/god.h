#pragma once

#include <memory>
#include <boost/program_options.hpp>

#include "util/pools.h"
#include "dec/ff/ff_factory.h"

namespace po = boost::program_options;

namespace herbal {

  namespace lm {
    class CHDVocab;
    class LanguageModel;
  }
  class Paste;

  /**
   * @brief Static god class
   *
   * Class containing configuration data and models, initialization procedures
   * and memory pools. Follows the pattern of a singleton "God class", hence
   * the name. The only instance is static. 
   */
  class God {
    public:
      /**
       * brief Default constructor
       */
      God();
      
      // Dont't allow copying or moving. This is a singleton class
      God(const God&) = delete;
      God(God&&) = delete;

      /**
       * @brief Access to the static single instance of God
       *
       *  @return An instance of God
       */
      static God& Summon() {
        return instance_;
      }
      
      /* Parameters and configuration******************************************/

      /**
       * @brief Read initialization information from string
       *
       * Calls Init(int argc, char** argv) after splitting the parameter
       *
       * @param initString A string with command line options
       */
      static God& Init(const std::string& initString);
      
      /**
       * @brief Read initialization information from c-style input
       *
       * Calls NonStaticInit(int argc, char** argv)
       *
       * @param argc Number of arguments
       * @param argv Array of arguments
       */
      static God& Init(int argc, char** argv);
      
      /**
       * brief Check if the configuration parameter exists
       *
       * @param key Name of the parameter
       *
       * @return true if exists, false otherwise
       */
      static bool Has(const std::string& key) {
        return instance_.vm_.count(key) > 0;
      }

      /**
       * brief Return the value of the specified configuration parameter
       *
       * The expected type of the parameter needs to specified as a template
       * argument as different parameters can have different underlying types. 
       *
       * @param key Name of the parameter
       *
       * @return Value of the specified parameter. 
       */
      template <typename T>
      static T Get(const std::string& key) {
        return instance_.vm_[key].as<T>();
      }

      /**
       * @brief Prints information about all set parameters to stderr
       */
      static void PrintConfig() {
        PrintConfig(std::cerr);
      }

      /**
       * @brief Prints information about all set parameters to specified stream
       *
       * @param out Output stream for printing
       */
      static void PrintConfig(std::ostream& out) {
        for(auto& entry: instance_.vm_) {
          out << entry.first << " = ";
          try { out << entry.second.as<std::string>(); } catch(...) { }
          try { out << entry.second.as<size_t>(); } catch(...) { }
          try { out << entry.second.as<bool>(); } catch(...) { }
          out << std::endl;
        }
      }

      /* Models and feature functions *****************************************/

      /**
       * @brief Access to the common vocabulary object
       *
       * All models and feature functions make use of a common word-id based
       * vocabulary. This function gives access to a map, that alllows to map
       * from and to that vocabulary. Used for converting input to the internal
       * representation and for outputting translations.
       *
       * @return the vocabulary
       */
      static lm::CHDVocab& GetVocab();
      
      /**
       * @brief Access to the list of used feature funtions
       *
       * All these features are stateful, i.e. their values are calculated in
       * context of the previous hypothesis.
       *
       * @return a vector of feature functions pointers
       */
      static std::vector<FeatureFunctionPtr>& GetFFs();
      
      /**
       * @brief Access to translation model
       *
       * The translation model is the only stateless feature function and
       * therefore has a special interface. It also provides the decoder with
       * translations.
       *
       * @return A phrase table
       * 
       */
      static Paste& GetTranslationModel();

      /* Memory pools *********************************************************/
      
      /**
       * @brief Thread-local non-blocking allocation of objects.
       *
       * The idea is to avoid calls to "new Object" as memory allocation with
       * new is a blocking operation htat can severly decresase the performance
       * of multi-threading applications.
       *
       * Call, for instance, like:
       *
       * TargetPhrase* tp = God::Create<TargetPhrase>(...)
       *
       * Objects created by this function are destroyed automatically after
       * a sentence has been translated. There is no inter-sentence persistence.
       * Objects do not need to be destroyed explicitly.
       *
       * @param args Any number of parameters that needs to be passed to a
       * constructor of the created object.
       *
       * @return A pointer to the created object.
       */
      template <typename T, class ...Args>
      static T* Create(Args&& ...args) {
        initPools();
        return pools_->Construct<T>(std::forward<Args>(args)...);
      }
      
      
      /**
       * @brief Thread-local non-blocking allocation of continuous memory
       *
       * @param length Number of bytes to allocate.
       *
       * @return Pointer to allocated memory.
       */
      template <class T>
      static T* Memory(size_t length) {
        initPools();
        return (T*)pools_->Memory(length * sizeof(T));
      }

      static void* Memory(size_t length) {
        initPools();
        return pools_->Memory(length);
      }
    
      /**
       * @brief Free all objects and memory that has been allocated with Create
       * and Memory.
       *
       * This destroys and frees thread-specific memory and objects created with
       * pool based methods. Objects created in other threads are not affected. 
       *
       * Only called after the completion of a sentence translation. 
       */
      static void Purge() {
        initPools();
        pools_->ClearAll();
      }

    private:      
      God& NonStaticInit(int argc, char** argv);

      inline static void initPools() {
        if(!pools_)
          pools_.reset(new Pools());
      }

      static God instance_;
      po::variables_map vm_;

      std::unique_ptr<lm::CHDVocab> vocab_;
      std::unique_ptr<Paste> tm_;

      std::vector<FeatureFunctionPtr> ffs_;
      FFFactory fffactory_;

      util::Blob blob_;
      
      static thread_local std::unique_ptr<Pools> pools_;
  };

}
