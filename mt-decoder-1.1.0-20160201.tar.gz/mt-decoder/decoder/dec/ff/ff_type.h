#pragma once

#include <cstdint>

namespace herbal {

    /**
     * @brief The list of all feature functions.
     *
     * The order of feature functions should not be changed.
     * This ENUM is used in recognising what FF is in blob.
     *
     * @see FFFactory
     *
     */
    enum class FFType : uint8_t {
        PhraseTable,
        LanguageModel,
        LexicalReorderingModel,
        DistortionPenalty,
        WordClassLanguageModel,
        OperationSequenceModel,
    };
}
