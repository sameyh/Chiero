#include "dec/ff/ff_language_model.h"

#include "lm/language_model.h"
#include "lm/wc_language_model.h"
#include "dec/ff/ff_type.h"
#include "dec/god.h"

using namespace herbal;

FFLanguageModelState::FFLanguageModelState(lm::LanguageModel::state_type state)
    : state_(std::move(state)) {
}

FFLanguageModelState::FFLanguageModelState() {
}

lm::LanguageModel::state_type& FFLanguageModelState::Get() {
    return state_;
}

size_t FFLanguageModelState::HashCombine(size_t seed) const {
    for(auto w : *state_)
        boost::hash_combine(seed, w);
    return seed;
}

FFLanguageModel::FFLanguageModel(size_t index,
                const std::vector<float>& weights,
                std::unique_ptr<lm::LanguageModel>&& lm)
: FeatureFunction(index, weights, FFType::LanguageModel), lm_(std::move(lm)) {}

FeatureFunctionPtr FFLanguageModel::Load(
              const size_t& index,
              const std::vector<float>& weights,
              util::Blob& blob) {
    std::unique_ptr<lm::LanguageModel> lmPtr(new lm::LanguageModel());
    blob >> *lmPtr;
    return FeatureFunctionPtr(new FFLanguageModel(index, weights, std::move(lmPtr)));
}

FeatureFunctionPtr FFLanguageModel::LoadWCLM(
    const size_t& index,
    const std::vector<float>& weights,
    util::Blob& blob) {
  std::unique_ptr<lm::WCLanguageModel> lmPtr(new lm::WCLanguageModel());
  blob >> *lmPtr;
  return FeatureFunctionPtr(new FFLanguageModel(index, weights, std::move(lmPtr)));
}

float FFLanguageModel::Score(
        FFStatePtr state,
        TargetPhrasePtr tp,
        FFStatePtr next) const {

    lm::LanguageModel::state_type& stateLM
        = static_cast<FFLanguageModelStatePtr>(state)->Get();
    lm::LanguageModel::state_type& nextLM
        = static_cast<FFLanguageModelStatePtr>(next)->Get();

    float lmScore = 0;
    lm::LanguageModel::state_type* statePtr = &stateLM;
    for (auto w : tp->GetPhrase()) {
        lm::LanguageModel::state_type nextState = lm_->NewState();
        //std::cerr << "w: " << w << std::endl;
        // EVIL!
        float prob = lm_->Query(w, *statePtr, &nextState);
        if(w != 1)
            lmScore += prob;
        //std::cerr << "lm: " << lmScore << std::endl;
        std::swap(nextLM, nextState);
        statePtr = &nextLM;
    }

    std::swap(nextLM, *statePtr);
    return lmScore * GetWeights()[0];
}

FFStatePtr FFLanguageModel::EmptyState() const {
    FFLanguageModelStatePtr state = God::Create<FFLanguageModelState>();
    state->Get() = lm_->NewState();
    return state;
}


