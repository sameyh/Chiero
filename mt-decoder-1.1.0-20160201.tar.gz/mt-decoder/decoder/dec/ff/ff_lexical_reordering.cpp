#include "dec/ff/ff_lexical_reordering.h"

#include "dec/source_range.h"
#include "dec/ff/ff_type.h"

#include "util/exception.h"

using namespace herbal;

FFLexicalReorderingState::FFLexicalReorderingState() : start_(0), end_(0) {
}

size_t FFLexicalReorderingState::HashCombine(size_t seed) const {
    boost::hash_combine(seed, start_);
    boost::hash_combine(seed, end_);
    for (auto& score: scores_) {
        boost::hash_combine(seed, score);
    }
    return seed;
}

size_t FFLexicalReorderingState::GetStart() const {
    return start_;
}

size_t FFLexicalReorderingState::GetEnd() const {
    return end_;
}

void FFLexicalReorderingState::Update(const size_t& start, const size_t& end, const LRScores<float>& scores)
{
    start_ = start;
    end_ = end;
    scores_ = scores;
}

LRScores<float>& FFLexicalReorderingState::GetScores() {
    return scores_;
}

FeatureFunctionPtr FFLexicalReorderingModel::Load(const size_t& index, const std::vector<float>& weights, util::Blob& blob) {
    std::unique_ptr<LexicalReorderingModel> lrPtr(new LexicalReorderingModel());
    blob >> *lrPtr;
    return FeatureFunctionPtr(new FFLexicalReorderingModel(index, weights, std::move(lrPtr)));
}

FFLexicalReorderingModel::FFLexicalReorderingModel(
        size_t index,
        const std::vector<float>& weights,
        std::unique_ptr<LexicalReorderingModel>&& lrModel)
      : FeatureFunction(index, weights, FFType::LexicalReorderingModel), lrModel_(std::move(lrModel)) {
          // herbal::util::THROW_IF(weights.size() != 1, "LR Models requires exactly one weight.");
}

FFStatePtr FFLexicalReorderingModel::EmptyState() const {
    FFLexicalReorderingStatePtr state = God::Create<FFLexicalReorderingState>();
    return state;
}

float FFLexicalReorderingModel::Score(
        FFStatePtr state,
        TargetPhrasePtr tp,
        FFStatePtr next) const {
    FFLexicalReorderingStatePtr lrState =
        static_cast<FFLexicalReorderingStatePtr>(state);
    FFLexicalReorderingStatePtr lrNextState =
        static_cast<FFLexicalReorderingStatePtr>(next);

    std::vector<lm::Word> sWords;
    std::vector<lm::Word> tWords;
    std::vector<lm::Word> lrKey;

    size_t start = tp->GetRange()->Start();
    size_t end = tp->GetRange()->End();

    for (size_t i = start; i <= end; ++i) {
        sWords.push_back(tp->GetRange()->GetSentence()->at(i));
    }

    for (auto tWord: tp->GetPhrase()) {
        tWords.push_back(tWord);
    }

    lrModel_->MakeKey(sWords, tWords, lrKey);

    LRScores<float> lrScores = lrModel_->GetScores(lrKey);

    float score = 0.0;
    if (tp->GetPhrase()[0] != lm::wEOS) {
    score += lrScores.ScoreBackward(lrState->GetStart(), lrState->GetEnd(),
                                    start, end);
    score += lrState->GetScores().ScoreForward(lrState->GetStart(), lrState->GetEnd(),
                                                start, end);
    }
    // score *= this->GetWeights()[0];

    lrNextState->Update(start, end, lrScores);
    return score;
}
