#pragma once

#include "dec/ff/feature_function.h"
#include "dec/source_range.h"
#include "pt/weights.h"

namespace herbal {

    /**
     * @brief Distortion Penalty FF State
     */
  class FFDistortionPenaltyState : public FFState {
    public:
        /**
         * @brief Constructor
         *
         * @param state Index of this state.
         */
      FFDistortionPenaltyState(int state);

      /**
       * @brief Set state (index).
       *
       * @param state
       */
      void Set(int state);

      /**
       * @brief Get state
       *
       * @return  State.
       */
      int Get() const;


      /**
       * @brief Compute a new hash with this state.
       *
       * @param seed Hash of current hypothesis.
       *
       * @return  Hash of current hypothisis with this state.
       */
      size_t HashCombine(size_t seed) const;

    private:
      int state_;
  };

typedef FFDistortionPenaltyState* FFDistortionPenaltyStatePtr;

/**
 * @brief Distortion Penalty Feature Function
 */
class FFDistortionPenalty : public FeatureFunction {
    public:
        /**
         * @brief Constructor.
         *
         * @param index The index of this FF in FF list.
         * @param weights Weights of Distortion Penalty FF. It's should be
         *  always a one-element vector.
         */
        FFDistortionPenalty(size_t index,
                            const std::vector<float>& weights);


        /**
         * @brief Score the phrase.
         *
         * @param state Current state in hypothesis.
         * @param tp The phrase to score.
         * @param next The new state after join the phrase into hypothesis.
         *
         * @return Distortion Penalty score.
         */
        float Score(FFStatePtr state, TargetPhrasePtr tp,
                    FFStatePtr next) const;

        /**
         * @brief Loader of Distortion Penalty FF from a blob.
         *
         * @param index Index of this FF in FF sequence
         * @param weights A vector of weights.
         * @param blob Blob
         *
         * @return  Pointer to this FF.
         */
        static FeatureFunctionPtr Load(const size_t& index, const std::vector<float>& weights,  util::Blob& blob);


        /**
         * @brief Return the beginning state for Distortion Penalty.
         *
         * @param pool Pool of FFDistortionPenaltyStates.
         *
         * @return The beginnning state.
         */
        FFStatePtr EmptyState() const;
};
}
