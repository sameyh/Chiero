#pragma once

#include <iostream>
#include <string>

#include "pt/weights.h"
#include "dec/ff/feature_function.h"
#include "dec/god.h"

#include "lr/lr_scores.h"
#include "lr/lexical_reordering_model.h"

#include "util/blob.h"

namespace herbal {

class SourceRange;

/**
 * @brief Lexical Reordering State.
 */
class FFLexicalReorderingState: public FFState {
    public:
        FFLexicalReorderingState();

        /**
         * @brief Return a new hash containing this LRState.
         *
         * @param seed The previous hash.
         *
         * @return  A new hash containing this LRState.
         */
        size_t HashCombine(size_t seed) const;

        /**
         * @brief Get the start position of the previous phrase.
         *
         * @return The start postion of the previous phrase.
         */
        size_t GetStart() const;

        /**
         * @brief Return the end position of the previous phrase.
         *
         * @return  The end position of the previous phrase.
         */
        size_t GetEnd() const;

        /**
         * @brief Update LRState with new data.
         *
         * @param start Start position of a previous phrase
         * @param end End postion of a previous phrase
         * @param scores Scores of a previous phrase.
         */
        void Update(const size_t& start, const size_t& end, const LRScores<float>& scores);

        /**
         * @brief Return scores from LR of the previous phrase.
         *
         * The scores are needed in forward scoring.
         *
         * @return Scores from LR of the previous phrase.
         */
        LRScores<float>& GetScores();

    private:
        size_t start_;
        size_t end_;
        LRScores<float> scores_;

};

typedef FFLexicalReorderingState* FFLexicalReorderingStatePtr;

/**
 * @brief Lexical Reordering Feature Function.
 *
 */
class FFLexicalReorderingModel : public FeatureFunction {
    public:

        /**
         * @brief Constructor.
         *
         * @param index An index of FF.
         * @param weights A vector of weights of FF.
         * @param lrModel Lexical Reordering Model.
         */
      FFLexicalReorderingModel(
        size_t index,
        const std::vector<float>& weights,
        std::unique_ptr<LexicalReorderingModel>&& lrModel);
        /**
         * @brief Loader of FF.
         *
         * @param index index of FF.
         * @param weights weights of FF.
         * @param blob The source.
         *
         * @return Pointer to FF.
         */
      static FeatureFunctionPtr Load(
              const size_t& index,
              const std::vector<float>& weights,
              util::Blob& blob);

      /**
       * @brief Create the first LR State which contains zeros as
       * scores from Lexical Reordering Model.
       *
       * @param pool
       *
       * @return The first LR State.
       */
      FFStatePtr EmptyState() const;

      /**
       * @brief Score phrase using Lexical Reordering Model.
       *
       * For more details of, see "A Simple and Effective Hierarchical
       * Phrase Reordering Model" of M. Galley and C. Manning.
       *
       * @param state The previous state.
       * @param tp The phrase to score.
       * @param next The next state.
       *
       * @return  The score of Lexical Reordering Model.
       */
      float Score(
              FFStatePtr state,
              TargetPhrasePtr tp,
              FFStatePtr next) const;

    private:
        std::unique_ptr<LexicalReorderingModel> lrModel_;
};

}
