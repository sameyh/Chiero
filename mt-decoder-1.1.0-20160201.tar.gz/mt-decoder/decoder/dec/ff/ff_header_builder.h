#pragma once

#include <vector>

#include "dec/ff/ff_type.h"
#include "dec/ff/ff_header.h"

#include "util/scoped_file.h"
#include "util/blob.h"

namespace herbal {

    /**
     * @brief Builder of FFHeader.
     */
class FFHeaderBuilder : public util::Blob {
    public:

        /**
         * @brief Constructor
         *
         * @param ffType FFType to be included in FFHeader.
         * @param  weights A vector of weights to be includded in FFHeader.
         */
        FFHeaderBuilder(const FFType ffType, const std::vector<float>& weights)
            : ffType_(ffType),
              weights_(weights) {
        }

        /**
         * @brief Constructor
         *
         * @param A header to write.
         */
        FFHeaderBuilder(const FFHeader& header)
            : ffType_(header.GetFFtype()),
              weights_(header.GetWeights()) {
        }

        /**
         * @brief Write the FFHeader to a given ScopedFile.
         *
         * @param sf ScopedFile to write FFHeader.
         *
         * @return  True if all information were written.
         */
        bool Write(util::ScopedFile& sf) {
            sf << static_cast<uint8_t>(ffType_);
            sf << uint64_t(weights_.size());
            for (auto& weight : weights_) {
                sf << weight;
            }
            return true;
        }

        /**
         * @brief Write the FFHeader to a given ScopedFile.
         *
         * @param sf ScopedFile to write FFHeader.
         *
         * @return  True if all information were written.
         */
        FFHeaderBuilder& operator>>(util::ScopedFile& sf) {
            Write(sf);
            return *this;
        }

    private:
    const FFType ffType_;
    const std::vector<float> weights_;

};

}
