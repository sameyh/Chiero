#pragma once

#include <memory>

#include "pt/target_phrase.h"
#include "dec/ff/ff_type.h"

namespace herbal {


    /**
     * @brief Feature Function State.
     */
    class FFState {
      public:

          /**
           * @brief Return the combination of given hash and the hash
           * of this FF state.
           *
           * @param seed the current hash.
           *
           * @return  The hash of the combination.
           */
        virtual size_t HashCombine(size_t seed) const = 0;
    };

    typedef FFState* FFStatePtr;
    
    /**
     * @brief Base class for feature functions.
     *
     * Every FF is stateful. In other words, FF has information about
     * the previous translated phrases.
     *
     */
    class FeatureFunction {
      public:

          /**
           * @brief Constructor.
           *
           * @param index The index of a FF.
           * @param weights Weights of FF.
           * @param ffType Type of FF. @see FFType.
           */
        FeatureFunction(const size_t index,
                        const std::vector<float>& weights,
                        const FFType ffType)
        : index_(index), weights_(weights), ffType_(ffType) {}

        /**
         * @brief The main method of FF. It scores a given phrase having
         * information about the history of translation.
         *
         * @param FFStatePtr Previous FF state.
         * @param TargetPhrasePtr The phrase to score.
         * @param FFStatePtr the new FF state of adding this phrase.
         *
         * @return The score of the FF of the given phrase. It's multiplied
         * by weights.
         */
        virtual float Score(FFStatePtr,
                            TargetPhrasePtr,
                            FFStatePtr) const = 0;

        /**
         * @brief This generate the first state in the zero hypothesis.
         *
         * @return The first FF state.
         */
        virtual FFStatePtr EmptyState() const = 0;

        /**
         * @brief Get the index of FF.
         *
         * @return The index of FF.
         */
        virtual size_t GetIndex() const {
          return index_;
        }


        /**
         * @brief Get the vector of weights.
         *
         * @return The weights of FF.
         */
        virtual const std::vector<float>& GetWeights() const {
          return weights_;
        }


        /**
         * @brief Get the type of FF. Every FF should know its own FF type.
         *
         * @return  FFType of FF.
         */
        virtual FFType GetFFType() const {
          return ffType_;
        }

      private:
        const size_t index_;
        const std::vector<float> weights_;
        const FFType ffType_;
    };

    typedef std::shared_ptr<FeatureFunction> FeatureFunctionPtr;

}
