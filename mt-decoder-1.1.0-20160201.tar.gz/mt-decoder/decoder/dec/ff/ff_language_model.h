#pragma once

#include "dec/ff/feature_function.h"

#include "lm/language_model.h"

namespace herbal {

  class FFLanguageModelState : public FFState {
    public:
      FFLanguageModelState(lm::LanguageModel::state_type state);

      FFLanguageModelState();

      lm::LanguageModel::state_type& Get();

      size_t HashCombine(size_t seed) const;

    private:
      lm::LanguageModel::state_type state_;
  };

  typedef FFLanguageModelState* FFLanguageModelStatePtr;

  class FFLanguageModel : public FeatureFunction {
    public:
      FFLanguageModel(size_t index,
                      const std::vector<float>& weights,
                      std::unique_ptr<lm::LanguageModel>&& lm);

      static FeatureFunctionPtr Load(
              const size_t& index,
              const std::vector<float>& weights,
              util::Blob& blob);

      static FeatureFunctionPtr LoadWCLM(
              const size_t& index,
              const std::vector<float>& weights,
              util::Blob& blob);

      float Score(FFStatePtr state, TargetPhrasePtr tp, FFStatePtr next) const;
      
      float QueryProb(const lm::NGram& ngram) {
        float prob = 0;
        float backoff = 0;
        bool found = false;
        lm_->Query(ngram, &prob, &backoff, &found);
        return prob;
      }

      FFStatePtr EmptyState() const;

    private:
      std::unique_ptr<lm::LanguageModel> lm_;
  };
}
