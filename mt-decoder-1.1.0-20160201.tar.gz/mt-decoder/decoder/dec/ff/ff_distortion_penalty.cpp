#include "dec/ff/ff_distortion_penalty.h"
#include "dec/ff/ff_type.h"
#include "dec/god.h"

using namespace herbal;

FFDistortionPenaltyState::FFDistortionPenaltyState(int state)
    : state_(state) {
}

void FFDistortionPenaltyState::Set(int state) {
    state_ = state;
}

int FFDistortionPenaltyState::Get() const {
    return state_;
}

size_t FFDistortionPenaltyState::HashCombine(size_t seed) const {
    boost::hash_combine(seed, state_);
    return seed;
}

FFDistortionPenalty::FFDistortionPenalty(
        size_t index,
        const std::vector<float>& weights)
    : FeatureFunction(index, weights, FFType::DistortionPenalty) {
}

float FFDistortionPenalty::Score(
        FFStatePtr state,
        TargetPhrasePtr tp,
        FFStatePtr next) const {
    int lastEnd = static_cast<FFDistortionPenaltyStatePtr>(state)->Get();

    float d = (float)lastEnd - (float)(tp->GetRange()->Start()) + (float)1;
    float dpScore = -fabs(d);

    static_cast<FFDistortionPenaltyStatePtr>(next)->Set(tp->GetRange()->End());
    return dpScore * GetWeights()[0];
}

FFStatePtr FFDistortionPenalty::EmptyState() const {
    return God::Create<FFDistortionPenaltyState>(-1);
}

FeatureFunctionPtr FFDistortionPenalty::Load(const size_t& index, const std::vector<float>& weights, util::Blob& blob) {
    return FeatureFunctionPtr(new FFDistortionPenalty(index, weights));
}
