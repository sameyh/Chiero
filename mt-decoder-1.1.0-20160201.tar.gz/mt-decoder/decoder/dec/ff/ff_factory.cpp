#include "dec/ff/ff_factory.h"
#include <cstddef>
#include <iostream>

#include "dec/ff/ff_distortion_penalty.h"
#include "dec/ff/ff_language_model.h"
#include "dec/ff/ff_lexical_reordering.h"
#include "dec/ff/ff_type.h"
#include "dec/ff/ff_header.h"

using namespace herbal;

FFFactory::FFFactory() {
    RegisterFF_(FFType::DistortionPenalty, FFDistortionPenalty::Load);
    RegisterFF_(FFType::LexicalReorderingModel, FFLexicalReorderingModel::Load);
    RegisterFF_(FFType::LanguageModel, FFLanguageModel::Load);
    RegisterFF_(FFType::WordClassLanguageModel, FFLanguageModel::LoadWCLM);
}

FeatureFunctionPtr FFFactory::Load(const size_t& index, util::Blob& blob) {
    FFHeader ffHeader;
    blob >> ffHeader;
#ifdef DEBUG
    std::cerr <<"FF: " << (uint32_t)ffHeader.GetFFtype() << std::endl;
    for(auto w : ffHeader.GetWeights())
        std::cerr << "w: " << w << std::endl;
#endif
    return ffMap_[ffHeader.GetFFtype()](index, ffHeader.GetWeights(), blob);
}

void FFFactory::RegisterFF_(const FFType ffType, FFLoader loader) {
    ffMap_[ffType] = loader;
}

