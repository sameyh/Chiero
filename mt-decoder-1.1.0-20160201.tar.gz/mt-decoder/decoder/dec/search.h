#pragma once

#include "dec/stack.h"

namespace herbal {

class Sentence;

enum class SearchType : size_t { CubePruning, StackDecoding };

/**
 * @brief Cube pruning search algorithm
 *
 * Abstract base class for search algorithms.
 */
class Search {
  public:
  
    /**
     * @param The main decoding function, search algorithms need to override
     * this. 
     *
     * @param sentence Input sentence object
     * @param translationOptions Translation options for all source ranges and
     * heuristic penalties used to guide the search.
     */
    virtual void Decode(Sentence& sentence,
                        const TranslationOptions& translationOptions) = 0;
    
    /**
     * @brief Finds the 1-best translation in the stacks. Common for stack-based
     * search algorithms like Stack-decoding and Cube-pruning. 
     *
     * @param sentence The source sentence that will be filled with the 1-best
     * translation.
     */
    virtual void BackTrack(Sentence& sentence);
    
  protected:
    virtual void BackTrackRec(const HypothesisPtr& hyp, Sentence& sentence);
  
    Stacks stacks_;
};

}
