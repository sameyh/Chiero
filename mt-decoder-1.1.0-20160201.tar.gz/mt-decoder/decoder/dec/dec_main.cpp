#include <iostream>
#include <string>
#include <queue>
#include <thread>
#include <mutex>
#include <boost/program_options.hpp>

#include "dec/god.h"
#include "dec/translation_task.h"
#if defined(PROFILING)
#include <gperftools/profiler.h>
#endif


using namespace herbal;

typedef std::pair<size_t, std::string> Item;
struct ItemSorter {
  bool operator()(const Item& a, const Item& b) { return a.first > b.first; }
};
typedef std::priority_queue<Item, std::vector<Item>, ItemSorter> Queue;

Item GetItem(bool& hadData, Queue& inQueue, std::mutex& inMutex) {
  std::lock_guard<std::mutex> lock(inMutex);
  Item item;
  if(!inQueue.empty()) {
    item = inQueue.top();
    inQueue.pop();
    hadData = true;
  }
  return item;
}

void PutItem(Item item, Queue& outQueue, std::mutex& outMutex, size_t& last) {
  std::lock_guard<std::mutex> lock(outMutex);
  outQueue.push(item);

  while(outQueue.top().first == last + 1) {
    std::cout << outQueue.top().second << std::endl;
    last++;
    outQueue.pop();
  }
}

void translate(Queue& inQueue, std::mutex& inMutex,
               Queue& outQueue, std::mutex& outMutex,
               size_t& last) {
  bool hadData;
  do {
    hadData = false;
    Item inItem = GetItem(hadData, inQueue, inMutex);
    if(hadData) {
      TranslationTask translationTask(inItem.first, inItem.second);
      translationTask.Translate();

      Item outItem = inItem;
      outItem.second = translationTask.GetTranslation();

      PutItem(outItem, outQueue, outMutex, last);
    }
  } while(hadData);
}

int main(int argc, char** argv) {
#if defined(PROFILING)
    ProfilerStart("dec.profiling.out");
#endif
    God::Init(argc, argv);

    Queue inQueue;
    std::mutex inMutex;
    Queue outQueue;
    std::mutex outMutex;

    std::string line;
    size_t no = 1;
    while(std::getline(std::cin, line)) {
      inQueue.emplace(no, line);
      no++;
    }

    size_t last = 0;
    size_t threadNum = God::Get<size_t>("threads");
    std::vector<std::thread> threads;
    for(size_t i = 0; i < threadNum; ++i) {
      threads.emplace_back(translate,
                           std::ref(inQueue), std::ref(inMutex),
                           std::ref(outQueue), std::ref(outMutex),
                           std::ref(last));
    }
    for(auto& t: threads)
      t.join();

#if defined(PROFILING)
    ProfilerStop();
#endif
    return 0;
}
