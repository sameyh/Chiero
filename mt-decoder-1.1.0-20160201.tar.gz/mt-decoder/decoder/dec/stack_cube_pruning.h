#pragma once

#include "dec/stack.h"


namespace herbal {
  
  struct CostSorterQueue {
    bool operator()(const HypothesisPtr& a, const HypothesisPtr& b) const {
      return a->TotalCost() < b->TotalCost();
    }
  };

  class Queue {
    public:
      const HypothesisPtr& top();
      void pop();
      void push(const HypothesisPtr& hyp);
      bool empty();

    private:
      std::priority_queue<HypothesisPtr, std::vector<HypothesisPtr>, CostSorterQueue> queue_;
      std::unordered_map<size_t, float> bestCosts_;
  };

  class Partition {
    public:
      Partition(const Coverage& coverage, size_t start, size_t end, const TranslationOptions& translationOptions);
      void SetFutureScorePerCoverage(const Coverage& coverage, size_t exStart, size_t exEnd);
      HypothesisPtr Best();
      void QueueNeighbours(const HypothesisPtr& hyp, Queue& queue);
      void Insert(HypothesisPtr& hyp);

    private:
      size_t start_;
      size_t end_;
      const TranslationOptions& translationOptions_;
      float restCost_;
      std::vector<HypothesisPtr> prevHyps_;
  };

  typedef std::unordered_map<size_t, Partition> Partitions;

  class StackCubePruning : public Stack {
    public:

      void DivideIntoPartitions(const TranslationOptions& translationOptions);
      Partitions& GetPartitions();
      void QueueNeighbours(const HypothesisPtr& hyp, Queue& queue);

    private:    
      Partitions partitions_;
  };
}
