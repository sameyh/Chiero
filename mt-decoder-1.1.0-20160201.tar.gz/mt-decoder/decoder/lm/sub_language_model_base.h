#pragma once

#include "util/blob.h"
#include "lm/payload.h"
#include "lm/ngram.h"

namespace herbal {
  namespace lm {
    
    /**
     * @brief Abstract base class for sub language models
     */
    class SubLanguageModelBase : public util::Blobbed {
      public:
        virtual Payload GetPayload(const NGram&, bool*) const = 0;
        virtual ~SubLanguageModelBase() {}
      
      protected:
        virtual void MapBlob(util::Blob&) = 0;
    };
  }
}
