#pragma once

#include "util/blob.h"
#include "lm/payload.h"
#include "lm/sub_language_model_base.h"

// @TODO: Handle sparse vocabulary

namespace herbal {
  namespace lm {

     /**
     * @brief Order-specifc typed sub language model for unigrams.
     *
     *  Order-specifc typed language model for unigrams. Since unigrams can be
     *  accessed by using word ids instead of n-gram hashes, this sublm for
     *  unigrams does not need a hash function. Hence the specialization.
     *  
     *  This is the lowest level in the language model structure.
     *  Not to be used directly. 
     */
    template<class PayloadLocal>
    class TypedSubLanguageModelUnigram : public SubLanguageModelBase {
      public:
        typedef PayloadLocal payload_type;
        
          /**
         * @brief Retreive payload (probability, backoff weight)
         *
         * @param key N-gram for which the payload should be retrieved
         * @param found Whether the n-gram has been found in the sub-lm
         */
        inline Payload GetPayload(const NGram& key, bool* found) const {
          const payload_type *p;
          GetPayload(key, &p, found);
          return Payload(p->GetProb(), p->GetBackoff());
        }
        
      private:
        template <class Key,
                  template <typename> class PayloadNoPrint,
                  typename Float>
        void inline GetPayload(const Key& key, const PayloadNoPrint<Float>** p,
                        bool* found) const {
          *found = true; // <unk> is always found
          size_t index = *key.data();
          //if (index == 0)
          //  *found = false;
          *p = payloads_.data() + index;
        }

        void MapBlob(util::Blob& blob) {
          blob >> keys_;
          blob >> payloads_(keys_);
        }

        util::Chunk64 keys_;
        util::ManyChunks<PayloadLocal> payloads_;
    };
  }
}
