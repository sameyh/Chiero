#pragma once

#include <limits>
#include "lm/vocab.h"

namespace herbal {
  namespace lm {

    /**
     * @brief Abstract base class for language model states
     *
     * For a detailed discussion of language model state see: Kenneth Heafield's
     * PHD thesis: "Efficient Language Modeling Algorithms with Applications to
     * Statistical Machine Translation"
     */
    class State {
      public:
        virtual ~State() {};
        virtual void Combine(const State&, Word) = 0;
        virtual void Combine(const std::unique_ptr<State>&, Word) = 0;
        virtual void Minimize(size_t) = 0;
        virtual const Word* data() const = 0;
        virtual size_t size() const = 0;
        virtual const Word* begin() const = 0;
        virtual const Word* end() const = 0;
        virtual float* GetBackoffs() = 0;
        virtual float GetBackoff(size_t) const = 0;
        virtual void Set(size_t, size_t, Word) = 0;
        virtual size_t F() const = 0;
    };
  
    /**
     * @brief Fixed-length language model state
     *
     * N-gram language models are used with states of type TypedState<N>. 
     */
    template <size_t N>
    class TypedState : public State {
      public:
        
        /**
         * @brief Default constructor
         */
        TypedState() : f_(N) {
          std::fill(b_, b_ + N - 1, std::numeric_limits<float>::infinity());
        }
           
        /**
         * @brief Save prefetched i-th backoff weight
         *
         * @param i backoff weight index
         * @param b backoff weight value
         */
        inline void SetBackoff(size_t i, float b) {
          b_[i] = b;
        }
        
        /**
         * @brief Retrieve prefetched i-th backoff weight
         *
         * @param i backoff weight index
         * 
         * @return backoff weight value
         */
        inline float GetBackoff(size_t i) const {
          return b_[i];
        }
        
        /**
         * @brief Retrieve array of backoff weights
         *
         * @return pointer to sequence of backoff weights
         */
        inline float* GetBackoffs() {
          return b_;
        }
        
        /**
         * @brief Retrieve array of words in current state
         *
         * @return Array of words in current minimal state
         */
        inline const Word* data() const {
          return w_ + f_;
        }
        
        /**
         * @brief Retrieve size of state
         *
         * @return Number words in current minimal state
         */
        inline size_t size() const {
          return N - f_;
        }

        /**
         * @brief Accessor to starting iterator
         */
        inline const Word* begin() const {
          return w_ + f_;
        }
        
        /**
         * @brief Accessor to iterator end
         */
        inline const Word* end() const {
          return w_ + N;
        }
        
        /**
         * @brief Set i-th word in state and found state length
         *
         * @param i word index in state
         * @param f offset for found state
         * @param w current word to be set in state
         */
        inline void Set(size_t i, size_t f, Word w) {
          w_[i] = w;
          f_ = f;
        }
        
        /**
         * @return Offset for this state
         */
        inline size_t F() const {
          return f_;
        }
        
        /**
         * @brief Extend state by one word
         *
         * Turns the current state into an extension of the previous state by
         * one word. The previous state is not changed.
         *
         * @param prevState The previous state.
         * @param w The word to be used for right-sided extension.
         */
        inline void Combine(const State& prevState, Word w) {
          // assume there are no n-grams of form "x <unk>"
          if(w != wUNK) {
            f_ = prevState.F() - 1;
            std::copy(prevState.data(), prevState.data() + prevState.size(),
                      w_ + f_);
          }
          else {
            f_ = N - 1;
          }
          w_[N - 1] = w;
        }
        
        /**
         * @brief Extend state by one word
         *
         * Turns the current state into an extension of the previous state by
         * one word. The previous state is not changed.
         *
         * @param prevState The previous state.
         * @param w The word to be used for right-sided extension.
         */
        inline void Combine(const std::unique_ptr<State>& prevState, Word w) {
          Combine(*prevState.get(), w);
        }
        
        /**
         * @brief Minimize state length based on backoff weight values
         *
         * The new state is of size nSize or smaller if there are left-side
         * padded 0-valued backoffs. The first position corresponding to the
         * first non-zero value will be used as state beginning. 
         *
         * @param nSize the maximum length of the state
         */
        inline void Minimize(size_t nSize) {
          // assume there are no n-grams of form "x <unk>"
          if(w_[N - 1] == wUNK)
            f_ = N;
          else
            f_ = (N == nSize) ? 1 : N - nSize;
          // minimize state according to 0 backoffs
          while(f_ < N && b_[N - f_ - 1] == 0)
            f_++;
        }
        
        /**
         * @brief For comparing states
         */
        bool operator==(const TypedState& other) {
          return f_ == other.f_
            && std::memcmp(data(), other.data(), size() * sizeof(Word)) == 0;
        }

      private:
        size_t f_;
        Word  w_[N];
        float b_[N - 1];
    };
  
  }
}