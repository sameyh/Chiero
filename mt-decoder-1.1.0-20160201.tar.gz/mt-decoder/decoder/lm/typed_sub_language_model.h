#pragma once

#include "util/blob.h"
#include "lm/payload.h"
#include "lm/ngram.h"
#include "hash/chd.h"

#include "lm/sub_language_model_base.h"

// @TODO: Handle sparse vocabulary

namespace herbal {
  namespace lm {

    /**
     * @brief Order-specifc typed sub language model
     *
     *  Order-specifc typed language model, contains only n-grams of one size.
     *  This is the lowest level in the language model structure.
     *  Not to be used directly. 
     */
    template<class PayloadLocal>
    class TypedSubLanguageModel : public SubLanguageModelBase {
      public:
        typedef PayloadLocal payload_type;
        
        /**
         * @brief Retreive payload (probability, backoff weigh)
         *
         * @param key N-gram for which the payload should be retrieved
         * @param found Whether the n-gram has been found in the sub-lm
         *
         */
        inline Payload GetPayload(const NGram& key, bool* found) const {
          const payload_type *p;
          GetPayload(key, &p, found);
          return Payload(p->GetProb(), p->GetBackoff());
        }
        
      private:
        template <class Key,
                  template <typename, typename> class PayloadWithPrint,
                  typename Print, typename Float>
        void inline GetPayload(const Key& key, const PayloadWithPrint<Print, Float>** p,
                        bool* found) const {
          HashTuple ht;
          Murmur::Hash(hash_.GetSeed(), key, ht);
              
          size_t index = hash_[ht];
          *p = payloads_.data() + index;
          *found = (*p)->PrintMatches(ht.p);
        }

        void MapBlob(util::Blob& blob) {
          blob >> keys_;
          blob >> hash_;
          blob >> payloads_(keys_);
        }

        CHD<Murmur> hash_;
        util::Chunk64 keys_;
        util::ManyChunks<PayloadLocal> payloads_;
    };
  }
}
