#pragma once

#include "lm/ngram.h"
#include "util/blob.h"
#include "lm/builder/ngram_iterator.h"

namespace herbal {
  namespace lm {
    
    class NGramBlob : public util::Blob {
      public:
        
        typedef NGram value_type;
        
        NGramBlob(size_t order) : util::Blob(), order_(order) {};
        NGramBlob(util::ScopedFile &sf, size_t order) : util::Blob(sf), order_(order) {};
        
        NGram operator[](size_t i) {
          size_t offset = sizeof(typename value_type::value_type) * i * order_;
          return NGram((typename value_type::value_type*)(util::Blob::data() + offset), order_);
        }
        
        NGram operator[](size_t i) const {
          return (*this)[i];
        }
        
        NGramIterator begin() {
          return NGramIterator((typename value_type::value_type*)util::Blob::begin(), order_);
        }
        
        NGramIterator end() {
          return NGramIterator((typename value_type::value_type*)util::Blob::end(), order_);
        }
        
        NGramIterator begin() const {
          return NGramIterator((typename value_type::value_type*)util::Blob::begin(), order_);
        }
        
        NGramIterator end() const {
          return NGramIterator((typename value_type::value_type*)util::Blob::end(), order_);
        }
        
        size_t size() const {
          return util::Blob::size() / (sizeof(typename value_type::value_type) * order_);
        }
        
      private:
        size_t order_;
    };

  }
}