#include <iostream>
#include <cstdio>
#include <memory>
#include <sstream>
#include <boost/program_options.hpp>

#include "util/scoped_file.h"
#include "lm/vocab.h"
#include "lm/builder/arpa_parser.h"

using namespace herbal;

int main(int argc, char** argv) {
  namespace po = boost::program_options;
  po::options_description cmdline_options("Allowed options");

  bool help = false;
  bool binary = false;

  cmdline_options.add_options()
    ("binary,b", po::value(&binary)->zero_tokens()->default_value(false),
     "Create and dump binary vocab file")
    ("help,h", po::value(&help)->zero_tokens()->default_value(false),
     "Print this help message and exit")
  ;

  po::variables_map vm;
  try {
    po::store(po::command_line_parser(argc,argv).
              options(cmdline_options).run(), vm);
    po::notify(vm);
  }
  catch (std::exception& e) {
    std::cout << "Error: " << e.what() << std::endl << std::endl;

    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }

  if (help) {
    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }

  lm::GrowVocab vocab;
  lm::ARPAParser arpa(stdin, vocab);

  lm::ARPAGram arpaGram;
  // just loop through unigrams
  while(arpa >> arpaGram
        && arpaGram.Order() == 1);

  util::ScopedFile myStdout(stdout);
  if(binary) {
    lm::CHDVocabBuilder chdVocabBuilder(vocab.GetVocab());
    chdVocabBuilder >> myStdout;
  }
  else
    vocab.PrettyDump(myStdout);

  return 0;
}
