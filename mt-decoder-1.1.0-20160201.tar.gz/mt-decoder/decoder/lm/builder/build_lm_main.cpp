#include <iostream>
#include <cstdio>
#include <memory>
#include <sstream>
#include <fstream>
#include <boost/program_options.hpp>

#include "util/progress.h"

#include "lm/ngram.h"
#include "lm/vocab.h"

#include "lm/builder/arpa_parser.h"
#include "lm/builder/sublm_builder.h"

#include "dec/ff/ff_type.h"
#include "dec/ff/ff_header_builder.h"

using namespace herbal;

size_t binarizeClasses(const std::string& classesPath, const lm::ToWordVocab& vocab,
                     util::ScopedFile& sf) {
  std::ifstream in(classesPath.c_str());
  std::string key;
  lm::Word classId;
  std::vector<lm::Word> map(3, 0);

  map[0] = 0; // <unk>
  map[1] = 1; // <s>
  map[2] = 2; // </s>

  size_t maxCls = 0;
  while(in >> key >> classId) {
    //std::cerr << key << " " << classId << std::endl;
    size_t pos = vocab[key];
    if(pos < 3)
      continue;
    if(pos >= map.size())
      map.resize(pos + 1, 0);
    map[pos] = classId + 3;
    if(map[pos] > maxCls)
      maxCls = map[pos];
  }
  sf << (size_t)map.size();
  for(auto w : map) {
    sf << w;
  }
  return maxCls + 1;
}

int main(int argc, char** argv) {
  namespace po = boost::program_options;
  po::options_description cmdline_options("Allowed options");

  bool help = false;
  std::string extVoc;
  std::string outStr;
  std::string classes;
  std::vector<float> weights;
  bool osm = false;

  cmdline_options.add_options()
    ("output,o", po::value(&outStr)->required(), "Output file path")
    ("vocab,v", po::value(&extVoc)->required(), "Prebuilt vocabulary blob")
    ("classes", po::value(&classes), "Provide classes for class-based LM")
    ("osm", po::value(&osm)->zero_tokens()->default_value(false), "Treat as OSM")
    ("w,weights", po::value<std::vector<float>>(&weights)->required()->multitoken(), "LM weights")
    ("help,h", po::value(&help)->zero_tokens()->default_value(false),
     "Print this help message and exit")
  ;

  po::variables_map vm;
  try {
    po::store(po::command_line_parser(argc,argv).
              options(cmdline_options).run(), vm);
    po::notify(vm);
  }
  catch (std::exception& e) {
    std::cout << "Error: " << e.what() << std::endl << std::endl;

    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(1);
  }

  if (help) {
    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }

  util::Blob vocabBlob;
  util::ScopedFile vocabFile(extVoc);
  vocabBlob.Map(vocabFile);
  std::unique_ptr<lm::ToWordVocab> vocab(new lm::CHDVocab());
  vocabBlob >> *(lm::CHDVocab*)vocab.get();

  util::ScopedFile out(outStr, util::SF_WRITE);

  FFType ffType;
  if (classes.size() != 0) {
      ffType = FFType::WordClassLanguageModel;
      std::cerr << "WCLM\n";
  }
  else if (osm) {
      ffType = FFType::OperationSequenceModel;
      std::cerr << "OSM\n";
  }
  else {
      ffType = FFType::LanguageModel;
      std::cerr << "LM\n";
  }

  FFHeaderBuilder(ffType, weights) >> out;

  std::unique_ptr<lm::SubLMBuilderBase> subLMBuilder;

  if(classes.size() != 0) {
    size_t maxCls = binarizeClasses(classes, *vocab, out);
    vocab.reset(new lm::ClassIdVocab(maxCls));
  }

  if(osm) {
    vocab.reset(new lm::GrowVocab());
  }

  lm::ARPAParser arpa(stdin, *vocab);

  std::stringstream ss;
  ss << "Reading n-grams (total: " << arpa.GetTotal() << ")";
  std::unique_ptr<util::Progress> progress(new util::Progress(arpa.GetTotal(), ss.str()));

  out << arpa.MaxOrder();

  using OrderedUnigram = lm::OrderedPayload<lm::Payloads8F::payload_unigram>;
  using OrderedLower   = lm::OrderedPayload<lm::Payloads8F::payload_lower>;
  using OrderedHighest = lm::OrderedPayload<lm::Payloads8F::payload_highest>;

  lm::ARPAGram arpaGram;
  while(arpa >> arpaGram) {
    if(!subLMBuilder || arpaGram.Order() > subLMBuilder->Order()) {
      if(subLMBuilder) {
        if(subLMBuilder->Order() == 1 && arpa.NoUnk()) {
          lm::ARPAGram unkGram = arpa.UnkGram(*vocab);
          subLMBuilder->Append(unkGram);
        }
        *subLMBuilder >> out;
      }
      if(arpaGram.Order() == 1) {
        subLMBuilder.reset(
          new lm::SubLMBuilder<OrderedUnigram>(arpaGram.Order()));
      }
      else if(arpaGram.Order() == arpa.MaxOrder()) {
        subLMBuilder.reset(
          new lm::SubLMBuilder<OrderedHighest>(arpaGram.Order()));
      }
      else {
        subLMBuilder.reset(
          new lm::SubLMBuilder<OrderedLower>(arpaGram.Order()));
      }
    }
    subLMBuilder->Append(arpaGram);
    ++*progress;
  }

  if(subLMBuilder)
    *subLMBuilder >> out;

  std::cerr << "Success" << std::endl;
  return 0;
}
