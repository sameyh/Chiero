#pragma once

#include <algorithm>
#include <tuple>

#include "util/blob.h"
#include "lm/payload.h"
#include "lm/ngram.h"
#include "hash/chd.h"
#include "hash/chd_builder.h"
#include "util/merge_sort.h"

#include "lm/builder/ngram_blob.h"
#include "lm/sub_language_model.h"

namespace herbal {
namespace lm {

class SubLMBuilderBase {
  public:
    virtual SubLMBuilderBase& operator>>(util::ScopedFile& sf) = 0;
    virtual bool Write(util::ScopedFile& sf) = 0;
    virtual void Append(const ARPAGram& arpaGram) = 0;
    virtual size_t Order() = 0;
    virtual ~SubLMBuilderBase() {};
};

template<class OrderedPayloadT>
class SubLMBuilder : public util::Blob, public SubLMBuilderBase {
  public:
    SubLMBuilder(size_t order)
    : order_(order),
      ngrams_(new util::ScopedFile()),
      scores_(new util::ScopedFile()) {}

    void Append(const ARPAGram& arpaGram) {
      AppendData(arpaGram.data(), arpaGram.size());
      AppendProbBackoff(arpaGram.GetProb(), arpaGram.GetBackoff());
    }

    bool Write(util::ScopedFile& out) {
      Build(out);
      return true;
    }

    SubLMBuilder& operator>>(util::ScopedFile& sf) {
      Write(sf);
      return *this;
    }

    util::Blob& operator>>(util::Blobbed& blobbed) {
      mappedFile_.reset(new util::ScopedFile);
      Write(*mappedFile_);
      Map(*mappedFile_);
      return Blob::operator>>(blobbed);
    }

    size_t Order() {
      return order_;
    }

  private:
    void Build(util::ScopedFile& out) {
      util::TypedBlob<OrderedPayloadT> payloads(*scores_);
      out << (uint64_t)order_; // Save lm order to file
      
      BuildForPayload(payloads, out);
    }
    
    // Specialization for higher order models
    template <template <typename, typename> class Payload,
              typename Print, typename Float>
    void BuildForPayload(util::TypedBlob<OrderedPayload<Payload<Print,Float>>>& payloads,
                         util::ScopedFile& out) {
      out << (uint64_t)payloads.size(); // Save number for keys to file;
      NGramBlob keys(*ngrams_, order_);
      
      CHDBuilder<Murmur> chd;
      chd.Build(keys, 0.9, false) >> out;

      CHD<Murmur> hash;
      chd >> hash;

      auto seed = hash.GetSeed();
      OrderedPayloadT* payloadIt = payloads.begin();
      for(auto& key : keys) {
        HashTuple ht;
        Murmur::Hash(seed, key, ht);
        
        payloadIt->SetIndex(hash[ht]);
        payloadIt->GetPayload().SetPrint(ht.p);
        ++payloadIt;
      }
      ngrams_.reset(nullptr);
   
      util::MergeSort(payloads.begin(), payloads.end(),
        util::ScopedFile::OutputIterator<Payload<Print,Float>>(out));
      scores_.reset(nullptr);
    }
    
    // Specialization for unigram models
    template <template <typename> class Payload,
              typename Float>
    void BuildForPayload(util::TypedBlob<OrderedPayload<Payload<Float>>>& payloads,
                         util::ScopedFile& out) {
      
      NGramBlob keys(*ngrams_, order_);
      auto payloadIt = payloads.begin();
      
      // sort unigram payloads by vocabulary id
      size_t keysSize = 0;
      Payload<Float> unkPayload;
      for(auto& key : keys) {
        Word w = key.data()[0];
        payloadIt->SetIndex(w);
        if(w == wUNK)
          unkPayload = payloadIt->GetPayload();
        ++payloadIt;
        if(w > keysSize)
          keysSize = w;
      }
      out << (uint64_t)(keysSize + 1); // Save number of keys to file;
      
      util::ScopedFile temp;
      util::MergeSort(payloads.begin(), payloads.end(),
        util::ScopedFile::OutputIterator<OrderedPayloadT>(temp));
      
      // output and fill empty places with payload from <unk>
      util::TypedBlob<OrderedPayloadT> tempPayloads(temp);
      util::ScopedFile::OutputIterator<Payload<Float>> outIt(out);
      uint32_t lastIndex = 0;
      for(auto& p : tempPayloads) {
        while(p.GetIndex() > lastIndex + 1) {
          outIt++ = unkPayload;
          lastIndex++;
        }
        lastIndex = p.GetIndex();
        outIt++ = p;
      }
    }
    
    template <typename T>
    void AppendData(T* data, size_t size) {
      ngrams_->Write((Byte*)data, size * sizeof(T));
    }

    void AppendProbBackoff(float prob, float backoff) {
      *scores_ << OrderedPayloadT(prob, backoff);
    }

    size_t order_;
    std::unique_ptr<util::ScopedFile> ngrams_;
    std::unique_ptr<util::ScopedFile> scores_;
};

}
}
