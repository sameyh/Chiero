#pragma once

#include <cstdio>
#include <vector>

#include "util/string_piece.h"
#include "hash/random_hash.h"
#include "lm/vocab.h"

namespace herbal {
namespace lm {

class ARPAGram {
  public:
    typedef Word value_type;
    
    //ARPAGram(const FromWordVocab& vocab)
    //: key_(false), vocab_(vocab) {}
    
    ARPAGram()
    : key_(false) {}
    
    void Clear() {
      words_.clear();
    }
    
    void Append(Word w) {  
      words_.push_back(w);
    }
    
    void SetProb(double prob) {
      prob_ = prob/log10(exp(1));
    }
    
    void SetBackoff(double backoff) {
      backoff_ = backoff/log10(exp(1));
    }
    
    void SetPos(size_t pos) {
      pos_ = pos;
    }
    
    size_t Size() const {
      return words_.size();
    }
    
    const Word* data() const {
      return words_.data();
    }
    
    const size_t size() const {
      return words_.size();
    }
    
    float GetProb() const {
      return prob_;
    }
    
    float GetBackoff() const {
      return backoff_;
    }
    
    size_t GetPos() const {
      return pos_;
    }
    
    size_t Order() const {
      return words_.size();
    }
    
    ARPAGram& Key() {
      key_ = true;
      return *this;
    }
    
  private:
    std::vector<Word> words_;
    size_t pos_;
    float prob_;
    float backoff_;
    bool key_;
    
  //  const FromWordVocab& vocab_;
  //  
  //friend std::ostream& operator<<(std::ostream& o, const ARPAGram& ngram) {
  //  if(!ngram.key_)
  //    o << ngram.prob_ << "\t";
  //  size_t c = 0;
  //  for(auto& w : ngram.words_) {
  //    o << ngram.vocab_[w];
  //    c++;
  //    
  //    if(c < ngram.words_.size())
  //      o << " ";
  //  }
  //  if(!ngram.key_)
  //    o << "\t" << ngram.backoff_;
  //  return o;
  //}
  
};  

class ARPAParser {
  public:
    ARPAParser(FILE* fPtr, ToWordVocab& vocab)
    : state_(Start), order_(0), c_(buffer_), read_(0), num_(0),
      fPtr_(fPtr), vocab_(vocab), noUnk_(true) {
      token_.reserve(100);
      ParseHeader();
    }
    
    ARPAParser& operator>>(ARPAGram& ngram) {
      NextNGram(ngram);
      return *this;
    }    
    
    operator bool() {
      return !Done();
    }
    
    bool Done() {
      return (AllRead() || state_ == End);
    }
    
    bool AllRead() {
      return (EoF() && c_ >= buffer_ + read_);
    }
    
    bool EoF() {
      return std::feof(fPtr_) != 0;
    }
    
    std::vector<size_t>& GetStats() {
      return stats_;
    }
    
    std::vector<size_t>& GetSeen() {
      return seen_;
    }
    
    size_t GetNum() {
      return num_;
    }
    
    size_t GetTotal() {
      size_t sum = 0;
      for(size_t i = 0; i < GetStats().size(); i++)
        sum += GetStats()[i];
      return sum;
    }
    
    size_t MaxOrder() {
      return GetStats().size();
    }
    
    template <class OStream>
    void Stats(OStream &out) {
      size_t sum1 = 0;
      size_t sum2 = 0;
      for(size_t i = 0; i < GetStats().size(); i++) {
        out << (i+1) << "-grams: " << GetSeen()[i] << "/" << GetStats()[i] << std::endl;
        sum1 += GetStats()[i];
        sum2 += GetSeen()[i];
      }
      out << "Total: " << sum1 << "/" << sum2 << std::endl;
    }
    
    bool NoUnk() {
      return noUnk_;
    }

    ARPAGram UnkGram(ToWordVocab& vocab) {
      ARPAGram unkGram;
      unkGram.Append(vocab["<unk>"]);
      unkGram.SetProb(0);
      unkGram.SetBackoff(0);
      return unkGram;
    }

  private:

    bool NextNGram(ARPAGram& ngram);
    bool ParseHeader();
        
    bool ParseStat();
    bool ParseNGram(ARPAGram& ngram);
    
    bool GetToken();
    void NextRead();
    
    std::vector<char> token_;  
    enum State { Start, BeforeStatOrNgram, GetStat,
      GetNGram, Prob, NGramToken, Backoff, Newline, End,
      Failure } state_;
    size_t order_;
    
    char buffer_[1024];
    char* c_;
    size_t read_;
    
    size_t num_;
    std::vector<uint64_t> stats_;
    std::vector<uint64_t> seen_;
    FILE* fPtr_;
    ToWordVocab& vocab_;
    bool noUnk_;
};

}
}
