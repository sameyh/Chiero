#include <iostream>
#include <cstdio>
#include <memory>
#include <set>

#include "util/scoped_file.h"
#include "lm/vocab.h"

using namespace herbal;

int main(int argc, char** argv) {
  std::ios_base::sync_with_stdio(false);
  
  std::set<std::string> strings;
  std::string line;
  while(std::getline(std::cin, line)) {
    if(line == "<s>" || line == "</s>" || line == "<unk>")
      continue;
    strings.insert(line);
  }
  
  lm::CHDVocabBuilder chdVocabBuilder(strings);
  util::ScopedFile scopedStdout(stdout);
  chdVocabBuilder >> scopedStdout;
  
  return 0;
}
