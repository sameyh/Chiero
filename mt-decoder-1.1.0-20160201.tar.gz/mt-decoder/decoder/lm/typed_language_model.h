#pragma once

#include <limits>
#include <memory>

#include "lm/language_model_base.h"
#include "lm/sub_language_model.h"
#include "lm/ngram.h"
#include "lm/payload.h"

#include "dec/god.h"

namespace herbal {
  namespace lm {
    
    
    /**
     * @brief Language model implementation for language model of order N
     *
     * Not to be used directly, use LanguageModel class instead. 
     */
    template<size_t N>
    class TypedLanguageModel : public LanguageModelBase {
      public:
        TypedLanguageModel() {}
        
        /**
         * @brief Language model querying without states by n-gram
         *
         * N-gram-based LM-querying function, mainly for diagnostic purposes,
         * not used during decoding. 
         *
         * @param ngram Queried n-gram
         * @param prob Found log-probability
         * @param backoff Found backoff weight
         * @param found Whether the given n-gram is present in the LM
         */
        void Query(const NGram &key, float* prob, float* bow, bool* found) {
          *found = false;
          size_t keySize = key.size();
          auto p = lms_[keySize - 1]->GetPayload(key, found);
          //if(*found) {
            *prob = p.GetProb();
            *bow = p.GetBackoff();
          //}
        }
        
        /**
         * @brief Language model querying with states
         *
         * Main LM-querying function for word-by-word extension of n-grams based
         * on previous state. 
         *
         * @param word Current word extending previous query
         * @param state Last language model states
         * @param nextState Next language model state, filled after querying the
         * current word
         *
         * @return N-Gram log-probability
         */
        float Query(Word word, const state_type& state, state_type* nextState) {
          (*nextState)->Combine(state, word);
          
          size_t matchedSize = 0;
          float prob = PessimisticQuery(nextState, &matchedSize);
#ifdef DEBUG
          //std::cerr << matchedSize << " " << (*nextState)->size() << " " << prob << std::endl;
#endif
          if(matchedSize < (*nextState)->size()) {
            prob += AddBackoffs(state, nextState, &matchedSize); 
          }
            
          (*nextState)->Minimize(matchedSize);
          return prob;
        }
        
        /**
         * @return Order of language model
         */
        constexpr size_t MaxOrder() const {
          return N;
        }

        /**
         * Returns common state for Begin-of-Sentence hypothesis. 
         */
        state_type& StateBOS() {
          return stateBOS_;
        }
        
        /**
         * Create empty state to-be-filled during querying. State type is
         * automatically destroyed when released.
         */
        state_type NewState() {
          return state_type(new TypedState<N>());
        }
        
        /**
         * Return probability of unknown word, used for future-score calculation.
         */        
        float UNK() {
          return Special(wUNK);
        }

        /**
         * Return probability of begin-of-sentence symbol, used for future-score
         * calculation.
         */
        float BOS() {
          return Special(wBOS);
        }
        
        /**
         * Return probability of end-of-sentence symbol, used for future-score
         * calculation.
         */
        float EOS() {
          return Special(wEOS);
        }
        
      private:

        float Special(Word w) {
          NGram unk(&w, 1);
          float prob, bow;
          bool found;
          Query(unk, &prob, &bow, &found);
          return prob;
        }

         
        inline float PessimisticQuery(state_type* nextState, size_t* matchedSize) {
          float prob = 0.0;
          
          bool found = true;
          size_t keySize = (*nextState)->size();
          while(found && *matchedSize < keySize) {
            NGram tempKey((*nextState)->data() + keySize - *matchedSize - 1,
                         *matchedSize + 1);
            QueryProb(lms_[*matchedSize], tempKey,
                      &prob, (*nextState)->GetBackoffs(), &found);
            if(found)
              ++*matchedSize;
          }
#ifdef DEBUG
          //std::cerr << "pq:" << prob << std::endl;
#endif
          return prob;
        }
        
        inline float AddBackoffs(const state_type& state,
                                 const state_type* nextState,
                                 size_t* matchedSize) {
          float prob = 0.0;
          size_t origMatchedSize = *matchedSize;
          size_t keySize = (*nextState)->size();
          //std::cerr << "ks: " << keySize << std::endl;
          float inf = std::numeric_limits<float>::infinity();
          for(size_t j = 0; j < keySize - origMatchedSize; j++) {
            //std::cerr << "j: " << j << std::endl;
            float backoff = state->GetBackoff(keySize - j - 2);
            //std::cerr << "b: " << backoff << std::endl;
            if(backoff == inf) {
              NGram backoffKey((*nextState)->data() + j, keySize - 1);
              QueryBackoff(lms_[backoffKey.size() - 1], backoffKey, &backoff);
            }
#ifdef DEBUG
            //std::cerr << "b: " << backoff << std::endl;
#endif
            prob += backoff;
          }
          return prob;
        }
        
        template <class LM, class Key>
        inline void QueryProb(const LM& lm, const Key& key,
                        float* prob, float* backoffs, bool* found) {
          *found = false;
          size_t keySize = key.size();
          auto p = lm->GetPayload(key, found);
          if(*found || keySize == 1) {
            *prob = p.GetProb();
            if(keySize < N)
              backoffs[key.size() - 1] = p.GetBackoff();
          }
          else
            std::fill(backoffs + keySize - 1, backoffs + N - 1, 0.0);
        }
        
        template <class LM, class Key>
        inline void QueryBackoff(const LM& lm, const Key& key, float* backoff) {
          bool found = false;
          auto p = lm->GetPayload(key, &found);
          if(found)
            *backoff = p.GetBackoff();
          else
            *backoff = 0.0;
        }
        
        void MapBlob(util::Blob& blob) {
          for(size_t i = 0; i < N; ++i) {
            lms_[i].reset(new SubLanguageModel(N));
            blob >> *lms_[i];
          }
          InitializeStateBOS();
        }
        
        void InitializeStateBOS() {
          stateBOS_.reset(new TypedState<N>());
          NGram BOS(&wBOS, 1);
          QueryBackoff(lms_[0], BOS, stateBOS_->GetBackoffs());
          stateBOS_->Set(N - 1, N - 1, wBOS);
        }

        state_type stateBOS_;
        std::unique_ptr<lm::SubLanguageModel> lms_[N];
    };
  }
}
