#include <iostream>
#include <cstdio>
#include <cmath>

#include "util/progress.h"

#include "util/blob.h"
#include "lm/vocab.h"
#include "lm/language_model.h"

using namespace herbal;

void ToVocab(const std::string& modelPath) {
  std::unique_ptr<boost::progress_timer> t;
  t.reset(new boost::progress_timer(std::cerr));
  
  util::ScopedFile in(modelPath);
  util::Blob lmBlob(in, util::Blob::Mode::Lazy);
  
  lm::LanguageModel lm; 
  lmBlob >> lm;
  
  std::cerr << "Loading vocabulary" << std::endl;
  lm::BlobbedVocab vocab;
  lmBlob >> vocab;
  
  std::string line;
  while(std::getline(std::cin, line)) {
    std::vector<lm::Word> sentence;
    vocab.BatchSplitSentence(sentence, line);
    // skip BOS
    std::fwrite(sentence.data() + 1, sizeof(lm::Word), sentence.size() - 1, stdout);
  }
  t.reset(nullptr);
}

void QueryVocab(const std::string& modelPath, const std::string& queryPath) {
  std::unique_ptr<boost::progress_timer> t;
  
  util::ScopedFile modelFile(modelPath);
  
  util::Blob lmBlob;
  lmBlob.Read(modelFile);
  //lmBlob.Map(modelFile);
  
  lm::LanguageModel lm; 
  lmBlob >> lm;
  
  util::ScopedFile queryFile(queryPath);
  
  size_t lines = 0;
  float totalProb = 0;
  size_t totalLength = 0;
  
  t.reset(new boost::progress_timer(std::cerr));
  
  lm::LanguageModel::state_type& BOSState = lm.StateBOS();
  
  lm::LanguageModel::state_type state     = lm.NewState();
  lm::LanguageModel::state_type nextState = lm.NewState();
  
  lm::LanguageModel::state_type *statePtr     = &BOSState,
                                *nextStatePtr = &nextState;
  
  lm::Word word;
  while(queryFile >> word) {
    totalProb += lm.Query(word, *statePtr, nextStatePtr);
    
    if(statePtr == &BOSState)
      statePtr = &state;
    std::swap(statePtr, nextStatePtr);
    
    ++totalLength;

    if(word == lm::wEOS) {      
      ++lines;
      if(lines % 10000 == 0)
        std::cerr << ".";
      if(lines % 1000000 == 0)
        std::cerr << "[" << lines << "]" << std::endl;
      
      statePtr = &BOSState;
      nextStatePtr = &nextState;
    }
  }
  
  std::cout << "Perplexity: " << pow(10, -totalProb/totalLength)
    << " " << totalProb << " " << totalLength << std::endl;
  
  t.reset(nullptr);
}

int main(int argc, char** argv) {
  if(std::strcmp(argv[1], "vocab") == 0)
    ToVocab(argv[2]);
  else
    QueryVocab(argv[2], argv[3]);
  return 0;
}
