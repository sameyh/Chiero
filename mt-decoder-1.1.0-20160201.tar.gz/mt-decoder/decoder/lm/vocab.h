#pragma once

#include <unordered_map>
#include <string>
#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>


#include "util/string_piece_hash.h"
#include "util/scoped_file.h"
#include "util/exception.h"
#include "hash/chd.h"
#include "pt/byte_map.h"

#include "util/blob.h"
#include "hash/chd_builder.h"
#include "pt/builder/byte_map_builder.h"
#include "hash/murmur_hash.h"

//@TODO: clean me! factor out into separate folder and files.

namespace herbal {
namespace lm {

typedef uint32_t Word;

const Word wUNK = 0;
const Word wBOS = 1;
const Word wEOS = 2;

const std::string sUNK = "<unk>";
const std::string sBOS = "<s>";
const std::string sEOS = "</s>";

class ToWordVocab {
  public:
    virtual Word operator[](const util::StringPiece&) const = 0;

    template <class String>
    void Batch(std::vector<Word>& key, const std::vector<String>& strs, bool& unk) {
      unk = false;
      key.reserve(strs.size());
      for(auto& item : strs) {
        Word w = (*this)[item];
        if(w == 0)
          unk = true;
        key.push_back(w);
      }
    }

    template <class String>
    void Batch(std::vector<Word>& words, const String str) {
      bool unk = false;
      Batch(words, str, unk);
    }

    template <class String>
    void BatchSplit(std::vector<Word>& words, const String str, bool& unk) {
      std::vector<String> strs;
      boost::split(strs, str, boost::is_any_of(" "));
      Batch(words, strs, unk);
    }

    template <class String>
    void BatchSplit(std::vector<Word>& words, const String str) {
      bool unk = false;
      BatchSplit(words, str, unk);
    }

    template <class String>
    void BatchSplitSentence(std::vector<Word>& words, const String str) {
      words.push_back(wBOS);
      BatchSplit(words, str);
      words.push_back(wEOS);
    }
};

class FromWordVocab {
  public:
    virtual util::StringPiece operator[](Word) const = 0;
};

class Vocab : public ToWordVocab, public FromWordVocab {
  public:
    virtual Word operator[](const util::StringPiece&) const = 0;
    virtual util::StringPiece operator[](Word) const = 0;
};

template <class RandomHash>
class HashVocab : public ToWordVocab {
  public:
    HashVocab(uint32_t seed) : seed_(seed) {}

    virtual Word operator[](const util::StringPiece& key) const {
      HashTuple ht;
      RandomHash::Hash(seed_, key, ht);
      return ht.g;
    }

  private:
    uint32_t seed_;
};

class BlobbedVocab : public ToWordVocab, public util::Blobbed {
    public:

      virtual Word operator[](const util::StringPiece& key) const {
        auto it = vocab_.find(key);
        if(it == vocab_.end())
          return 0;
        return it->second;
      }

      void MapBlob(util::Blob& blob) {
        blob >> bytes_;
        blob >> buffer_(bytes_);

        char* data = buffer_.data();
        size_t length = 0;
        for(auto& c : buffer_) {
          if(c == '\0') {
            util::StringPiece str(data, length);
            Word before = vocab_.size();
            vocab_[str] = before;
            data = &c + 1;
            length = 0;
          }
          else
            length++;
        }
      }

    private:
      std::unordered_map<util::StringPiece, Word> vocab_;
      util::Chunk64 bytes_;
      util::ManyChunks<char> buffer_;
};

class CHDVocab : public Vocab,
                 public util::Blobbed {
  public:

    Word operator[](const util::StringPiece& key) const {
      if(key == sUNK)
        return 0;
      if(key == sBOS)
        return 1;
      if(key == sEOS)
        return 2;

      Word id = hash_[key] + 3; // skip for <unk>, <s>, </s>
      const auto& found = strings_[id];
      if(found.size() == key.size())
        if(std::memcmp(found.data(), key.data(), key.size()) == 0)
          return id;
      return wUNK;
    }

    util::StringPiece operator[](Word word) const {
      switch (word) {
        case 0 : return sUNK;
        case 1 : return sBOS;
        case 2 : return sEOS;
        default :
          THROW_IF(word >= strings_.size(), "No such word id: " << word);
          const auto& found = strings_[word];
          return util::StringPiece((const util::StringPiece::value_type*)found.data(),
                                   found.size());
      }
    }

  private:

    void MapBlob(util::Blob& blob) {
      blob >> hash_
           >> strings_;
    }

    CHD<Murmur> hash_;
    ByteMap strings_;
};

class CHDVocabBuilder : public util::Blob {
  public:
    CHDVocabBuilder() {}

    template <class Keys>
    CHDVocabBuilder(const Keys& keys) {
      Build(keys);
    }

    template <class Keys>
    CHDVocabBuilder& Build(const Keys& keys) {

      CHD<herbal::Murmur> hash;
      CHDBuilder<herbal::Murmur> hashBuilder(keys, 0.9);
      hashBuilder >> hash;

      std::vector<const typename Keys::value_type*> sorter(keys.size() + 3);
      sorter[0] = &sUNK;
      sorter[1] = &sBOS;
      sorter[2] = &sEOS;

      for(auto& key : keys)
        sorter[hash[key] + 3] = &key;

      ByteMapBuilder byteMapBuilder;
      for(auto* key : sorter) {
        byteMapBuilder.AppendPos();
        byteMapBuilder.AppendData(key->data(), key->size());
      }

      ByteMap byteMap;
      byteMapBuilder >> byteMap;

      Allocate(hashBuilder.size() + byteMapBuilder.size());

      *this
        << hashBuilder
        << byteMapBuilder;

      Rewind();

      return *this;
    }
};

class GrowVocab : public Vocab {
  public:
    virtual Word operator[](const util::StringPiece& key) const {
      return const_cast<GrowVocab&>(*this)[key];
    }

    virtual Word operator[](const util::StringPiece& key) {
      std::unordered_map<util::StringPiece, Word>::iterator it = vocabMap_.find(key);
      if(it != vocabMap_.end())
        return it->second;
      else {
        Word word = vocab_.size();
        vocab_.push_back(key.as_string());
        vocabMap_[util::StringPiece(vocab_.back())] = word;
        return word;
      }
    }

    virtual util::StringPiece operator[](Word word) const {
      return util::StringPiece(vocab_[word]);
    }

    void Dump(const std::string& filename) {
      util::ScopedFile out(filename, util::SF_WRITE);
      Dump(out);
    }

    void Dump(util::ScopedFile& out) {
      out << Bytes();
      for(auto& v : vocab_) {
        out.Write(v.data(), v.size());
        out << '\0';
      }
    }

    void PrettyDump(util::ScopedFile& out) {
      for(auto& v : vocab_) {
        out.Write(v.data(), v.size());
        out << '\n';
      }
    }

    size_t Bytes() {
      size_t bytes = vocab_.size();
      for(auto& v : vocab_)
        bytes += v.size();
      return bytes;
    }

    std::vector<std::string>& GetVocab() {
      return vocab_;
    }

  private:
    std::unordered_map<util::StringPiece, Word> vocabMap_;
    std::vector<std::string> vocab_;
};

class ClassIdVocab : public lm::ToWordVocab {
  public:
    ClassIdVocab(size_t maxCls) : maxCls_(maxCls) {}
    
    virtual lm::Word operator[](const util::StringPiece& str) const {
      if(str == "<unk>")
        return 0;
      if(str == "<s>")
        return 1;
      if(str == "</s>")
        return 2;
      if(str == "G")
        return maxCls_;
      return boost::lexical_cast<lm::Word>(str.as_string()) + 3;
    }
    
  private:  
    size_t maxCls_;
};

class OSMVocab : public lm::ToWordVocab {
  public:
    
    enum class Ops {
      TRANS, TO, INS, GAP, CONT, CEPT, JMP, BCK, DEL
    };
    
    OSMVocab(size_t mod = 1000000)
     : mod_(mod) {}
    
    virtual lm::Word operator[](const util::StringPiece& str) const {
      if(str == "<unk>")
        return 0;
      if(str == "<s>")
        return 1;
      if(str == "</s>")
        return 2;
      return HashStr(str);
    }
    
  lm::Word HashStr(const util::StringPiece& str) const {
    uint32_t seed = 0;
    uint32_t out = 0;
    MurmurHash3_x86_32(str.data(), str.size(), seed, &out);
    return (out % mod_) + 3;
  }
  
  private:
    const size_t mod_;
};

}
}
