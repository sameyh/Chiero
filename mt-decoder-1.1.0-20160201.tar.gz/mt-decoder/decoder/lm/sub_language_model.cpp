#include "lm/sub_language_model.h"

#include "lm/typed_sub_language_model.h"
#include "lm/typed_sub_language_model_unigram.h"

namespace herbal {
  namespace lm {
    SubLanguageModel::SubLanguageModel(size_t maxOrder) : maxOrder_(maxOrder) {}
    
    Payload SubLanguageModel::GetPayload(const NGram& key, bool* found) const {
      return subLm_->GetPayload(key, found);
    }

    void SubLanguageModel::MapBlob(util::Blob& blob) {
      blob >> order_;
      InitializeLM(order_);
      blob >> *subLm_;
    }
    
    void SubLanguageModel::InitializeLM(size_t order) {
      InitializeLM<TypedSubLanguageModelUnigram, TypedSubLanguageModel, Payloads8F>(order);    
    }
  }
}
