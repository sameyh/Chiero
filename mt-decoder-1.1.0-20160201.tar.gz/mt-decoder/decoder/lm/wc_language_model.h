#pragma once

#include "lm/language_model.h"

namespace herbal {
  namespace lm {

    /**
     * @brief Word-class Language Model.
     *
     * Derived class from normal language model to be used with word-classes.
     * All word indeces are mapped to class indeces (@see Query), querying is
     * then the same as for normal language models.
     */
    class WCLanguageModel : public LanguageModel {
      public:

        /**
         * @brief Language model querying without states by n-gram
         *
         * N-gram-based LM-querying function, mainly for diagnostic purposes,
         * not used during decoding. The given n-gram is converted to a word
         * class n-gram.
         *
         * @param ngram Queried n-gram
         * @param prob Found log-probability
         * @param backoff Found backoff weight
         * @param found Whether the given n-gram is present in the LM
         */
        virtual void Query(const NGram& ngram, float* prob, float* backoff, bool* found) {
          Word buffer[ngram.size()];
          for(size_t i = 0; i < ngram.size(); ++i)
            buffer[i] = classes_[ngram.data()[i]];
          NGram classNgram(buffer, ngram.size());
          return LanguageModel::Query(classNgram, prob, backoff, found);
        }
        
        /**
         * @brief Language model querying with states
         *
         * Main LM-querying function for word-by-word extension of n-grams based
         * on previous state. Word ids are wrapped into class ids during
         * querying.
         *
         * @param word Current word extending previous query
         * @param state Last language model states
         * @param nextState Next language model state, filled after querying the
         * current word
         *
         * @return N-Gram log-probability
         */
        virtual float Query(Word word, const state_type& state, state_type* nextState) {
          return LanguageModel::Query(classes_[word], state, nextState);
        }

      private:
        virtual void MapBlob(util::Blob& blob) {
          blob >> classesSize_;
          blob >> classes_(classesSize_);
          LanguageModel::MapBlob(blob);
        }

        util::Chunk64 classesSize_;
        util::ManyChunks<Word> classes_;
    };
  }
}
