#pragma once

#include <cstring>

namespace herbal {
namespace lm {

#pragma pack(push)
#pragma pack(1)

/**
 * brief internal helper class for collection payloads (probability, backoffs)
 * from language model binary structures
 */
template<class PayloadT>
class OrderedPayload {
  public:
    typedef PayloadT payload_type;
    
    OrderedPayload() : index_(0) {}
    
    OrderedPayload(PayloadT payload)
    : index_(0), payload_(payload)
    {}

    template <typename Float>
    OrderedPayload(Float prob, Float backoff)
    : index_(0), payload_(prob, backoff)
    {}

    uint32_t GetIndex() { return index_; }
    PayloadT& GetPayload() { return payload_; }
    
    const uint32_t GetIndex() const { return index_; }
    const PayloadT& GetPayload() const { return payload_; }
       
    void SetIndex(uint64_t index) {
        index_ = index;
    }
  
    bool operator<(const OrderedPayload& o) const {
      return index_ < o.index_;
    }
  
  private:
    uint32_t index_;
    PayloadT payload_;
};

/**
 * brief internal helper class for collection payloads (probability, backoffs)
 * from language model binary structures
 */
template<typename Float = float>
class PayloadUnigram {
  public:
    typedef Float float_type;
    
    PayloadUnigram() : prob_(0), backoff_(0) {}
    
    PayloadUnigram(Float prob, Float backoff)
    : prob_(prob), backoff_(backoff)
    {}
    
    PayloadUnigram(const OrderedPayload<PayloadUnigram<Float>>& o)
    : PayloadUnigram(o.GetPayload())
    {}
    
    Float GetProb() const { return prob_; }
    Float GetBackoff() const { return backoff_; }
    
    void SetProb(Float prob) { prob_ = prob; }
    void SetBackoff(Float backoff) { backoff_ = backoff; }
    
    bool operator!=(const PayloadUnigram& o) const {
      return std::memcmp(this, &o, sizeof(PayloadUnigram));
    }
  
    template <class P>
    friend void setBackoffSignIfZero(P&);
    
    template <class P>
    friend bool BackoffIsZeroAndNotSigned(P&);
    
  private:
    Float prob_;
    Float backoff_;
};

/**
 * brief internal helper class for collection payloads (probability, backoffs)
 * from language model binary structures
 */
template<typename Print, typename Float = float>
class PayloadLower {
  public:
    typedef Print print_type;
    typedef Float float_type;
    
    PayloadLower() : print_(0), prob_(0), backoff_(0) {}
    
    PayloadLower(Float prob, Float backoff)
    : print_(0), prob_(prob), backoff_(backoff)
    {}
        
    PayloadLower(Print print, Float prob, Float backoff)
    : print_(print), prob_(prob), backoff_(backoff)
    {}

    PayloadLower(const OrderedPayload<PayloadLower<Print,Float>>& o)
    : PayloadLower(o.GetPayload())
    {}
    
    bool PrintMatches(Print print) const {
        return print_ == print;
    }
    
    static PayloadLower Unknown() {
      return PayloadLower(0, 1.0, 1.0);
    }
    
    Print GetPrint() const { return print_; }
    Float GetProb() const { return prob_; }
    Float GetBackoff() const { return backoff_; }
    
    void SetPrint(Print print) { print_ = print; }
    void SetProb(Float prob) { prob_ = prob; }
    void SetBackoff(Float backoff) { backoff_ = backoff; }
  
    template <class P>
    friend void setBackoffSignIfZero(P&);
    
    template <class P>
    friend bool BackoffIsZeroAndNotSigned(P&);
  
    bool operator!=(const PayloadLower& o) const {
      return std::memcmp(this, &o, sizeof(PayloadLower));
    }
  
  private:
    Print print_;
    Float prob_;
    Float backoff_;
};

/**
 * brief internal helper class for collection payloads (probability, backoffs)
 * from language model binary structures
 */
template<typename Print, typename Float = float>
class PayloadHighest {
  public:
    typedef Print print_type;
    typedef Float float_type;

    PayloadHighest() : print_(0), prob_(0) {}

    PayloadHighest(Float prob, Float backoff = 0.0)
    : print_(0), prob_(prob)
    {}

    PayloadHighest(Print print, Float prob, Float backoff = 0.0)
    : print_(print), prob_(prob)
    {}

    PayloadHighest(const OrderedPayload<PayloadHighest<Print,Float>>& o)
    : PayloadHighest(o.GetPayload())
    {}

    Print GetPrint() const { return print_; }
    Float GetProb() const { return prob_; }
    Float GetBackoff() const { return 0.0; }

    void SetProb(Float prob) { prob_ = prob; }
    void SetBackoff(Float backoff) {  }

    
    bool PrintMatches(Print print) const {
        return print_ == print;
    }

    void SetPrint(Print print) { print_ = print; }

    bool operator!=(const PayloadHighest& o) const {
      return std::memcmp(this, &o, sizeof(PayloadHighest));
    }

  private:
    Print print_;
    Float prob_;
};

/**
 * brief internal helper class for collection payloads (probability, backoffs)
 * from language model binary structures
 */
template <class Print, class Float>
struct Payloads {
  using payload_unigram = PayloadUnigram<Float>;
  using payload_lower   = PayloadLower<Print, Float>; 
  using payload_highest = PayloadHighest<Print, Float>;
};

/**
 * brief internal helper class for collection payloads (probability, backoffs)
 * from language model binary structures
 */
class Payload {
  public:
    Payload() : prob_(0), backoff_(0) {}
    Payload(float prob, float backoff) : prob_(prob), backoff_(backoff) {}
    
    Payload(const Payload&) = delete;
    Payload(Payload&&) = default;
    
    float GetProb() const {
      return prob_;
    }

    float GetBackoff() const {
      return backoff_;
    }
    
  private:
    float prob_;
    float backoff_;
};

typedef PayloadUnigram<float> PayloadUF;
typedef PayloadLower<uint8_t, float> PayloadL8F;
typedef PayloadHighest<uint8_t, float> PayloadH8F;

typedef PayloadLower<uint16_t, float> PayloadL16F;
typedef PayloadHighest<uint16_t, float> PayloadH16F;

typedef Payloads<uint16_t, float> Payloads8F;
//typedef Payloads<uint16_t, float> Payloads16F;


#pragma pack(pop)

}
}
