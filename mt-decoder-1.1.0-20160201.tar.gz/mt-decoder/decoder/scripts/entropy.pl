use strict;

my $sum = 0;
my @n;
my $e = 0;
while (<STDIN>) {
    chomp;
    s/^\s+|\s+$//g;
    my ($n, $i) = split;
    push(@n, $n);
    $sum += $n;
}

foreach(@n) {
    $e += - $_/$sum * log($_/$sum);
}
print $e, "\n";
