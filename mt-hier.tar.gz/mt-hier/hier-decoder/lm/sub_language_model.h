#pragma once

#include "util/blob.h"
#include "lm/payload.h"
#include "lm/ngram.h"

#include "lm/sub_language_model_base.h"

namespace herbal {
  namespace lm {
  
    /**
     * @brief class for n-gram language model fragments of specific order.
     *
     * This class is used a per-order component for language models with
     * multiple order (N > 1). Each LM order is saved in its specific subLM.
     * This class is not meant to be used on its own.
     * It wraps the more specific TypeSpecificSubLanguageModel to provide a
     * generic type-independent interface.
     */
    class SubLanguageModel : public SubLanguageModelBase {
      public:
        
        /**
         * @brief Constructor
         *
         * @param maxOrder Highest order used in the main language model
         */
        SubLanguageModel(size_t maxOrder);
        
        /**
         * @brief Retreive payload (probability, backoff weigh)
         *
         * @param key N-gram for which the payload should be retrieved
         * @param found Whether the n-gram has been found in the sub-lm
         *
         */
        Payload GetPayload(const NGram& key, bool* found) const;
        
      private:
        void MapBlob(util::Blob&);
        void InitializeLM(size_t);
        
        template <template <typename> class LMUnigram,
                  template <typename> class LM,
                  class Payloads> 
        void InitializeLM(size_t order) {
          if (order_ == 1)
            subLm_.reset(new LMUnigram<typename Payloads::payload_unigram>());
          else if (order_ == maxOrder_)
            subLm_.reset(new LM<typename Payloads::payload_highest>());
          else
            subLm_.reset(new LM<typename Payloads::payload_lower>());
        }

        size_t maxOrder_;
        util::Chunk64 order_;
        std::unique_ptr<SubLanguageModelBase> subLm_;
    };
    
  }
}
