#pragma once

#include "lm/ngram.h"

namespace herbal {
  namespace lm {    

    class NGramIterator : public std::iterator<std::input_iterator_tag, NGram> {
      public:
        NGramIterator(typename NGram::value_type* data, size_t size)
        : nkey_(data, size) {}
        
        NGramIterator()
        : nkey_(nullptr, 0) {}
        
        bool operator!=(const NGramIterator& o) {
          return nkey_.data_ != o.nkey_.data_;
        }
        
        bool operator==(const NGramIterator& o) {
          return nkey_.data_ == o.nkey_.data_;
        }
        
        NGramIterator& operator++() {
          nkey_.data_ += nkey_.size_;
          return *this;
        }
        
        NGramIterator operator++(int) {
          NGramIterator copy(*this);
          ++(*this);
          return copy;
        }
        
        NGram& operator*() {
          return nkey_;
        }
               
        size_t operator-(const NGramIterator& o) {
          return (nkey_.data() - o.nkey_.data()) / nkey_.size(); 
        }
        
        NGramIterator operator+(const size_t& i) {
          return NGramIterator(nkey_.data() + i * nkey_.size(), nkey_.size()); 
        }
        
      private:
        NGram nkey_;
    };

  }
}