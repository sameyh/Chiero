
#include "lm/builder/arpa_parser.h"

#include <iostream>
#include "util/exception.h"

namespace herbal {
  namespace lm {
    
    bool ARPAParser::GetToken() {
      token_.clear();
      if(c_ >= buffer_ + read_) 
          NextRead();
      while(read_) {
        if(isspace(*c_)) {
          if(!token_.empty()) {
            token_.push_back('\0');
            return true;
          }
          if(*c_ == '\n' && token_.empty()) {
            token_.push_back('\n');
            token_.push_back('\0');
            c_++;
            return true;
          }
        }
        else {
          token_.push_back(*c_);
        }
        c_++;
        
        if(c_ >= buffer_ + read_) 
          NextRead();
      }
      if(!token_.empty()) {
        token_.push_back('\0');
        return true;
      }
      return false;
    }
    
    void ARPAParser::NextRead() {
      if(!EoF()) {
        read_ = std::fread(buffer_, 1, 1024, fPtr_);
        c_ = buffer_;
      }
      else {
        read_ = 0;
        c_ = buffer_;
      }
    }
        
    bool ARPAParser::ParseStat() {
      GetToken();
      util::StringPiece tok(token_.data(), token_.size() - 1);
      size_t num = strtoul(tok.substr(tok.find("=") + 1).data(),
                           NULL, 10);
      stats_.push_back(num);
      seen_.push_back(0);
      
      state_ = BeforeStatOrNgram;
      return true;
    }
    
    bool ARPAParser::ParseNGram(ARPAGram& ngram) {
      if(Done())
        throw util::Exception();
      
      double prob;
      double backoff = 0;
      
      state_ = Prob;
      
      do {
        util::StringPiece tok(token_.data(), token_.size() - 1);
        
        if(state_ == Newline && tok != "\n")
          throw util::Exception();
        else if(state_ == Newline && tok == "\n") {
          state_ = GetNGram;
          break;
        }
        if(tok != "\n") {
          if(state_ == Prob) {
            prob = strtod(tok.data(), NULL);
            ngram.SetProb(prob);
            state_ = NGramToken;
          }
          else if(state_ == NGramToken) {
            Word w = vocab_[tok];
            if(w == 0)
              noUnk_ = false;
            ngram.Append(w);
            if(ngram.Size() < order_)
              state_ = NGramToken;
            else
              state_ = Backoff;
          }
          else if(state_ == Backoff) {
            backoff = strtod(tok.data(), NULL);
            ngram.SetBackoff(backoff);
            state_ = Newline;
          }
        }
        else {
          if(state_ == Backoff) {
            backoff = 0;
            ngram.SetBackoff(backoff);
            state_ = GetNGram;
            break;
          }
        }
      } while(GetToken());
      
      
      ngram.SetPos(num_);
      seen_[order_ - 1]++;
      num_++;
      
      return true;
    }
    
    bool ARPAParser::NextNGram(ARPAGram& ngram) {
      if(Done())
        return false;
      
      ngram.Clear();
      while(state_ != End && GetToken()) {
        util::StringPiece tok(token_.data(), token_.size() - 1);
        
        if(tok != "\n") {
          if(tok == "\\end\\") {
            state_ = End;
            return false;
          } else if(state_ == GetNGram) {
            if(sscanf(tok.data(), "\\%lu-grams:", &order_)) {
              state_ = GetNGram;
            } else {
              return ParseNGram(ngram);
            }
          }
        }
      }
      
      // Consume all;
      while(GetToken());
      
      return false;
    }
    
    bool ARPAParser::ParseHeader() {   
      state_ = Start;

      while(true) {
        GetToken();
        util::StringPiece tok(token_.data(), token_.size() - 1);
        
        if(tok != "\n") {
          if(state_ == Start) {
            if(tok == "\\data\\") {
              state_ = BeforeStatOrNgram;
            } else {
              state_ = Failure;
              throw util::Exception();
            }
          } else if(tok == "\\end\\") {
            state_ = End;
            break;
          } else if(state_ == Failure) {
            std::cerr << "Failure!" << std::endl;
            break;
          } else if(state_ == BeforeStatOrNgram) {
            if(tok == "ngram") {
              state_ = GetStat;
              ParseStat();
            } else if(sscanf(tok.data(), "\\%lu-grams:", &order_)) {
              state_ = GetNGram;
              break;
            } else {
              state_ = Failure;
              throw util::Exception();
            }
          } 
        }
      }
      return true;
    }
    
  }
}
