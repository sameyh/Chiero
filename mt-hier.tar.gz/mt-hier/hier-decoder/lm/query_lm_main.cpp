#include <iostream>
#include <cstdio>
#include <cmath>
#include <boost/program_options.hpp>

#include "util/progress.h"
#include "util/string_piece.h"
#include "util/string_piece_split.h"

#include "util/blob.h"
#include "lm/vocab.h"
#include "lm/language_model.h"
#include "lm/wc_language_model.h"
#include "lm/ngram.h"

#include "dec/ff/ff_header.h"

using namespace herbal;

int main(int argc, char** argv) {
  namespace po = boost::program_options;
  po::options_description cmdline_options("Allowed options");

  bool help = false;
  std::string lmPath;
  std::string vocabPath;
  bool classBased = false;

  cmdline_options.add_options()
    ("lm,l", po::value(&lmPath)->required(),
     "Path to lm")
    ("vocab,v", po::value(&vocabPath)->required(),
     "Path to common vocabulary")
    ("class-based,c", po::value(&classBased)->zero_tokens()->default_value(false),
     "Treat as class-based lm")
    ("help,h", po::value(&help)->zero_tokens()->default_value(false),
     "Print this help message and exit")
  ;

  po::variables_map vm;
  try {
    po::store(po::command_line_parser(argc,argv).
              options(cmdline_options).run(), vm);
    po::notify(vm);
  }
  catch (std::exception& e) {
    std::cout << "Error: " << e.what() << std::endl << std::endl;

    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }

  if (help) {
    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }

  util::ScopedFile vocabFile(vocabPath);
  util::Blob vocabBlob;
  vocabBlob.Map(vocabFile);
  lm::CHDVocab vocab;
  vocabBlob >> vocab;
  std::cerr << "Vocab is loaded.\n";

  util::ScopedFile lmFile(lmPath);
  util::Blob lmBlob;
  lmBlob.Map(lmFile);

  FFHeader ffHeader;
  lmBlob >> ffHeader;

  lmBlob.Map(lmFile);
  lm::LanguageModel* languageModel;
  if(classBased)
    languageModel = new lm::WCLanguageModel();
  else
    languageModel = new lm::LanguageModel();
  lmBlob >> *languageModel;


  std::string line;
  while(std::getline(std::cin, line)) {
    herbal::util::StringPiece sLine(line.data(), line.length());
    std::vector<herbal::util::StringPiece> sWords;
    herbal::util::split(sWords, sLine, " ");

    std::vector<lm::Word> ngramVec;
    //ngramVec.push_back(lm::wBOS);
    for(auto& s : sWords) {
      ngramVec.push_back(vocab[s]);
    }
    //ngramVec.push_back(lm::wEOS);

    lm::LanguageModel::state_type state     = languageModel->NewState();
    lm::LanguageModel::state_type nextState = languageModel->NewState();

    lm::LanguageModel::state_type *statePtr     = &state,
                                *nextStatePtr = &nextState;

    float totalProb = 0;
    for(auto w : ngramVec) {
      float prob = languageModel->Query(w, *statePtr, nextStatePtr);
      totalProb += prob;
      std::cout << vocab[w] << " " << w << "\t" << prob << " " << prob/log(10) << std::endl;
      std::swap(statePtr, nextStatePtr);
    }

    std::cout << totalProb << " " << totalProb/log(10) << std::endl;

  }
  delete languageModel;

  return 0;
}
