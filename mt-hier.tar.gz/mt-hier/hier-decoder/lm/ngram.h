#pragma once

#include "lm/vocab.h"

namespace herbal {
  namespace lm {    

    class NGramIterator;
    
    /**
     * @brief NGram class for querying
     *
     * A simple NGram class for wrapping continuous pieces of memory filled with
     * lm::Word values to provide phrase-like functionality.
     * Also used for querying in language models and other data structures. 
     */
    class NGram {
      public:
        typedef const Word value_type;
      
        /**
         * @brief Constructor
         *
         * @param data Pointer of type lm::Word* to sequence start
         * @oaran size Length of sequence
         */
        NGram(value_type* data, size_t size)
        : data_(data), size_(size) {}
        
        /**
         * @brief Accessor to underlying memory
         */
        value_type* data() {
          return data_;
        }

        /**
         * @brief Accessor to underlying memory (const version)
         */
        value_type* data() const {
          return data_;
        }
                
        /**
         * @brief Accessor to size in number od words lm::Word
         */
        size_t size() const {
          return size_;
        }
        
        /**
         * @brief Return sequence iterator start
         */
        value_type* begin() const {
          return data();
        }
        
        /**
         * @brief Return sequence iterator end
         */
        value_type* end() const {
          return data_ + size();
        }
        
         /**
         * @brief For sorting ngrams
         */
        bool operator<(const NGram& o) {
          return std::lexicographical_compare(data_, data_ + size_,
                    o.data_, o.data_ + o.size_, std::less<lm::Word>());
        }
        
        template <class OStream>
        friend OStream& operator<<(OStream& o, const NGram& ngram) {
          for(auto& w : ngram) {
            o << w << " ";
          }
          return o;
        }
       
      friend NGramIterator;
      
      private:
        const value_type* data_;
        const size_t size_;
    };
  }
}