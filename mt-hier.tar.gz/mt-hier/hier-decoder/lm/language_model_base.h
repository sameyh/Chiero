#pragma once

#include <memory>

#include "util/blob.h"
#include "lm/state.h"
#include "lm/ngram.h"

namespace herbal {
  namespace lm {
    
    /**
     * Abstract base class for language models, @see LanguageModel for
     * more detailed information on class members.
     */
    class LanguageModelBase : public util::Blobbed {
      public:
        typedef std::unique_ptr<State> state_type;
        
        virtual state_type& StateBOS() = 0;
        virtual state_type NewState() = 0;
        virtual float Query(Word, const state_type&, state_type*) = 0;
        virtual void Query(const NGram&, float*, float*, bool*) = 0;
        
        virtual float UNK() = 0;
        virtual float BOS() = 0;
        virtual float EOS() = 0;
        
        virtual ~LanguageModelBase() {}
      
      protected:
        virtual void MapBlob(util::Blob&) = 0;
    };
    
  }
}
