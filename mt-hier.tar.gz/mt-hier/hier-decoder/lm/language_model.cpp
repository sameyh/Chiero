#include "lm/language_model.h"

#include "lm/typed_language_model.h"

namespace herbal {
  namespace lm {
    
    float LanguageModel::Query(Word word, const state_type& state,
                               state_type* nextState) {
      return lm_->Query(word, state, nextState);
    }
    
    void LanguageModel::Query(const NGram& ngram, float* prob, float* bow, bool* found) {
      lm_->Query(ngram, prob, bow, found);
    }
    
    LanguageModel::state_type LanguageModel::NewState() {
      return lm_->NewState();
    }
    
    LanguageModel::state_type& LanguageModel::StateBOS() {
      return lm_->StateBOS();
    }
    
    float LanguageModel::UNK() {
      return lm_->UNK();
    }

    float LanguageModel::BOS() {
      return lm_->UNK();
    }

    float LanguageModel::EOS() {
      return lm_->UNK();
    }
    
    void LanguageModel::InitializeLM(size_t order) {
      switch(order) {
        case 1 : lm_.reset(new TypedLanguageModel<1>()); break;
        case 2 : lm_.reset(new TypedLanguageModel<2>()); break;
        case 3 : lm_.reset(new TypedLanguageModel<3>()); break;
        case 4 : lm_.reset(new TypedLanguageModel<4>()); break;
        case 5 : lm_.reset(new TypedLanguageModel<5>()); break;
        case 6 : lm_.reset(new TypedLanguageModel<6>()); break;
        case 7 : lm_.reset(new TypedLanguageModel<7>()); break;
        case 8 : lm_.reset(new TypedLanguageModel<8>()); break;
        case 9 : lm_.reset(new TypedLanguageModel<9>()); break;
        default: 
           THROW_IF(order > 9, "Maximum n-gram size of 9, add orders here for more."); 
           break;
      }
    }
    
    void LanguageModel::MapBlob(util::Blob& blob) {          
      blob >> maxOrder_;
      InitializeLM(maxOrder_);
      blob >> *lm_;
    }
  }
}
