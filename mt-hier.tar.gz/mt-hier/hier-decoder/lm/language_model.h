#pragma once

#include "lm/language_model_base.h"

namespace herbal {
  namespace lm {
    
      /**
     * @brief Main Language model data structure for ngram language model.
     *
     * Main Language model data structure for ngram language mode, used as
     * wrapper around TypedLanguageModel which have predefined maximum n-gram
     * size. This data structure is more generic. 
     */
    class LanguageModel : public LanguageModelBase {
      public:

        /**
         * @brief Language model querying without states by n-gram
         *
         * N-gram-based LM-querying function, mainly for diagnostic purposes,
         * not used during decoding. 
         *
         * @param ngram Queried n-gram
         * @param prob Found log-probability
         * @param backoff Found backoff weight
         * @param found Whether the given n-gram is present in the LM
         */
        virtual void Query(const NGram&, float*, float*, bool*);
        
        /**
         * @brief Language model querying with states
         *
         * Main LM-querying function for word-by-word extension of n-grams based
         * on previous state. 
         *
         * @param word Current word extending previous query
         * @param state Last language model states
         * @param nextState Next language model state, filled after querying the
         * current word
         *
         * @return N-Gram log-probability
         */
        virtual float Query(Word word, const state_type& state, state_type* nextState);
        
        /**
         * Create empty state to-be-filled during querying. State type is
         * automatically destroyed when released.
         */
        state_type NewState();
        
        /**
         * Returns common state for Begin-of-Sentence hypothesis. 
         */
        state_type& StateBOS();

        /**
         * Return probability of unknown word, used for future-score calculation.
         */
        float UNK();
        
        /**
         * Return probability of begin-of-sentence symbol, used for future-score
         * calculation.
         */
        float BOS();
        
        /**
         * Return probability of end-of-sentence symbol, used for future-score
         * calculation.
         */
        float EOS();
		/*
		 *
		 *
		 * */
		size_t GetLMOrder(){
			return maxOrder_;
		}
        
      protected:
        virtual void MapBlob(util::Blob& blob);
        virtual void InitializeLM(size_t order);
        
        util::Chunk64 maxOrder_;
        std::unique_ptr<LanguageModelBase> lm_;
    };
  }
}
