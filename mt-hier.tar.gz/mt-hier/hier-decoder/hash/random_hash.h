#pragma once

#include <cstring>

#include "hash/murmur_hash.h"
#include "util/string_piece.h"

namespace herbal {
  
struct HashTuple {
  uint32_t g;
  uint32_t f;
  uint32_t h;
  uint32_t p;
  
  friend std::ostream& operator<<(std::ostream& o, const HashTuple &ht) {
    return o << ht.g << " " << ht.f << " " << ht.h << " " << ht.p;
  }
};

struct HashTuple64 {
  uint64_t g;
  uint64_t f;
  uint64_t h;
  uint64_t p;

  friend std::ostream& operator<<(std::ostream& o, const HashTuple64 &ht) {
    return o << ht.g << " " << ht.f << " " << ht.h << " " << ht.p;
  }
};

class Murmur {
  public:
    template <class Key>
    static void Hash(const uint32_t seed, const Key& key, HashTuple& ht) {
      MurmurHash3_x64_128(key.data(), key.size() * sizeof(typename Key::value_type), seed, &ht);
    }

    static void Hash(const uint32_t seed, const char* key, HashTuple& ht) {
      util::StringPiece keyPiece(key, strlen(key));
      Hash(seed, keyPiece, ht);
    }
    
    template <class Key>
    static void Hash64(uint64_t seed, const Key& key, HashTuple64& ht) {
      uint32_t seed1 = seed;
      uint32_t seed2 = seed >> 32; 
      MurmurHash3_x64_128(key.data(), key.size(), seed1, &ht.g);
      MurmurHash3_x64_128(key.data(), key.size(), seed2, &ht.h);
    }
    
    static void Hash64(uint64_t seed, const char* key, HashTuple64& ht) {
      util::StringPiece keyPiece(key, strlen(key));
      Hash64(seed, keyPiece, ht);
    }
};

class PreHashed {
  public:
    static void Hash(uint32_t &seed, HashTuple& key, HashTuple& ht) {
      ht = key;
      seed = seed_;
    }
    
    static void SetSeed(uint32_t seed) {
      seed_ = seed;
    }
    
    static uint32_t seed_;
};
  
}