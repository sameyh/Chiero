#include "hash/buckets.h"

namespace herbal {

bool operator==(const BucketItem& b1, const BucketItem& b2) {
  return b1.f == b2.f && b1.h == b2.h;
}

}
