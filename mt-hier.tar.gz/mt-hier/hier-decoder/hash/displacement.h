#pragma once

#include <cmath>

namespace herbal {
 
// Diagonal search for displacement values does not hit size limit so often
// as the method in CMPH, less repeated iterations. (1,0) has index 2.

inline static void GetDisplacement(uint64_t index, uint64_t& d0, uint64_t& d1) {
  uint64_t diagonal = 0.5 + sqrt(0.25 + 2 * index);
  uint64_t firstInRow = 0.5 * diagonal * (diagonal - 1);
  d0 = index - firstInRow;
  d1 = diagonal - d0 - 1;
}

}