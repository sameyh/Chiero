#pragma once

#include <cstdio>
#include <cstdlib>
#include <memory>
#include <sys/mman.h>
#include <sys/types.h>
#include <unistd.h>

#include "util/exception.h"
#include "util/types.h"

namespace herbal {
namespace util {


const size_t SCOPED_FILE_BUFFER_SIZE = 100ul * 1024ul * 1024ul;

class ScopedFile {
  public:
    template <typename T>
    class InputIterator : public std::iterator<std::input_iterator_tag, T> {
      public:
        InputIterator() : sf_(0) {}
        InputIterator(ScopedFile &sf) : sf_(&sf) { ++*this; }

        InputIterator<T>& operator++() {
          if (sf_ && !(*sf_ >> value_))
            sf_ = 0;
          return *this;
        }

        InputIterator<T> operator++(int) {
          InputIterator<T> tmp = *this;
          ++*this;
          return tmp;
        }

        const T& operator*() const { return value_; }
        const T* operator->() const { return &value_; }
        bool operator!=(InputIterator &it) { return sf_ != it.sf_; }

      private:
        T value_;
        ScopedFile* sf_;
    };

    template <typename T>
    class OutputIterator : public std::iterator<std::output_iterator_tag, T> {
      public:
        OutputIterator() : sf_(0) {}
        OutputIterator(ScopedFile &sf) : sf_(&sf) {}

        OutputIterator<T>& operator=(const T& value) {
          *sf_ << value;
          return *this;
        }

        OutputIterator<T>& operator*() { return *this; }
        OutputIterator<T>  operator++(int) { return *this; }
        OutputIterator<T>& operator++() { return *this; }

      private:
        ScopedFile* sf_;
    };

  public:
    enum struct Mode { Read, Write, Append, ReadUpdate,
                WriteUpdate, AppendUpdate };

    typedef InputIterator<Byte> iterator;
    typedef OutputIterator<Byte> output_iterator;

    ScopedFile(const std::string& filename, Mode mode)
    : pFile_(nullptr), mode_(mode), size_(0),
      buffer_(new Byte[SCOPED_FILE_BUFFER_SIZE])
    {
      switch(mode_) {
        case Mode::Write:
          pFile_.reset(std::fopen(filename.c_str(), "wb"));
          break;
        case Mode::Append:
          pFile_.reset(std::fopen(filename.c_str(), "ab"));
          break;
        case Mode::ReadUpdate:
          pFile_.reset(std::fopen(filename.c_str(), "rb+"));
          break;
        case Mode::AppendUpdate:
          pFile_.reset(std::fopen(filename.c_str(), "ab+"));
          break;
        case Mode::WriteUpdate:
          pFile_.reset(std::fopen(filename.c_str(), "wb+"));
          break;
        case Mode::Read:
        default:
          pFile_.reset(std::fopen(filename.c_str(), "rb"));
          break;
      }
      std::setvbuf(pFile_.get(), (char*)buffer_, _IOFBF, SCOPED_FILE_BUFFER_SIZE);
      size_ = TrueSize();
    }

    ScopedFile()
    : pFile_(std::tmpfile()), mode_(Mode::WriteUpdate), size_(0),
      buffer_(new Byte[SCOPED_FILE_BUFFER_SIZE])
    {
      ThrowIfNull();
      int retval = std::setvbuf(pFile_.get(), (char*)buffer_,
                                _IOFBF, SCOPED_FILE_BUFFER_SIZE);
      if(retval != 0)
        throw util::Exception();
    }

    ScopedFile(std::FILE* filePtr)
    : pFile_(filePtr), mode_(Mode::Write), size_(0),
      buffer_(new Byte[SCOPED_FILE_BUFFER_SIZE])
    {
      ThrowIfNull();
      int retval = std::setvbuf(pFile_.get(), (char*)buffer_,
                                _IOFBF, SCOPED_FILE_BUFFER_SIZE);
      if(retval != 0)
        throw util::Exception();
    }

    ScopedFile(const std::string& filename)
    : ScopedFile(filename, Mode::Read)
    {}

    ScopedFile(ScopedFile& sf)
     : pFile_(std::move(sf.pFile_)), mode_(sf.mode_), size_(sf.size_),
       buffer_(sf.buffer_)
    {
      sf.buffer_ = nullptr;
    }

    ScopedFile(ScopedFile&& sf)
     : pFile_(std::move(sf.pFile_)), mode_(sf.mode_), size_(sf.size_),
       buffer_(sf.buffer_)
    {
      sf.buffer_ = nullptr;
    }

    ~ScopedFile() {
      if(pFile_ != nullptr)
        std::fclose(pFile_.release());
      if(buffer_ != nullptr)
        delete buffer_;
    }

    iterator begin() {
      Rewind();
      return iterator(*this);
    }

    iterator end() {
      return iterator();
    }

    output_iterator output() {
      return output_iterator(*this);
    }

    template<typename T>
    InputIterator<T> begin() {
      Rewind();
      return InputIterator<T>(*this);
    }

    template<typename T>
    InputIterator<T> end() {
      return InputIterator<T>();
    }

    template<typename T>
    OutputIterator<T> output() {
      return OutputIterator<T>(*this);
    }


    size_t Resize(size_t size) {
      ThrowIfNull();
      int retval = ftruncate(GetFileDescriptor(), size);
      if(retval != 0)
        throw util::Exception();
      size_ = size;
      return size;
    }

    size_t Read(Byte* data, size_t size) {
      ThrowIfNull();
      size_t read = std::fread(data, 1, size, pFile_.get());
      return read;
    }

    size_t Write(Byte* data, size_t size) {
      ThrowIfNull();
      size_t written = std::fwrite(data, 1, size, pFile_.get());
      if(written != size)
        throw util::Exception();
      size_ += written;
      return written;
    }

    template <typename T>
    size_t Write(T* data, size_t size) {
      ThrowIfNull();
      size_t written = std::fwrite((Byte*)data, 1, size * sizeof(T), pFile_.get());
      if(written != size * sizeof(T))
        throw util::Exception();
      size_ += written;
      return written;
    }

    size_t Flush() {
      ThrowIfNull();
      return std::fflush(pFile_.get());
    }

    int GetFileDescriptor() const {
      ThrowIfNull();
      return fileno(pFile_.get());
    }

    int GetProtection() const {
      switch(mode_) {
        case Mode::Write:
          return PROT_WRITE;
        case Mode::Append:
          return PROT_NONE;
        case Mode::ReadUpdate:
          return PROT_READ|PROT_WRITE;
        case Mode::AppendUpdate:
          return PROT_NONE;
        case Mode::WriteUpdate:
          return PROT_READ|PROT_WRITE;
        case Mode::Read:
        default:
          return PROT_READ;
      }
    }

    size_t Size() const {
      return size_;
    }

    size_t TrueSize() {
      ThrowIfNull();
      Flush();
      size_t current = std::ftell(pFile_.get());
      std::fseek(pFile_.get(), 0, SEEK_END);
      size_t bytes = std::ftell(pFile_.get());
      std::fseek(pFile_.get(), current, SEEK_SET);
      return bytes;
    }

    void Rewind() {
      Flush();
      std::rewind(pFile_.get());
    }

    template <typename T>
    ScopedFile& operator<<(T plain) {
        Write((Byte*)&plain, sizeof(T));
        return *this;
    }

    template <typename T>
    ScopedFile& operator>>(T &plain) {
        Read((Byte*)&plain, sizeof(T));
        return *this;
    }

    operator bool() {
      return std::feof(pFile_.get()) == 0;
    }

  private:

    inline void ThrowIfNull() const {
      if(pFile_ == nullptr) {
        throw util::Exception();
      }
    }

    std::unique_ptr<std::FILE> pFile_;
    Mode mode_;
    size_t size_;
    Byte* buffer_;
};

const ScopedFile::Mode SF_READ  = ScopedFile::Mode::Read;
const ScopedFile::Mode SF_WRITE = ScopedFile::Mode::Write;

}
}
