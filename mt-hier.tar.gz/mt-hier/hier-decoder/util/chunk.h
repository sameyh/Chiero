#pragma once

#include "util/types.h"

namespace herbal {
  namespace util {

 typedef long unsigned int size_t;

    template <typename T>
    class Chunk {
      public:
        typedef T value_type;

        Chunk() : ptr_(0) {}
        Chunk(T* address) : ptr_(address) {}

        template <typename P>
        Chunk& operator=(P* address) {
          Set((T*)address);
          return *this;
        }

        Chunk& operator=(T value) {
          *ptr_ = value;
          return *this;
        }

        template <typename P>
        void Set(P* address) {
          ptr_ = (T*)address;
        }

        operator T() const {
          return *ptr_;
        }

        T& operator*() {
          return *ptr_;
        }

        T* data() {
          return ptr_;
        }

        const T* data() const {
          return ptr_;
        }

      protected:
        T* ptr_;
    };

    template <typename T>
    class ManyChunks {
      public:
        typedef T value_type;

        ManyChunks() : ptr_(0), size_(0) {}
        ManyChunks(size_t size) : ptr_(0), size_(size) {}
        ManyChunks(T* address, size_t size) : ptr_(address), size_(size) {}

        template <typename P>
        void Set(P* address) {
          ptr_ = (T*)address;
        }

        inline T& operator[](size_t i) {
          return ptr_[i];
        }

        inline const T& operator[](size_t i) const {
          return ptr_[i];
        }

        size_t size() const {
          return size_;
        }

        void resize(size_t size) {
          size_ = size;
        }

        T* begin() {
          return data();
        }

        T* end() {
          return data() + size();
        }

        const T* begin() const {
          return data();
        }

        const T* end() const {
          return data() + size();
        }

        ManyChunks& operator()(size_t size) {
          resize(size);
          return *this;
        }

        inline T* data() {
          return ptr_;
        }

        inline const T* data() const {
          return ptr_;
        }

      protected:
        T* ptr_;
        size_t size_;
    };

    typedef Chunk<uint8_t>  Chunk8;
    typedef Chunk<uint16_t> Chunk16;
    typedef Chunk<uint32_t> Chunk32;
    typedef Chunk<uint64_t> Chunk64;

    typedef ManyChunks<uint8_t>  ManyChunks8;
    typedef ManyChunks<uint16_t> ManyChunks16;
    typedef ManyChunks<uint32_t> ManyChunks32;
    typedef ManyChunks<uint64_t> ManyChunks64;

    typedef Chunk<const uint8_t>  ChunkC8;
    typedef Chunk<const uint16_t> ChunkC16;
    typedef Chunk<const uint32_t> ChunkC32;
    typedef Chunk<const uint64_t> ChunkC64;

    typedef ManyChunks<const uint8_t>  ManyChunksC8;
    typedef ManyChunks<const uint16_t> ManyChunksC16;
    typedef ManyChunks<const uint32_t> ManyChunksC32;
    typedef ManyChunks<const uint64_t> ManyChunksC64;

  }
}
