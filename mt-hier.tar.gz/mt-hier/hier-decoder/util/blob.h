#pragma once

#include <cstdio>
#include <cstdlib>
#include <sys/mman.h>
#include <utility>

#include "util/types.h"
#include "util/chunk.h"
#include "util/scoped_file.h"

namespace herbal {
namespace util {

    class Blob;

    class Blobbed {
        friend class Blob;

      public:
        Blobbed() : data_(NULL), size_(0) {}

        Byte* data() {
          return data_;
        }

        size_t size() const {
          return size_;
        }

        bool Read(const std::string& file) {
          try {
            ScopedFile sf(file);
            sf.Read(data_, size_);
            return true;
          }
          catch(util::Exception& e) {
            return false;
          }
        }

        bool Write(const std::string& file) {
          try {
            ScopedFile sf(file, SF_WRITE);
            sf.Write(data_, size_);
            return true;
          }
          catch(util::Exception& e) {
            return false;
          }
        }

        Byte* begin() {
          return data_;
        }

        Byte* end() {
          return data_ + size_;
        }

      protected:

        virtual void MapBlob(Blob&) = 0;

        void SetMemory(Byte* data, size_t size) {
            data_ = data;
            size_ = size;
        }

      private:

        Byte* data_;
        size_t size_;
    };

    class Blob {
      public:

        enum struct Mode { Populate, Lazy };


        Blob()
        : data_(0), size_(0), pos_(0),
          allocated_(false), mapped_(false), mappedFile_(NULL) {}

        Blob(Blob&& o)
         : data_(std::move(o.data_)), size_(std::move(o.size_)), pos_(std::move(o.pos_)),
           allocated_(std::move(o.allocated_)), mapped_(std::move(o.mapped_)),
           mappedFile_(std::move(o.mappedFile_))
        {}

        Blob(ScopedFile &sf, Mode mode = Mode::Populate)
        : data_(0), size_(0), pos_(0),
          allocated_(false), mapped_(false), mappedFile_(NULL) {
          Map(sf, mode);
        }

        virtual ~Blob() {
          if(allocated_)
            Deallocate();
          if(mapped_)
            Unmap();
        }

        bool Read(const std::string& file) {
          ScopedFile sf(file);
          Allocate(sf.Size());
          sf.Read(data_, size_);
          return true;
        }

        bool Read(ScopedFile& sf) {
          Allocate(sf.Size());
          sf.Read(data_, size_);
          return true;
        }

        bool Write(const std::string& file) const {
          ScopedFile sf(file, ScopedFile::Mode::Write);
          sf.Write(data_, size_);
          return true;
        }

        virtual bool Write(ScopedFile& sf) const {
          sf.Write(data_, size_);
          sf.Flush();
          return true;
        }

        bool Map(const std::string& file,
                 ScopedFile::Mode mode = ScopedFile::Mode::Read,
                 Mode mapmode = Mode::Populate) {
          if(mapped_)
            Unmap();
          mappedFile_.reset(new ScopedFile(file, mode));
          Map(*mappedFile_, mapmode);
          return true;
        }

        void Map(ScopedFile& sf, Mode mode = Mode::Populate) {
          sf.Rewind();
          if(mapped_)
            Unmap();

          int flags = MAP_SHARED;
          if(mode == Mode::Populate)
            flags |= MAP_POPULATE;

          data_ = (Byte*) mmap(NULL, sf.Size(), sf.GetProtection(),
                               flags, sf.GetFileDescriptor(), 0);
          size_ = sf.Size();
          mapped_ = true;
        }

        void Unmap() {
          munmap(data_, size_);
          size_ = 0;
          mapped_ = false;
          mappedFile_.release();
        }

        void Allocate(size_t size) {
          data_ = new Byte[size];
          size_ = size;
          allocated_ = true;
        }

        void Deallocate() {
          delete[] data_;
          size_ = 0;
          allocated_ = false;
        }

        template <class T>
        Blob& operator>>(Chunk<T> &p) {
          p.Set(CurrentData());
          pos_ += sizeof(typename Chunk<T>::value_type);
          return *this;
        }

        template <class T>
        Blob& operator>>(ManyChunks<T> &p) {
          p.Set(CurrentData());
          pos_ += sizeof(typename ManyChunks<T>::value_type) * p.size();
          return *this;
        }

        virtual Blob& operator>>(Blobbed& blobbed) {
          Byte* start = CurrentData();
          blobbed.MapBlob(*this);
          Byte* end = CurrentData();
          blobbed.SetMemory(start, end - start);
          return *this;
        }

        virtual Blob& operator>>(ScopedFile& sf) {
            Write(sf);
            return *this;
        }

        Blob& operator<<(Blob& blob) {
          std::copy(blob.begin(), blob.end(), begin() + pos_);
          pos_ += blob.size();
          return *this;
        }

        operator bool() const {
            return pos_ != size_;

        }

        Byte& operator[](size_t i) {
            return data_[i];
        }

        Byte& operator[](size_t i) const {
            return data_[i];
        }

        Byte* data() {
          return data_;
        }

        Byte* begin() {
          return data_;
        }

        Byte* end() {
          return data_ + size_;
        }

        const Byte* data() const {
          return data_;
        }

        const Byte* begin() const {
          return data_;
        }

        const Byte* end() const {
          return data_ + size_;
        }

        size_t size() const {
          return size_;
        }

        size_t Size() const {
          return size();
        }

        void Rewind() {
          pos_ = 0;
        }

        void Swap(Blob& blob) {
          std::swap(data_, blob.data_);
          std::swap(size_, blob.size_);
          std::swap(pos_, blob.pos_);
          std::swap(allocated_, blob.allocated_);
          std::swap(mapped_, blob.mapped_);
          std::swap(mappedFile_, blob.mappedFile_);
        }

      protected:

        Byte* CurrentData() {
          return data_ + pos_;
        }

        Byte* data_;
        size_t size_;
        size_t pos_;

        bool allocated_;
        bool mapped_;
        std::auto_ptr<ScopedFile> mappedFile_;
    };

    Blob& operator>>(ScopedFile& sf, Blob& blob);

    template <typename T>
    class TypedBlob : public Blob {
      public:
        typedef T value_type;

        TypedBlob() : Blob() {};
        TypedBlob(ScopedFile &sf) : Blob(sf) {};

        virtual T& operator[](size_t i) {
          return data()[i];
        }

        virtual T* begin() {
          return (T*) Blob::begin();
        }

        virtual T* end() {
          return (T*) Blob::end();
        }

        virtual T* data() {
          return (T*) Blob::data();
        }

        virtual T& operator[](size_t i) const {
          return data()[i];
        }

        virtual T* begin() const {
          return (T*) Blob::begin();
        }

        virtual T* end() const {
          return (T*) Blob::end();
        }

        virtual T* data() const {
          return (T*) Blob::data();
        }

        virtual size_t size() const {
          return Blob::size() / sizeof(T);
        }
    };

}
}
