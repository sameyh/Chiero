#include "exception.h"

#include <errno.h>
#include <string.h>

namespace herbal {
namespace util {

Exception::Exception() throw() {}
Exception::~Exception() throw() {}

Exception::Exception(const Exception &from) : std::exception() {
  stream_ << from.stream_.str();
}

const char *Exception::what() const throw() {
  text_ = stream_.str();
  return text_.c_str();
}

void Exception::SetInfo(
        const char *file,
        unsigned int line,
        const char *func,
        const char *condition,
        const char *message) {
  text_ = stream_.str();
  stream_.str("");
  stream_ << file << ':' << line << " in " << func;
  stream_ << " threw an exception because " << condition;
  stream_ << " (" << message << ")."  << std::endl;
}

}
}
