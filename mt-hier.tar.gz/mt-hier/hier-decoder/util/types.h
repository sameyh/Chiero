#pragma once

#include <cstdint>

namespace herbal {
    typedef uint8_t Byte;
}
