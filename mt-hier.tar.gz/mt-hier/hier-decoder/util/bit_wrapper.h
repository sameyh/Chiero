#pragma once

#include <string>
#include <algorithm>

namespace herbal {
  namespace util {

    class BitWrapper
    {
    private:
      std::vector<uint8_t>& m_data;
      const uint8_t m_exp = 3;
      const uint8_t m_bits = 1U << m_exp;
      size_t m_bitSize;

    public:

      BitWrapper(std::vector<uint8_t>& data);

      bool GetBit(size_t i);

      void SetBit(size_t i);

      void FlipBit(size_t i);

      void ClearBit(size_t i);

      void ChangeBit(size_t i, bool value);

      uint64_t GetBits(size_t i, size_t length);

      void SetBits(size_t i, uint64_t value, size_t length);

      void ClearBits(size_t i, uint64_t value, size_t length);

      void PushBits(uint64_t value, const size_t length);

      void PushBit(bool bit);

      std::vector<uint8_t>& GetContainer();

      void Resize(size_t size);

      size_t GetBitSize() const;

      size_t GetByteSize() const;
    };

  }
}

