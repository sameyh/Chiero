#pragma once

#include "util/string_piece.h"
#include <boost/functional/hash.hpp>

namespace herbal {
  namespace util {
  
    inline size_t hash_value(const StringPiece &str) {
      return boost::hash_range(str.data(), str.data() + str.length());
    }
  
  }
}

namespace std
{
    template<>
    struct hash<herbal::util::StringPiece>
    {
        typedef herbal::util::StringPiece argument_type;
        typedef std::size_t result_type;
 
        result_type operator()(argument_type const& s) const
        {
            return hash_value(s);
        }
    };
}
