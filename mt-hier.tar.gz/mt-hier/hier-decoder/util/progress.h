#pragma once

#include <iostream>
#include <boost/progress.hpp>

namespace herbal {
  namespace util {

    class Progress {
      public:
        Progress(const size_t& total, const std::string& message, std::ostream& out = std::cerr)
        : message_(message), out_(out), d_(0), t_(0)
        {
          out_ << "=== " << message_ << " ===" << std::endl;
          d_ = new boost::progress_display(total, out_, "");
          t_ = new boost::timer();
        }

        ~Progress() {
          out_ << "Elapsed time: " << t_->elapsed() << " s" << std::endl << std::endl;
          delete d_;
          delete t_;
        }

        Progress& operator++() {
          ++(*d_);
          return *this;
        }

      private:
        std::string message_;
        std::ostream& out_;
        boost::progress_display* d_;
        boost::timer* t_;
    };

  }
}
