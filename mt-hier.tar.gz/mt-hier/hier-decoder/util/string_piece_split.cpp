#include "util/string_piece_split.h"

namespace herbal {
  namespace util {
    void split(std::vector<StringPiece>& c,
                const StringPiece& s,
                const StringPiece& sep) {
        size_t pos = 0;
        size_t found = s.find(sep, pos);
        while(found != herbal::util::StringPiece::npos) {
        c.push_back(s.substr(pos, found - pos));
        pos = found + sep.length();
        found = s.find(sep, pos);
        }
        c.push_back(s.substr(pos, s.length() - pos));
    }
  }
}
