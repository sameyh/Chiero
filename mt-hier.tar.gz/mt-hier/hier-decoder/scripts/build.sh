SCRIPTDIR=.

python ${SCRIPTDIR}/moses2prep.py ../../moses-data/rule-table.gz
#perl ${SCRIPTDIR}/binarize_mert.pl --ini $2 --blob $3
perl ${SCRIPTDIR}/binarize.pl --ini ../../moses-data/moses.ini --blob ../../model/chart-model.blob
rm vocab* lm.bin tm.bin
