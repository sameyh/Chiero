def fun(f,s):
	para = s.strip().split()
	mdict={}
	for i in range(len(para)):
		if 'LM0=' in para[i] or 'WordPenalty0=' in para[i] or 'PhrasePenalty0=' in para[i] or 'GluePenalty0=' in para[i]:
			mdict[para[i]] = [para[i+1]]
		elif 'TranslationModel0=' in para[i]:
			mdict[para[i]] = para[i+1:i+5]
	flag = True
	fp = open(f)
	for l in fp:
		for a in mdict.keys():
			if l.strip().startswith(a):
				print a,' '.join(e for e in mdict[a])
				flag = False
				break
		if flag:
			print l.strip()

import sys
fun(sys.argv[1],sys.argv[2])

