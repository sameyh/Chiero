#!/usr/bin/env perl

use warnings;
use strict;
use Getopt::Long "GetOptions";
use FindBin qw($RealBin);
use Data::Dumper;

my ($PT, $LM, $WCLM, $OSM, $WCLMCLS, $HP, $INI, $BLOB, $LR, $RECASER, $SIMPLE, $FORCE);

die("binarize.pl -lm lm -wclm wclm -pt phrase_table -lr lr_table -ini moses.ini [-osm osm] [-path path_to_bin] [-blob blob] [-recaser]")
    unless  &GetOptions('lm=s' => \$LM,
                        'wclm=s' => \$WCLM,
                        'osm=s' => \$OSM,
                        'wclm-classes=s' => \$WCLMCLS,
                        'pt=s' => \$PT,
                        'lr=s' => \$LR,
                        'ini=s' => \$INI,
                        'path=s' => \$HP,
                        'blob=s' => \$BLOB,
                        'force-overwrite' => \$FORCE);


sub parse_ini()
{
    my %weights = ();
    my %features = ();
    my $INI_PATH = $_[0];
    open my $FILE, $INI_PATH or die("Could not open $INI_PATH");
    my $section = 0;
    while (my $line = <$FILE>) {
        chomp $line;
        if ($line =~ m/^\#/  or $line eq "") {
            next;
        }
        elsif ($line =~ m/^\[(.+)\]$/) {
            $section = $1;
            next;
        }
        elsif ($section eq "weight") {
            if ($line =~ m/^([^=]+)\s*=\s*([^=]+)$/) {
                $weights{$1} = $2;
            }
        }
        elsif ($section eq "feature") {
            if ($line =~ m/^(\S+)\s.*?name=(\S+)(.+)/) {
		my $ff_type = $1;
                my $ff_name = $2;
                my $options_str = $3;
                my @ff_options = $options_str =~ /(\S+)=(\S+)\b/g;
                my %ops = @ff_options;
                $features{$ff_name} = \%ops;
		$features{$ff_name}{'type'} = $ff_type;
            }
        }
    }
    return (\%weights, \%features);
}

sub binarize_vocab
{
    my $HP = "$RealBin/../build/bin" unless $HP;
    my $PT_PATH = shift(@_);
    my $vocab_bin = "vocab.bin";

    if (not -e "vocab.pt.txt") {
        print "Creating vocab from the phrase table...\n";
        mySystem("zcat $PT_PATH | $HP/pt_vocab > vocab.pt.txt");
    }

    my $lm_counter = -1;
    for my $lm_path (@_) {
        ++$lm_counter;
        if (not -e "vocab.lm$lm_counter.txt") {
            print "Creating vocab from language model LM$lm_counter...\n";
            mySystem("zcat $lm_path | $HP/arpa_vocab > vocab.lm$lm_counter.txt");
        }
    }

    if (not -e "vocab.lm.txt") {
        mySystem("rm -f vocab.lm.txt");
        mySystem("touch vocab.lm.txt");
        while ($lm_counter >= 0) {
            mySystem("cat vocab.lm$lm_counter.txt >> vocab.lm.txt");
            --$lm_counter;
        }
    }

    if (not -e $vocab_bin) {
        print "Collecting and binarizing vocabulary...\n";
        mySystem("cat vocab.lm.txt vocab.pt.txt | $HP/text_vocab > $vocab_bin");
    }
    return $vocab_bin;
}

sub mySystem
{
    my $command = shift;
    print "$command\n";
    my $code = system($command);
    if ($code != 0) {
        exit($code);
    }
}


sub checkBinaries
{
    my $HP = "$RealBin/../build/bin" unless $HP;
    if (! -e "$HP/pt_vocab")   {die("Error: could not find $HP/pt_vocab");}
    if (! -e "$HP/arpa_vocab") {die("Error: could not find $HP/arpa_vocab");}
    if (! -e "$HP/build_lm")   {die("Error: could not find $HP/build_lm");}
    if (! -e "$HP/build_pt")   {die("Error: could not find $HP/build_pt");}
    if (! -e "$HP/build_pt_mert")   {die("Error: could not find $HP/build_pt_mert");}
    if (! -e "$HP/build_lr")   {die("Error: could not find $HP/build_lr");}
    if (! -e "$HP/build_dp")   {die("Error: could not find $HP/build_dp");}
    if (! -e "$HP/text_vocab") {die("Error: could not find $HP/text_vocab");}
}

sub build_dp
{
    my $HP = "$RealBin/../build/bin" unless $HP;
    my $weight = shift;
    my $dp_output = "dp.bin";
    if (not -e $dp_output or $FORCE) {
        mySystem(
        "$HP/build_dp "
        . "--output $dp_output "
        . "--w $weight "
        . "2>&1"
        );
    }
    return $dp_output;
}
sub build_lr
{
    my $HP = "$RealBin/../build/bin" unless $HP;
    my $vocab_bin = shift;
    my $lr_path = shift;
    my $weights = shift;
    my $lr_output = "lr.bin";
    if (not -e $lr_output or $FORCE) {
        mySystem(
        "zcat $lr_path | $HP/build_lr "
        . "--vocab $vocab_bin "
        . "--output $lr_output "
        . "--w $weights "
        . "2>&1"
        );
    }
    return $lr_output;
}

sub build_lm
{
    my $HP = "$RealBin/../build/bin" unless $HP;
    my $vocab_bin = shift;
    my $lm_path = shift;
    my $lm_weights = shift;
    my $lm_bin = "lm.bin";
    if (not -e "lm.bin" or $FORCE) {
        print "Binarizing language model...\n";
        mySystem("zcat $lm_path | $HP/build_lm"
            . " --vocab $vocab_bin"
            . " --w $lm_weights"
            . " --output $lm_bin 2>&1");
    }
    return $lm_bin;
}

sub build_wclm
{
    my $HP = "$RealBin/../build/bin" unless $HP;
    my $vocab_bin = shift;
    my $lm_path = shift;
    my $lm_weights = shift;
    my $classes = shift;
    my $lm_bin = "wclm.bin";
    if (not -e $lm_bin or $FORCE) {
        print "Binarizing word class based language model...\n";
        mySystem("zcat $lm_path | $HP/build_lm"
            . " --vocab $vocab_bin"
            . " --classes $classes"
            . " --w $lm_weights"
            . " --output $lm_bin 2>&1");
    }
    return $lm_bin;
}

sub build_osm
{
    my $HP = "$RealBin/../build/bin" unless $HP;
    my $vocab_bin = shift;
    my $lm_path = shift;
    my $lm_weights = shift;
    my $lm_bin = "osm.bin";
    if (not -e $lm_bin or $FORCE) {
        print "Binarizing word class based language model...\n";
        mySystem("zcat $lm_path | $HP/build_lm"
            . " --vocab $vocab_bin"
            . " --osm"
            . " --output $lm_bin 2>&1");
    }
    return $lm_bin;
}

sub build_pt
{
    my $HP = "$RealBin/../build/bin" unless $HP;
    my $vocab_bin = shift;
    my $tm_path = shift;
    my $tm_weights = shift;
    my $wp_weight = shift;
    my $pp_weight = shift;
    my $lms = shift;
    my $tm_bin = "tm.bin";

    if (not -e $tm_bin or $FORCE) {
        print "Binarizing phrase table...\n";
        mySystem("zcat $tm_path | $HP/build_pt"
            . " --vocab $vocab_bin"
            . " --tm-weights $tm_weights"
            . " --word-penalty $wp_weight"
            . " --phrase-penalty $pp_weight"
            . " --lm $lms"
            . " --output $tm_bin 2>&1");
    }
    return $tm_bin;

}
sub build_pt_mert
{
    my $HP = "$RealBin/../build/bin" unless $HP;
    my $vocab_bin = shift;
    my $tm_path = shift;
    my $tm_weights = shift;
    my $wp_weight = shift;
    my $pp_weight = shift;
    my $glue_weight = shift;
	my $lm_weight = shift;
    my $lms = shift;
    my $tm_bin = "tm.bin";

    if (not -e $tm_bin or $FORCE) {
        print "Binarizing phrase table...\n";
        mySystem("zcat $tm_path | $HP/build_pt_mert"
            . " --vocab $vocab_bin"
            . " --tm-weights $tm_weights"
            . " --word-penalty $wp_weight"
            . " --phrase-penalty $pp_weight"
            . " --glue-penalty $glue_weight"
			. " --lm-penalty $lm_weight"
            . " --lm $lms"
            . " --output $tm_bin 2>&1");
    }
    return $tm_bin;

}
sub main
{
    $BLOB = "blob.bin" unless $BLOB;
    print "Start binarizing...\n\n";


    die("Error: no moses INI file.") unless $INI;
    print "Moses INI file: $INI\n";
    print "Parsing INI file...";

    my ($WEIGHTS, $FFS) = &parse_ini($INI);

    my %WEIGHTS = %$WEIGHTS;
    my %FFS = %$FFS;

    $PT = $FFS{"TranslationModel0"}{"path"} unless defined($PT);
    $LR = $FFS{"LexicalReordering0"}{"path"} unless defined($LR);
    $LM = $FFS{"LM0"}{"path"} unless defined($LM);

    my $vocab_bin = binarize_vocab($PT, $LM);
    my @lms = ();
    my @ff_bins = ();
	
	my $lm_weight_mert =1;
    push @lms, build_lm($vocab_bin, $LM, $lm_weight_mert);

    if (exists $FFS{"GenerationModel0"}) {
        $FFS{"LM1"}{"path"} = $WCLM if defined($WCLM);
        $FFS{"GenerationModel0"}{"path"} = $WCLMCLS if defined($WCLMCLS);
        push @lms, build_wclm($vocab_bin, $FFS{"LM1"}{"path"},
                 $WEIGHTS{"LM1"}, $FFS{"GenerationModel0"}{"path"});
    }

    if (exists $FFS{"OpSequenceModel0"}) {
        $FFS{"OpSequenceModel0"}{"path"} = $OSM if defined($OSM);
        # push @lms, build_osm($vocab_bin, $FFS{"OpSequenceModel0"}{"path"},
                 # $WEIGHTS{"OpSequenceModel0"});
    }
    if (exists $WEIGHTS{"Distortion0"}) {
        push @ff_bins, build_dp($WEIGHTS{"Distortion0"});
    }

    $WEIGHTS{"PhrasePenalty0"} = 0.0 unless exists $WEIGHTS{"PhrasePenalty0"};
    $WEIGHTS{"GluePenalty0"} = 0.0 unless exists $WEIGHTS{"PhrasePenalty0"};
    my $pt_bin = build_pt_mert($vocab_bin, $PT, $WEIGHTS{"TranslationModel0"},
                                           $WEIGHTS{"WordPenalty0"},
                                           $WEIGHTS{"PhrasePenalty0"},
                                           $WEIGHTS{"GluePenalty0"},
										   $WEIGHTS{"LM0"},
                                           "@lms");

    if (exists $FFS{"LexicalReordering0"}) {
        $FFS{"LexicalReordering0"}{"path"} = $LR if defined($LR);
		###push @ff_bins, build_lr($vocab_bin, $FFS{"LexicalReordering0"}{"path"},
		###         $WEIGHTS{"LexicalReordering0"});
    }

    push @ff_bins, @lms;
    mySystem("cat $vocab_bin $pt_bin @ff_bins > $BLOB");
}

main();

