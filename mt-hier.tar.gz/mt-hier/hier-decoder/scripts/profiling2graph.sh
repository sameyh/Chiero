#!/bin/sh

#Usage:
# * $1 - path to <dec> binary
# * $2 - path to profiling output file

DEC_BIN=$1
PROFIL_OUT=$2
FORMAT=${3:-pdf}
DOT_FILE=`echo $PROFIL_OUT | sed "s/out$/dot/"`
PNG_FILE=`echo $PROFIL_OUT | sed "s/out$/$FORMAT/"`

google-pprof --dot $DEC_BIN $PROFIL_OUT > $DOT_FILE
dot -T$FORMAT $DOT_FILE > $PNG_FILE
echo "Graph saved to $PNG_FILE."

