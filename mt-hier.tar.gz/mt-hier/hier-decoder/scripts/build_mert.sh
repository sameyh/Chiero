SCRIPTDIR=/home/meitu/work/smt/pol/mt-decoder/hier-decoder/scripts

perl ${SCRIPTDIR}/binarize_mert.pl --ini $1 --blob $2
#perl ${SCRIPTDIR}/binarize.pl --ini $1 --blob $2
