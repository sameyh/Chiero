import math,sys,gzip
def loaddict(aligns):
	md = {}
	for x in aligns:
		s,t=x.strip().split('-')
		if s in md:
			md[int(s)].append(int(t))
		else:
			md[int(s)] = [int(t)]
	return md

def moses2preprocess(f):
	fp = gzip.open(f)
	fo = gzip.open(f[:-3]+".x1.gz",'w')
	for l in fp:
		src, tgt, prob_str, align, _ = l.strip().split(' ||| ',4)
		newsrc = src.strip().rsplit(' [X]',1)[0]
		newtgt = tgt.strip().rsplit(' [X]',1)[0]
		probs = [math.log(float(x)+1e-18) for x in prob_str.strip().split()]
		mdict = loaddict(align.strip().split())
				
	
		newsrcvec = newsrc.strip().split()
		newtgtvec = newtgt.strip().split()
		count = 0
		markindex = []
		for i in range(len(newsrcvec)):
			if newsrcvec[i]=='[X][X]':
				markindex.append(i)
				count += 1
		if len(markindex)>0:
			count = 1
			for i in markindex:
				indextgt = mdict[i][0]
				newtgtvec[indextgt] = "[X%s][X%s]" % (str(count),str(count))
				newsrcvec[i] =  '[X%s][X%s]' % (str(count),str(count))
				count +=1	
		
		fo.write( '%s ||| %s ||| %s ||| %s' % (' '.join(x for x  in newsrcvec), ' '.join(x for x in newtgtvec), ' '.join(['%f' % x for x in probs]), align) )
		fo.write('\n');
		#print '%s ||| %s ||| %s' % (' '.join(x for x  in newsrcvec), ' '.join(x for x in newtgtvec), ' '.join(['%f' % x for x in probs]))

moses2preprocess(sys.argv[1])


