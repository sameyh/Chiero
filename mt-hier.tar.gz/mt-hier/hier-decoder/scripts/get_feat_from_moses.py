def fun(f):
	fp = open(f)
	flag = False
	for l in fp:
		if flag:
			l = l.strip()
			if len(l) > 0 and not l.startswith('#'):
				print l
		if l.strip().startswith('[weight]'):
			flag = True

import sys
fun(sys.argv[1])
			

