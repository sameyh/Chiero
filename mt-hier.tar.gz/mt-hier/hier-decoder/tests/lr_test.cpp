#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE LRTests
#include <boost/test/unit_test.hpp>

#include <boost/progress.hpp>

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <ctime>
#include <cmath>
#include <cstdlib>

#include "lr/lr_scores.h"

using namespace herbal;

bool compare_float(float a, float b, float eps = 0.00001) {
    float diff = fabs(a - b);
    return diff < eps;
}

BOOST_AUTO_TEST_CASE(DefaultLRScores)
{
    LRScores lrScores;
    for (auto& score : lrScores ) {
        BOOST_CHECK(compare_float(0.0, score));
    }
    std::cerr << std::endl;
}

BOOST_AUTO_TEST_CASE(SetLRScores)
{
    float tab[6] = {1.0,2.0,3.0,4.0,5.0,6.0};
    LRScores lrScores(tab);
    for (size_t i = 0; i < LRScores::ScoreNumber; ++i) {
        BOOST_CHECK(compare_float(float(i + 1), lrScores[i]));
    }
}

BOOST_AUTO_TEST_CASE(GetReorderingTypes)
{
    float tab[6] = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
    LRScores lrScores(tab);

    BOOST_CHECK_EQUAL(lrScores.GetReorderingType(1, 3, 4, 5), LRScores::M);
    BOOST_CHECK_EQUAL(lrScores.GetReorderingType(6, 10, 4, 5), LRScores::S);
    BOOST_CHECK_EQUAL(lrScores.GetReorderingType(1, 2, 4, 5), LRScores::D);
}

BOOST_AUTO_TEST_CASE(ScoreBackward)
{
    float tab[6] = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
    LRScores lrScores(tab);

    BOOST_CHECK(compare_float(lrScores.ScoreBackward(1, 3, 4, 5), 0));
    BOOST_CHECK(compare_float(lrScores.ScoreBackward(6, 10, 4, 5), 1));
    BOOST_CHECK(compare_float(lrScores.ScoreBackward(1, 2, 4, 5), 2));
}

BOOST_AUTO_TEST_CASE(ScoreForward)
{
    float tab[6] = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
    LRScores lrScores(tab);

    BOOST_CHECK(compare_float(lrScores.ScoreForward(1, 3, 4, 5), 3));
    BOOST_CHECK(compare_float(lrScores.ScoreForward(6, 10, 4, 5), 4));
    BOOST_CHECK(compare_float(lrScores.ScoreForward(1, 2, 4, 5), 5));
}
