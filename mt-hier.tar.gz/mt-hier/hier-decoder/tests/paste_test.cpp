#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE PasteTests
#include <boost/test/unit_test.hpp>

#include <boost/progress.hpp>

#include <string>

#include "pt/paste.h"
#include "pt/builder/paste_builder.h"

BOOST_AUTO_TEST_CASE(Paste)
{
  std::vector<std::string> sources = {"this", "is", "a", "key",
                                      "for", "the", "MPH"};
  
  std::vector<std::vector<std::string>> targets = {
    {"der ||| 0.1", "die ||| 0.1", "das ||| 0.2", "dies ||| 0.6"},
    {"ist ||| 0.9", "sind ||| 0.1"},
    {"ein ||| 0.8", "eine ||| 0.2"},
    {"Schluessel ||| 0.6" , "Eintrag ||| 0.4"},
    {"fuer ||| 1.0"},
    {"der ||| 0.33", "die ||| 0.33", "das ||| 0.33"},
    {"MPH ||| 0.9", "die MPH ||| 0.1"}
  };
  
  herbal::util::ScopedFile pasteFile;
  herbal::PasteBuilder(sources, targets) >> pasteFile;
  
  herbal::util::Blob pasteBlob;
  herbal::Paste paste;
  pasteFile >> pasteBlob >> paste;

  for(size_t i = 0; i < sources.size(); ++i) {
    herbal::TargetPhrases tp = paste[sources[i]];
    BOOST_CHECK_EQUAL(tp.size(), targets[i].size());
    for(size_t j = 0; j < targets[i].size(); ++j) {
      //std::cerr << sources[i] << " ||| " << tp[j] << std::endl;
      //BOOST_CHECK_EQUAL(tp[j], targets[i][j]);
    }
  }

  std::string oov("NOT IN PHRASE TABLE");
  BOOST_CHECK_EQUAL(paste[oov].size(), 0);
}

BOOST_AUTO_TEST_CASE(DoubleThePaste)
{
  std::vector<std::string> sources = {"this", "is", "a", "key",
                                      "for", "the", "MPH"};
  
  std::vector<std::vector<std::string>> targets = {
    {"der ||| 0.1", "die ||| 0.1", "das ||| 0.2", "dies ||| 0.6"},
    {"ist ||| 0.9", "sind ||| 0.1"},
    {"ein ||| 0.8", "eine ||| 0.2"},
    {"Schluessel ||| 0.6" , "Eintrag ||| 0.4"},
    {"fuer ||| 1.0"},
    {"der ||| 0.33", "die ||| 0.33", "das ||| 0.33"},
    {"MPH ||| 0.9", "die MPH ||| 0.1"}
  };
  
  herbal::util::ScopedFile modelFile;
  {
    herbal::PasteBuilder pasteBuilder(sources, targets);
    pasteBuilder >> modelFile;
    pasteBuilder >> modelFile;
  } // Let pasteBuilder go out of scope
  
  herbal::util::Blob mapper;
  herbal::Paste pt1, pt2;
  modelFile >> mapper >> pt1 >> pt2;

  for(size_t i = 0; i < sources.size(); ++i) {
    herbal::TargetPhrases tp1 = pt1[sources[i]];
    herbal::TargetPhrases tp2 = pt2[sources[i]];
    BOOST_CHECK_EQUAL(tp1.size(), tp2.size());
    for(size_t j = 0; j < tp1.size(); ++j) {
      //std::cerr << sources[i] << " ||| " << tp1[j] << std::endl;
      //BOOST_CHECK_EQUAL(tp1[j], tp2[j]);
    }
  }

  std::string oov("NOT IN PHRASE TABLE");
  BOOST_CHECK_EQUAL(pt1[oov].size(), 0);
  BOOST_CHECK_EQUAL(pt2[oov].size(), 0);
}



