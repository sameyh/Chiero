#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE TargetsTests
#include <boost/test/unit_test.hpp>

#include <boost/progress.hpp>

#include <iostream>
#include <string>

#include "pt/targets.h"
#include "pt/builder/targets_builder.h"

BOOST_AUTO_TEST_CASE(targets)
{
  
  std::vector<std::vector<std::string>> trans = {
    {"der ||| 0.1", "die ||| 0.1", "das ||| 0.2", "dies ||| 0.6"},
    {"ist ||| 0.9", "sind ||| 0.1"},
    {"ein ||| 0.8", "eine ||| 0,2"},
    {"Schluessel ||| 0.6" , "Eintrag ||| 0.4"},
    {"fuer ||| 1.0"},
    {"der ||| 0.33", "die ||| 0.33", "das ||| 0.33"},
    {"MPH ||| 0.9", "die MPH ||| 0.1"}
  };
  
  herbal::Targets targets;
  herbal::TargetsBuilder targetsBuilder(trans);
  std::cout << "test size: " << targetsBuilder.Size() << std::endl;
  std::cout << "test data: " << targetsBuilder.data() << std::endl;
  
  targetsBuilder >> targets;

  for(size_t i = 0; i < trans.size(); ++i) {
    herbal::TargetPhrases tp = targets[i];
    BOOST_CHECK_EQUAL(tp.size(), trans[i].size());
    for(size_t j = 0; j < trans[i].size(); ++j) {
      //BOOST_CHECK_EQUAL(tp[j], trans[i][j]);
    }
  }  
  
  BOOST_CHECK_EQUAL(targets[trans.size()].size(), 0);
}
