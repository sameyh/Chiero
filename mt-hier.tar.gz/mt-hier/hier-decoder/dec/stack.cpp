#include "dec/stack.h"

namespace herbal {

struct HashSorter {
  bool operator()(const HypothesisPtr& a, const HypothesisPtr& b) const {
    return (a->Hash() < b->Hash() || (a->Hash() == b->Hash() && a->GetCost() > b->GetCost()));
  }
};

struct Hash {
  size_t operator()(const HypothesisPtr& a) const {
    return a->Hash();
  }
};

struct HashEqual {
  bool operator()(const HypothesisPtr& a, const HypothesisPtr& b) const {
    return (a->Hash() == b->Hash());
  }
};

struct CostSorter {
  bool operator()(const HypothesisPtr& a, const HypothesisPtr& b) const {
    return a->TotalCost() > b->TotalCost();
  }
};

bool Stack::Insert(HypothesisPtr h) {
  stack_.push_back(h);
  return true;
}

HypothesisPtr Stack::Best() const {
  return stack_.front();
}

bool Stack::Empty() const {
  return stack_.empty();
}

Stack::vector_type::const_iterator Stack::begin() const {
  return stack_.begin();
}

Stack::vector_type::const_iterator Stack::end() const {
  return stack_.end();
}

void Stack::Prune() {
  SortAndRecombine();
  SortAndPrune();
}

size_t Stack::GetSize() {
  return stack_.size();
}

void Stack::SortAndRecombine() {
  pdqsort(stack_.begin(), stack_.end(), HashSorter());
  auto eraseMe = std::unique(stack_.begin(), stack_.end(), HashEqual());
  if(eraseMe != stack_.end()) {
    stack_.resize(std::distance(stack_.begin(), eraseMe));
  }
}

void Stack::SortAndPrune() {
  pdqsort(stack_.begin(), stack_.end(), CostSorter());
  size_t stackSize = God::Get<size_t>("stack-size");
  if(stack_.size() > stackSize) {
    stack_.resize(stackSize);
  }
}

}
