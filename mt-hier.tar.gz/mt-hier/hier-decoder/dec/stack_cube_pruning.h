#pragma once

#include "dec/stack.h"


namespace herbal {
  
  template<class T=HypothesisPtr>
  struct CostSorterQueue {
    bool operator()(const T& a, const T& b) const {
      return a->TotalCost() < b->TotalCost();
    }
  };

  template<class T>
  class Queue {
    public:
      const T& top(){
	  	return queue_.top();
	  }
      void pop(){
	  	return queue_.pop();
	  }
      void push(const T& hyp){
	     auto it = bestCosts_.find(hyp->Hash());
         if(it == bestCosts_.end() || it->second < hyp->TotalCost()) {
         queue_.push(hyp);
         bestCosts_[hyp->Hash()] = hyp->TotalCost();
	     }
	  }
      bool empty(){
	  	return queue_.empty();
	  }

    private:
      std::priority_queue<T, std::vector<T>, CostSorterQueue<T> > queue_;
      std::unordered_map<size_t, float> bestCosts_;
  };

  class Partition {
    public:
      Partition(const Coverage& coverage, size_t start, size_t end, const TranslationOptions& translationOptions);
      void SetFutureScorePerCoverage(const Coverage& coverage, size_t exStart, size_t exEnd);
      HypothesisPtr Best();
      void QueueNeighbours(const HypothesisPtr& hyp, Queue<HypothesisPtr>& queue);
      void Insert(HypothesisPtr& hyp);

    private:
      size_t start_;
      size_t end_;
      const TranslationOptions& translationOptions_;
      float restCost_;
      std::vector<HypothesisPtr> prevHyps_;
  };

  typedef std::unordered_map<size_t, Partition> Partitions;

  class StackCubePruning : public Stack {
    public:

      void DivideIntoPartitions(const TranslationOptions& translationOptions);
      Partitions& GetPartitions();
      void QueueNeighbours(const HypothesisPtr& hyp, Queue<HypothesisPtr>& queue);

    private:    
      Partitions partitions_;
  };
}
