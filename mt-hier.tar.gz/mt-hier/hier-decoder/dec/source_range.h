#pragma once

#include <limits>

#include "pt/target_phrase.h"
#include "pt/targets.h"
#include "lm/vocab.h"

namespace herbal {

  typedef std::vector<lm::Word> RawSentence;
  
  class SourceRange {
    public:
      SourceRange()
      : sourceStart_(0), sourceEnd_(0), sourceSentence_(0),
        restCost_(-std::numeric_limits<float>::infinity()) {}

      void SetRange(size_t start, size_t end, const RawSentence* sourceSentence) {
        sourceStart_ = start;
        sourceEnd_ = end;
        sourceSentence_ = sourceSentence;
      }

      float GetFutureScore() const {
        return restCost_;
      }

      const TargetPhrases& GetTargetPhrases() const {
        return targetPhrases_;
      }

      void SetFutureScore(float score) {
        restCost_ = score;
      }

      void SetTargetPhrases(TargetPhrases tps) {
        targetPhrases_ = tps;
        for(auto& tp : targetPhrases_)
          tp->SetRange(this);
        restCost_ = 0;
        restCost_ += targetPhrases_.front()->GetScores()[0];
        restCost_ += targetPhrases_.front()->GetScores()[1];
      }

      size_t Start() const {
        return sourceStart_;
      }

      size_t End() const {
        return sourceEnd_;
      }

      const lm::Word* begin() const {
          return &(*sourceSentence_)[sourceStart_];
      }

      const lm::Word* end() const {
          return &(*sourceSentence_)[sourceEnd_ + 1];
      }

      const RawSentence* GetSentence() const {
        return sourceSentence_;
      }

    private:
      size_t sourceStart_;
      size_t sourceEnd_;
      const RawSentence* sourceSentence_;
      float restCost_;
      TargetPhrases targetPhrases_;
  };
  
  class XSourceRange:public SourceRange
  {
	public:
	  XSourceRange():SourceRange(){}
	  void SetTargetXPhrases(const TargetXPhrases &tps) {
        targetXPhrases_ = tps;
        for(auto& tp : targetXPhrases_)
          tp->SetRange(this);
        //restCost_ = 0;
        //restCost_ += targetXPhrases_.front()->GetScores()[0];
        //restCost_ += targetXPhrases_.front()->GetScores()[1];
      }
	  const TargetXPhrases& GetTargetXPhrases() const {
        return targetXPhrases_;
      }
	  void SetXRange(size_t start, size_t end)
	  {
	  	m_xspan.emplace_back(start,end);
	  }
	  size_t XSize() const{
	  	return m_xspan.size();
	  }
	  size_t X1Start() const{
	  	return m_xspan[0].first;
	  }
	  size_t X1Back() const{
	  	return m_xspan[0].second;
	  }
	  size_t X2Start() const{
	  	return m_xspan[1].first;
	  }
	  size_t X2Back() const{
	  	return m_xspan[1].second;
	  }
	  
	private:
	  TargetXPhrases targetXPhrases_;
	  typedef std::pair<size_t , size_t > SPAN;
	  std::vector<SPAN> m_xspan;	  

  };


  typedef SourceRange* SourceRangePtr;
  typedef XSourceRange* XSourceRangePtr; 
  typedef  std::vector<XSourceRangePtr>  XSourceRangePool;
  typedef std::shared_ptr<XSourceRangePool> XSourceRangePoolPtr;
}


