#pragma once

#include "dec/sentence.h"
#include "dec/source_range.h"
#include "dec/coverage.h"
#include "dec/hypothesis.h"
#include "lm/ngram.h"

namespace herbal {

typedef std::pair<size_t, size_t> Range;
typedef std::vector<Range> Ranges;
typedef std::unordered_map<size_t, Ranges> RangesCache;

/**
 * @brief Holds the translation options for a given source sentence per source
 * word range. With all possible ranges it also precalculates future score
 * penalties used during decoding as heuristc weights. 
 */
class TranslationOptions {
  public:
    
    /**
     * @brief Constructor
     *
     * On creating the constructor queries the translation model for possible
     * translation for all found matching word ranges and next calculates
     * future scores. 
     *
     * @param sentence The source sentence.
     */
    TranslationOptions(const Sentence& sentence);
    
    /**
     * @brief Retreive source range information
     *
     * Returns a SourceRange object that holds translations and heuristc weights
     * for the current range. Range values overlap, i.e. start=1, end=1 denotes
     * a phrase of size 1.
     *
     * @param start Starting index of the source phrase
     * @param end End index of the source phrase
     */
    const SourceRange* operator()(size_t start, size_t end) const {
        return wordRanges_[start][end];
    }
    
	/**
     * @brief Retreive source range information
     *
     * Returns a SourceRange object that holds translations and heuristc weights
     * for the current range. Range values overlap, i.e. start=1, end=1 denotes
     * a phrase of size 1.
     *
     * @param start Starting index of the source phrase
     * @param end End index of the source phrase
     */
    const XSourceRangePoolPtr GetXSourceRangePool (size_t start, size_t end) const {
        return wordXRanges_[start][end];
    }

    /**
     * @brief Retrieve the source sentence
     */
    const Sentence& GetSentence() const {
        return sentence_;
    }
  
    /**
     * @brief Return the rest cost based on the coverage vector of a hypothesis.
     *
     * @param c The coverage vector of a hypothesis
     *
     * @return the rest cost according to the coverage vector. 
     */
    float GetFutureScorePerCoverage(const Coverage& c) const;  
    
    /**
     * @brief Return the rest cost based on the coverage vector of a hypothesis.
     *
     * This version is used for Cube-pruning to determin the rest cost for a
     * potential expansion.
     *
     * @param c The coverage vector of a hypothesis
     * @param exStart Starting index of an expansion
     * @param exEnd End index of an expansion
     *
     * @return the rest cost according to the coverage vector. 
     */
    float GetFutureScorePerCoverage(const Coverage& c, size_t exStart, size_t exEnd) const;  
  
    const Ranges& GetRanges(const HypothesisPtr& hyp);
    
  private:
    typedef std::vector<std::vector<SourceRangePtr>> WordRanges;
    typedef std::vector<std::vector<XSourceRangePoolPtr> > WordXRanges;
  
    void CollectTranslationOptions();
    void CalculateFutureScores();
	// mtu add for generating hierarchical rules
	void GenerateXRules(size_t start, size_t length, const std::vector<lm::Word> &sourcevec, size_t source_last_pos, lm::Word xid);
	void GenerateX2Rules(size_t start, std::vector<lm::Word> &sourcevec, lm::Word xid, size_t abs_x1_start, size_t abs_x1_len,size_t abs_start,size_t abs_len);
	void FillRuleMatrixUnit(lm::NGram &source, size_t abs_start, size_t abs_len,size_t abs_x1_start=0, size_t x1_len=0, size_t abs_x2_start=0, size_t x2_len=0);
	void CollectXTranslationOptions();	
	void GenerateGlueRules();

    float GetFutureScore(size_t start, size_t length);
    
    void SetFutureScore(size_t start, size_t length, float score);   
  
    const Sentence& sentence_;
    WordRanges wordRanges_;
    WordXRanges wordXRanges_;
    RangesCache rangesCache_;
};

}
