#include "dec/sentence.h"
#include "dec/god.h"
#include "util/string_piece_split.h"

namespace herbal {

Sentence::Sentence(const std::string& line)
 : line_(line) {
  util::split(lineTokens_, line_, " ");
  source_.push_back(God::GetVocab()[lm::sBOS]);
  for(auto& t : lineTokens_)
    source_.push_back(God::GetVocab()[t]);
  source_.push_back(God::GetVocab()[lm::sEOS]);
}

const Sentence::source_type& Sentence::GetSource() const {
  return source_;
}

const std::string& Sentence::GetSourceString() const {
  return line_;
}

const Sentence::translation_type& Sentence::GetTranslation() const {
  return target_;
}

size_t Sentence::Length() const {  
  return source_.size();
}

const std::string Sentence::GetTranslationString() const {
  std::stringstream starget;
  for(auto& w : target_)
    if(w.first == lm::wUNK) {
	  if (God::Get<bool>("drop-unks"))
		continue;
        starget << lineTokens_[w.second - 1];
        if(God::Get<bool>("show-unks"))
          starget << "|UNK";
        starget << " ";
	  
    }
    else if(w.first <= 2)
      continue;
    else
      starget << God::GetVocab()[w.first] << " ";
  return starget.str();      
}

const std::vector<std::string>& Sentence:: GetTuneInfoVec() const
{
  return tuneVec_;
}
}
