#pragma once

#include "dec/god.h"
#include "lm/language_model.h"
#include "dec/ff/feature_function.h"

namespace herbal {

class FFOSMState : public FFState {
    public:
        FFOSMState(lm::LanguageModel::state_type state);

        FFOSMState();

        lm::LanguageModel::state_type& Get();

        size_t HashCombine(size_t seed) const;

    private:
        lm::LanguageModel::state_type state_;
};

typedef FFOSMState* FFOSMStatePtr;

class FFOSM : public FeatureFunction {
    public:
      FFOSM(size_t index,
            const std::vector<float>& weights,
            std::unique_ptr<lm::LanguageModel>&& lm);

      float Score(
              FFStatePtr state, TargetPhrasePtr tp, FFStatePtr next);

      FFStatePtr EmptyState();
	  size_t GetOrder()const {
	  	return 0;
	  }

    private:
      std::unique_ptr<lm::LanguageModel> lm_;
};

}
