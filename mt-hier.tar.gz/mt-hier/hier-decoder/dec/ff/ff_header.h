#pragma once

#include <vector>

#include "util/blob.h"
#include "util/scoped_file.h"
#include "dec/ff/ff_type.h"
#include "util/chunk.h"

namespace herbal {

    /**
     * @brief The header of FF.
     *
     * It's contained two pieces of information: a type and a vector
     * of weights.
     */
class FFHeader : public util::Blobbed {
    typedef util::Chunk<FFType> ChunkFFType;

    public:
        FFHeader() {}


        /**
         * @brief Return FFType included in FFHeader.
         *
         * @return FFTypr included in FFHeader.
         */
        FFType GetFFtype() const {
            return type_;
        }


        /**
         * @brief Return a vector of weights.
         *
         * @return A vector of weights.
         */
        std::vector<float> GetWeights() const {
            std::vector<float> weights;
            for (auto& weight : weights_) {
                weights.push_back(weight);
            }
            return weights;
        }

    private:

        /**
         * @brief Map the content of blob. It's read FFType and weights.
         *
         * @param blob Blob to read from.
         */
        void MapBlob(util::Blob& blob) {
            blob >> type_;
            blob >> nWeights_;
            blob >> weights_(nWeights_);
        }
        ChunkFFType type_;
        util::Chunk64 nWeights_;
        util::ManyChunks<float> weights_;
};

}

