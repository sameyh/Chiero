#pragma once

#include <map>
#include <string>
#include <vector>
#include <functional>

#include "dec/ff/feature_function.h"
#include "dec/ff/ff_type.h"

#include "util/blob.h"

namespace herbal {

typedef FeatureFunctionPtr (*FFLoader)(const size_t&, const std::vector<float>& weights, util::Blob&);

/**
 * @brief Feature Function Factory.
 */
class FFFactory {
    public:

        /**
         * @brief Constructor.
         */
        FFFactory();

        /**
         * @brief Load a FF from a given blob.
         *
         * @param index an index of FF.
         * @param blob a blob with FF.
         *
         * @return The function pointer to a function which loads a FF.
         */
        FeatureFunctionPtr Load(const size_t& index, util::Blob& blob);

    private:

        /**
         * @brief  Adding FF to the Factory.
         *
         * @param ffType FFType of  a new FF.
         * @param loader A function pointer to loader of a new FF.
         */
        void RegisterFF_(const FFType ffType, FFLoader loader);

        std::map<FFType, FFLoader> ffMap_;

};

}
