#include "dec/ff/ff_osm.h"
#include "lm/language_model.h"
#include "dec/ff/ff_type.h"

namespace herbal {

FFOSMState::FFOSMState(lm::LanguageModel::state_type state)
: state_(std::move(state)) {}

FFOSMState::FFOSMState() {}

lm::LanguageModel::state_type& FFOSMState::Get() {
    return state_;
}

size_t FFOSMState::HashCombine(size_t seed) const {
    for (auto w : *state_)
        boost::hash_combine(seed, w);
    return seed;
}

FFOSM::FFOSM(
        size_t index,
        const std::vector<float>& weights,
        std::unique_ptr<lm::LanguageModel>&& lm)
      : FeatureFunction(index, weights, FFType::OperationSequenceModel),
        lm_(std::move(lm)) {}

float FFOSM::Score(
        FFStatePtr state,
        TargetPhrasePtr tp,
        FFStatePtr next) {
    lm::LanguageModel::state_type& stateLM
        = static_cast<FFOSMStatePtr>(state)->Get();
    lm::LanguageModel::state_type& nextLM
        = static_cast<FFOSMStatePtr>(next)->Get();

    float lmScore = 0;
    lm::LanguageModel::state_type* statePtr = &stateLM;
    for(auto w : tp->GetPhrase()) {
        lm::LanguageModel::state_type nextState = lm_->NewState();
        lmScore += lm_->Query(w, *statePtr, &nextState);
        std::swap(nextLM, nextState);
        statePtr = &nextLM;
    }
    std::swap(nextLM, *statePtr);
    return lmScore;
}

FFStatePtr FFOSM::EmptyState() {
    FFOSMStatePtr state = God::Create<FFOSMState>();
    state->Get() = lm_->NewState();
    return state;
}

}
