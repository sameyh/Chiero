#pragma once

#include "pt/target_phrase.h"
#include "pt/paste.h"
#include "dec/coverage.h"
#include "dec/hypothesis_states.h"
#include "dec/source_range.h"
//#include "dec/tune_info.h"

namespace herbal {

class ChartHypothesis;
typedef std::shared_ptr<ChartHypothesis> ChartHypothesisPtr;

/**
 * @brief Cube coordinates for cube pruning
 */
struct ChartCubeCoord {
    ChartCubeCoord(const size_t tx, const size_t ty, const size_t tr){
		coords.resize(3);
		coords[0]=(tx);
	   	coords[1]=(ty);
	  	coords[2]=tr;
	}

  std::vector<size_t> coords;
  
  void Set(const size_t ti, size_t id){
  	coords[id] = ti;
  }
  size_t HashCombine(size_t seed){
	  size_t seed1 = seed;
	  for(auto x: coords)
		  boost::hash_combine(seed1,x);
	  return seed1;
  }
  size_t operator [](size_t index){
  	return coords[index];
  }
};

class FeatScores {
	public:
	FeatScores(){
		feat.resize(static_cast<size_t>(FEATURELIST::FEATCOUNT),0.0);
	}
	float GetSum(){
	  float sum = 0.0;
	  for(auto &x:feat)
		sum += x;
	  return sum;
	}
	float GetWeightedSum(){
	  float sum = 0.0;
	  size_t i=0;
	  for(auto &x:feat)
		  sum += x * God::GetTranslationModel().GetWeight(i++);
	  return sum;
	}
	const std::vector<float> GetFeatScores() const{
		return feat;
	}
	void SetFeatScores(const FeatScores &fs){
		for(size_t i=0;i<fs.GetFeatScores().size();++i)
			feat[i]=fs.At(i);
	}
	void SetFeatScore(size_t featType, const float fs){
		feat[featType]=fs;
	}
	void AddFeatScore(size_t featType, const float fs){
		feat[featType] += fs;
	}
	const float At(size_t i) const{
		return feat[i];
	}
	void operator+=(const FeatScores &rfs){
		for(size_t i=0;i<feat.size();++i)
			feat[i] += rfs.At(i) ;
	}
	template <class OStream>
    friend OStream& operator<<(OStream& o, const FeatScores& fs) {
		o<<" features: ";
		for(size_t i=0; i<static_cast<size_t>(FEATURELIST::FEATCOUNT); ++i)
			o<<fs.feat[i]<<" ";
		return o;
	}
 
	std::vector<float> feat;

};

/**
 * @brief Main class for hypothesis calculation and extension
 *
 * Every translation step is encoded as a hypothesis. Hypotheses always point
 * back to their parent hypothesis. Transaltion and decoding is scoring of
 * hypothesis extensions. 
 *
 */
class ChartHypothesis {
  public:
    typedef std::unordered_map<size_t, std::pair<float, FFStatePtr> >* LmmapPtr;
    //typedef std::unordered_map<size_t, std::pair<float, lm::LanguageModel::state_type*> >* LmmapPtr;
    /**
     * @brief Constructor for empty hypothesis
     *
     * @param length Source sentence size
     */
    ChartHypothesis(size_t length)
    : cost_(0.0),
      leftHyp_(nullptr), rightHyp_(nullptr), currentTargetXPhrase_(nullptr),
      coverage_(length), 
      chartCubeCoord_(0,0,0), hash_(0),rank_(0),
	  lmCache_(nullptr),leftBoundHash_(0),rightBoundHash_(0)
    {}

    /**
     * @brief Constructor for extending hypothesis
     *
     * @param h Previous hypothesis
     * @param tp Target phrase used to extend the hypothesis and prodce the
     * current one. 
     */
    ChartHypothesis(const ChartHypothesisPtr& lh, const ChartHypothesisPtr& rh, const TargetXPhrasePtr& tp,const  size_t rank_tp, LmmapPtr &lmcache);


    /**
     * @return left child hypothesis used to construct the current one.
     */
    const ChartHypothesisPtr& LeftHypothesis() const {
      return leftHyp_;
    }
	/**
     * @return right child hypothesis used to construct the current one.
     */
    const ChartHypothesisPtr& RightHypothesis() const {
      return rightHyp_;
    }

    /**
     * @return target phrase used to extend the current hypothesis.
     */
    const TargetXPhrasePtr& CurrTargetXPhrase() const {
      return currentTargetXPhrase_;
    }
    /**
     * @return start.
     */
    size_t  Start()  {
      return currentTargetXPhrase_->GetRange()->Start();
    }
	/*
	 * @return end.
	 * */

	size_t  Back()  {
		return currentTargetXPhrase_->GetRange()->End();
	}
	/*
	 *@return boundary of an target phrase
	 * */
	const PhrasePiece  GetBoundary(const PhrasePiece& ph, size_t direction, size_t order);
	/*
	 *
	 * */
	const float  CurrLeftBoundScore()
	{
		return leftBoundLMScore_;
	}
	/*
	 *
	 * */

	void  HypoBoundary(size_t order);
	
	/*
	 *
	 * */
	void  ComputeHypoBoundaryLM(FeatureFunctionPtr &ff);

	/*
	 *
	 * */

	bool GetTerminals(std::vector<PhrasePiece>& v);
	/*
	 *
	 * */
	float ComputeDeltaLM(const PhrasePiece&lh, const PhrasePiece&rh, FeatureFunctionPtr& ff, ChartHypothesisPtr ptr=nullptr);
	/*
	 *
	 * */
	 //float queryFF(lm::NGram &ngram, FeatureFunctionPtr& ff);
	 float queryFF(TargetPhrase& targetPhrase, FeatureFunctionPtr& ff, FFStatePtr next= nullptr);
	 float queryFFConst(TargetPhrase& targetPhrase, FeatureFunctionPtr& ff, FFStatePtr next= nullptr);

	/*
	 *
	 * */ 
	 void ForwardBoundaryUpdate(std::vector<lm::Word>& forwardBound,const PhrasePiece& rh,size_t order);
	/*
	 *
	 * */
	const std::vector<lm::Word>& GetCurrBoundary	(size_t direction)const {
		if(direction==0){
			return rightBound_;
		}
		else
			return leftBound_;
	}
	

    /**
     * @return The source word coverage vector.
     */
    const Coverage& GetCoverage() const {
      return coverage_;
    }

    /**
     * @return The current accurate cost.
     */
    float GetCost() const {
      return cost_;
    }


    /**
     * @return The total cost used for search.
     */
    float TotalCost() const {
      return GetCost(); 
    }

    
    /**
     * @param i The feature function index.
     *
     * @return The vector of current feature function states.
     */
    FFStatePtr GetState(size_t i) {
      return states_.GetState(i);
    }

    /**
     * @return The vector of current feature function states.
     */
    HypothesisStates& GetStates() {
      return states_;
    }

    /**
     * @brief Return the precalculated hash value for this hypothesis.
     */
    size_t Hash() {
      return hash_;
    }

    /**
     * @brief Get the cube pruning coordinates.
     */
    ChartCubeCoord& GetCubeCoords() {
      return chartCubeCoord_;
    }

	FeatScores& GetFeatScores() {
		return ftScores_;
	}
    /**
     * @brief Set the cube pruning coordinates.
     */
    void SetChartCubeCoords(size_t x, size_t y, size_t t) {
      chartCubeCoord_ = {x, y, t};
    }
	/**
     * @brief Set rank of current hypothesis.
     */
    void SetRank(size_t k) {
      rank_ = k;
    }
	/**
     * @brief get rank of current hypothesis.
     */
    const size_t GetRank() const{
      return rank_;
    }

	/**
     * @brief Compute the added language model score.
     */
	float ComputeAddLM (FeatureFunctionPtr &ff);
	
	/**
     * @brief Add feature score with new score.
     */
	void AddUnitScore(size_t featType, float score);
	size_t GetWordNum(){
		return word_num_;
	}
   	const size_t GetLeftBoundHash() const{
		return leftBoundHash_;
	}
   	const size_t GetRightBoundHash() const{
		return rightBoundHash_;
	}

	/**
     * @brief Prints a hypothesis to a stream, for debugging.
     */
	void PrintBackTrack() const;
	
	/**
     * @brief Prints a hypothesis to a stream, for debugging.
     */
	void PrintVocabBackTrack(std::vector<lm::Word> &v) const;


    /**
     * @brief Prints a hypothesis to a stream, for debugging.
     */
    template <class OStream>
    friend OStream& operator<<(OStream& o, const ChartHypothesis& hyp) {
      o << hyp.hash_ << " (" << hyp.chartCubeCoord_.coords[0] << "," << hyp.chartCubeCoord_.coords[1] << ","<<hyp.chartCubeCoord_.coords[2] <<") : ";

      if(hyp.currentTargetXPhrase_ != 0){
       	hyp.PrintBackTrack();
		o << "||| "; 
		  o << *hyp.currentTargetXPhrase_ << "||| ";
	  }
      else
        o << "NULL ||| ";
	  
	  o << hyp.ftScores_;
      o << hyp.GetCost() << " " << hyp.TotalCost() << " ||| "
        << hyp.coverage_;
      return o;
    }


  private:
    float cost_;

    const ChartHypothesisPtr leftHyp_;
	const ChartHypothesisPtr rightHyp_;
    const TargetXPhrasePtr currentTargetXPhrase_;

    Coverage coverage_;
    HypothesisStates states_;

    ChartCubeCoord chartCubeCoord_;

	FeatScores ftScores_;
    size_t hash_;
	size_t word_num_;
	size_t rank_;
	std::vector<lm::Word> leftBound_;
	std::vector<lm::Word> rightBound_;
	float leftBoundLMScore_;
	float rightBoundLMScore_;
	FFStatePtr rightState_;
	LmmapPtr lmCache_;

	size_t leftBoundHash_;
	size_t rightBoundHash_;

};

}
