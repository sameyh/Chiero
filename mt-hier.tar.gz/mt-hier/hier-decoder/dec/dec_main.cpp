#include <iostream>
#include <fstream>
#include <string>
#include <queue>
#include <thread>
#include <mutex>
#include <boost/program_options.hpp>
#include "time.h"

#include "dec/god.h"
#include "dec/translation_task.h"
#if defined(PROFILING)
#include <gperftools/profiler.h>
#endif

#if !defined HIER_MERT && !defined PHRASE_RELEASE

  #define HIER_RELEASE

#endif

using namespace herbal;

struct TargetTune{
  std::string target_;
  std::vector<std::string> tune_;
  TargetTune(std::string &s):target_(s){}
  TargetTune(){}
};
typedef std::pair<size_t, TargetTune> Item;
struct ItemSorter {
  bool operator()(const Item& a, const Item& b) { return a.first > b.first; }
};
typedef std::priority_queue<Item, std::vector<Item>, ItemSorter> Queue;

Item GetItem(bool& hadData, Queue& inQueue, std::mutex& inMutex) {
  std::lock_guard<std::mutex> lock(inMutex);
  Item item;
  if(!inQueue.empty()) {
    item = inQueue.top();
    inQueue.pop();
    hadData = true;
  }
  return item;
}
void PutItem(Item item, Queue& outQueue, std::mutex& outMutex, std::ostream& o,  size_t& last) {
  std::lock_guard<std::mutex> lock(outMutex);
  outQueue.push(item);

  while(outQueue.top().first == last + 1) {
    std::cout << outQueue.top().second.target_ << std::endl;
#ifdef HIER_MERT
    for(auto &e:outQueue.top().second.tune_)
		o << last <<" ||| "<<e;
#endif
    last++;
    outQueue.pop();
  }
}
void translate(Queue& inQueue, std::mutex& inMutex,
               Queue& outQueue, std::mutex& outMutex,
			   std::ostream &o,
               size_t& last) {
  bool hadData;
  do {
    hadData = false;
    Item inItem = GetItem(hadData, inQueue, inMutex);
    if(hadData) {
      TranslationTask translationTask(inItem.first, inItem.second.target_);
      translationTask.Translate();

      Item outItem = inItem;
      outItem.second.target_ = translationTask.GetTranslation();
	  outItem.second.tune_ = translationTask.GetTuneInfo();
	  
      PutItem(outItem, outQueue, outMutex, o, last);
    }
  } while(hadData);
}

int main(int argc, char** argv) {
#if defined(PROFILING)
    ProfilerStart("dec.profiling.out");
#endif
    God::Init(argc, argv);

    Queue inQueue;
    std::mutex inMutex;
    Queue outQueue;
    std::mutex outMutex;

	
	std::string input = God::Get<std::string>("input-file");
	if (input.length()>0)
	  freopen(input.c_str(),"r",stdin);
    std::string line;
    size_t no = 1;
    while(std::getline(std::cin, line)) {
      inQueue.emplace(no, TargetTune(line));
      no++;
    }

    bool nbest=false;
	std::ofstream ofnbest;	
#ifdef HIER_MERT
	std::vector<std::string> nbestlist = God::Get<std::vector<std::string> >("n-best-list");

    std::cerr<<"size nbest:"<<nbestlist.size()<<std::endl;	 
	std::cerr<<nbestlist<<std::endl;
    if (nbestlist.size() == 2){
	  ofnbest.open(nbestlist[0].c_str());
	  if (!ofnbest){
	    std::cerr<<"cannot open nbest file"<<std::endl;
	  }
	  nbest = true;
	}	
#endif
	std::clock_t t=clock();
    size_t last = 0;
    size_t threadNum = God::Get<size_t>("threads");
    std::vector<std::thread> threads;
    for(size_t i = 0; i < threadNum; ++i) {
	  if (nbest)
        threads.emplace_back(translate,
                           std::ref(inQueue), std::ref(inMutex),
                           std::ref(outQueue), std::ref(outMutex),
						   std::ref(ofnbest),
                           std::ref(last));
	  else
        threads.emplace_back(translate,
                           std::ref(inQueue), std::ref(inMutex),
                           std::ref(outQueue), std::ref(outMutex),
						   std::ref(std::cout),
                           std::ref(last));

    }
    for(auto& t: threads)
      t.join();
	t=clock()-t;
	std::cerr<<"Time cost: "<<t/CLOCKS_PER_SEC <<"/"<<t*1000/no/CLOCKS_PER_SEC<<" ms"<<std::endl;

#if defined(PROFILING)
    ProfilerStop();
#endif
    return 0;
}
