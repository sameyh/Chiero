#include "dec/search_cyk_decoding.h"
#include "dec/stack_cube_pruning.h"
//#define DEBUG_MAXLEN
//#define DEBUG_NBEST

#ifndef HIER_MERT
#define HIER_RELEASE
#endif
namespace herbal {

void SearchCYKDecoding::Decode(Sentence& sentence,
                               const TranslationOptions& translationOptions) {
	size_t maxlen = sentence.Length();
	chartCube_.Resize(maxlen+1);
	chartCube_.SetLmCache(lmCache_);

	for(size_t len=1; len<maxlen; ++len){
	  for (size_t start=0; start+len < maxlen; ++start){
#ifdef DEBUG_MAXLEN
		std::cerr<<"kbest start:"<<start<<" last:"<<start+len-1<<std::endl;
#endif		  
	    chartCube_.GenerateKBest(start, start+len-1, translationOptions); 	
		
	  }
	}
//#define DEBUG_BEAM
#ifdef DEBUG_BEAM
	for(size_t i=0; i<maxlen; ++i)
		std::cerr<<i<<"  ";
	std::cerr<<std::endl;
	for(size_t len=1; len<maxlen; ++len){
	  for(size_t start = 0; start+len < maxlen; ++start){
	    for(size_t i=0;i<len-1;++i)
			std::cerr<<" ";
		std::cerr<<chartCube_.GetPool(start,start+len-1)->Size()<<"  ";
	  }
	  std::cerr<<std::endl;
	}
#endif
}
void SearchCYKDecoding::BackTrack(Sentence& sentence)
{
    const ChartHypothesisPtr p = chartCube_.Best(sentence.Length());
	if (p){
	  BackTrackDec(sentence, p);
	}
#ifdef HIER_MERT
	std::vector<std::string> nbestVec = God::Get<std::vector<std::string> >("n-best-list");
	if (nbestVec.size()==2){
	  std::stringstream ss(nbestVec[1]);
	  size_t nbest;
	  ss>>nbest;
	  for(size_t i=0; i<nbest; ++i){
	    const ChartHypothesisPtr ptr = chartCube_.NBest(sentence.Length(),i);
		if (ptr){
		  BackTrackTune(sentence, ptr);		  
		}
		else
		  break;
	  }  
	}
#endif
}
void SearchCYKDecoding::BackTrackDec(Sentence& sentence, const ChartHypothesisPtr &hypo)
{
    for(auto &w: hypo->CurrTargetXPhrase()->GetPhrase()){
		if (w == lm::wX1M){
		  BackTrackDec(sentence, hypo->LeftHypothesis());
		}
		else if (w == lm::wX2M){
		  BackTrackDec(sentence, hypo->RightHypothesis());
		}
		else
	      sentence.target_.emplace_back(w, hypo->CurrTargetXPhrase()->GetRange()->Start());
	  }

}
const std::string SearchCYKDecoding::BackTrackTunePhrase(Sentence &sentence, const ChartHypothesisPtr &hypo)const
{
   std::stringstream starget;
   
   for(auto &w: hypo->CurrTargetXPhrase()->GetPhrase()){
     if (w == lm::wX1M){
	   starget << BackTrackTunePhrase(sentence, hypo->LeftHypothesis());
	 }
	 else if (w == lm::wX2M){
	   starget << BackTrackTunePhrase(sentence, hypo->RightHypothesis());
	 }
	 else if (w == lm::wUNK){
	   if (God::Get<bool>("drop-unks"))
		   continue;
	   starget << sentence.lineTokens_[hypo->CurrTargetXPhrase()->GetRange()->Start() - 1];
	   if(God::Get<bool>("show-unks"))
		   starget << "|UNK";
	   starget << " ";
	 }
	 else if(w <= 2)
	   continue;
	 else 
	   starget << God::GetVocab()[w] << " ";
    }
  return starget.str(); 
}
void SearchCYKDecoding::BackTrackTune(Sentence& sentence, const ChartHypothesisPtr &hypo)
{
	std::stringstream ss;
   
	std::string target=  BackTrackTunePhrase(sentence, hypo); 

	ss<<target;
#ifdef DEBUG_NBEST
   std::cerr<<ss.str()<<"||| "<<target<<std::endl;
#endif

  ss<<"||| ";
  FeatScores ft = hypo->GetFeatScores() ;
  ss<< "LM0= "<< ft.At(static_cast<size_t>(FEATURELIST::LM))
	  << " WordPenalty0= "<< ft.At(static_cast<size_t>(FEATURELIST::WP))
	  << " PhrasePenalty0= "<< ft.At(static_cast<size_t>(FEATURELIST::PP))
	  << " GluePenalty0= "<< ft.At(static_cast<size_t>(FEATURELIST::GP))
	  << " TranslationModel0= "<< ft.At(0)<<" "<<ft.At(1)<<" "<<ft.At(2)<<" "<<ft.At(3)<<" ";
  ss<< "||| "<< hypo->TotalCost()
	  << " "<< ft.GetWeightedSum()
	  <<std::endl;
  sentence.tuneVec_.push_back(ss.str());
}
}

