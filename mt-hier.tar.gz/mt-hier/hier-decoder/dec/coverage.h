#pragma once

#include <iostream>

#include "dec/god.h"
#include "util/bit_array.h"

namespace herbal {

/**
 * @brief Keeps track of source word positions covered by a hypothesis so far.
 */
class Coverage {
  public:
    
    /**
     * @brief Constructor
     *
     * @param length number of words in the source sentence, here the number of
     * bits in the bitset. 
     */
    Coverage(size_t length)
    : hash_(0), coverage_(0)
    {
      size_t wordLength = roundup_bits2words64(length);
      void* memory = God::Memory(sizeof(BIT_ARRAY) + sizeof(word_t) * wordLength);
      coverage_ = bit_array_create(length, memory);
    }

    /**
     * @brief Copy constructor
     */
    Coverage(const Coverage& o)
    : hash_(0), coverage_(0)
    {
      size_t bits = o.GetSize();
      size_t length = roundup_bits2words64(bits);
      void* memory = God::Memory(sizeof(BIT_ARRAY) + sizeof(word_t) * length);
      coverage_ = bit_array_clone(o.coverage_, memory);
      Rehash();
    }
    
    /**
     * @brief Mark words in range as covered.
     *
     * @param start Beginning of word range
     * @param end End of word range (inclusive).
     */
    void SetCovered(size_t start, size_t end) {
      bit_array_set_region(coverage_, start, end - start + 1);
      Rehash();
    }

    /**
     * @return Return number of covered source words
     */
    size_t NumCovered() const {
      return bit_array_num_bits_set(coverage_);
    }

    /**
     * @brief Check if any word in word range is covered
     *
     * @param start Beginning of word range
     * @param end End of word range (inclusive)
     *
     * @return true if any word is covered, else false
     */
    bool IsCovered(size_t start, size_t end) const {
      for(size_t i = start; i <= end; i++)
        if(IsCovered(i))
          return true;
      return false;
    }
    
    /**
     * @brief Check if specified word is covered
     *
     * @param i Index of word
     *
     * @return true if word is covered, else false
     */
    bool IsCovered(size_t i) const {
      return bit_array_get_bit(coverage_, i) == 1;
    }

    /**
     * @brief Return first non-covered position
     *
     * @return Position of first non-covered word from the left.
     */
    size_t FirstGap() const {
      size_t gap = 0;
      bit_array_find_first_clear_bit(coverage_, &gap);
      return gap;
    }

    /**
     * @brief Function that produces a combined hash for the given range
     */
    size_t HashCombine(size_t seed) const {
      for(word_t* i = coverage_->words;
          i < coverage_->words + coverage_->num_of_words; i++)
        boost::hash_combine(seed, *i);
      return seed;
    }
    
    /**
     * @return A precomputed hash value
     */
    size_t Hash() const {
      return hash_;
    }
        
    // @TODO: clean this up
    void Rehash(size_t seed = 0) {
      hash_ = HashCombine(seed);
    }
    
    /**
     * @return The number of source words
     */
    size_t GetSize() const {
      return bit_array_length(coverage_);
    }
     
    /**
     * @brief Prints a bit-wise coverage information, used for debugging.
     */
    template <class OStream>
    friend OStream& operator<<(OStream& o, const Coverage& c) {
      for(size_t i = 0; i < c.GetSize(); ++i)
        o << c.IsCovered(i);
      return o;
    }

  private:
    size_t hash_;
    BIT_ARRAY* coverage_;
};

}
