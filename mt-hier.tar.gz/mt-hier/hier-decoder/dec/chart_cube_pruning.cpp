
#include "chart_cube_pruning.h"

//#define DEBUG
//#define DEBUG_MAXLEN
namespace herbal{

bool CandSorter(const ChartHypothesisPtr&a , const ChartHypothesisPtr& b)
{
	return a->TotalCost() > b->TotalCost();
}
bool CandLess(const ChartHypothesisPtr&a , const ChartHypothesisPtr& b)
{
	return a->TotalCost() < b->TotalCost();
}

const ChartHypothesisPtr ChartCubePruning::Best(size_t sent_length) const
{
  if (mat_cands[0][sent_length-2]->Size() >0 ){
    return mat_cands[0][sent_length-2]->GetHypo(0);
  }
  return nullptr;
}
const ChartHypothesisPtr ChartCubePruning::NBest(size_t sent_length, size_t index) const
{
    if (mat_cands[0][sent_length-2]->Size() > index ){
	   return mat_cands[0][sent_length-2]->GetHypo(index); 
    }
	return nullptr;
}	
	

void ChartCubePruning::FillCandMatrixBase(size_t start, size_t last, const TranslationOptions& translationOptions, Queue<ChartHypothesisPtr>& queue)
{
	XSourceRangePoolPtr rulePoolPtr = translationOptions.GetXSourceRangePool(start, last);
	if (!rulePoolPtr)return;
#ifdef DEBUG_MAXLEN
	if (rulePoolPtr->size() == 0){
	  std::cerr<<"start-last: "<<start<<"-"<<last<<" no rule"<<std::endl;
	}
#endif
	if (rulePoolPtr->size() > 0){
	  size_t index=0;
	  for(auto &rule: *rulePoolPtr){
		if (rule->XSize()==0){
		  //phrase 
		  for(auto &targetx: rule->GetTargetXPhrases()){
		    ChartHypothesisPtr hypo( new ChartHypothesis(NULL, NULL, targetx, index++, lmCachePtr) );
			queue.push(hypo);
		  }  
		}	  
		else if(rule->XSize()==1){
		  //xterm
		  size_t x1_start = rule->X1Start();
		  size_t x1_last = rule->X1Back();

		  for(auto &targetx: rule->GetTargetXPhrases()){
		    if (mat_cands[x1_start][x1_last]->Size() > 0){
		      ChartHypothesisPtr hypo( new ChartHypothesis(mat_cands[x1_start][x1_last]->GetHypo(0),NULL,targetx,index++, lmCachePtr) );
			  queue.push(hypo);
			}
		  }	
		}
		else{
		  //x1 x2
		  size_t x1_start = rule->X1Start();
		  size_t x1_last = rule->X1Back();
	   	  size_t x2_start = rule->X2Start();
		  size_t x2_last = rule->X2Back();

		  for(auto &targetx: rule->GetTargetXPhrases()){
		    if (mat_cands[x1_start][x1_last]->Size() > 0 
					&& mat_cands[x2_start][x2_last]->Size() > 0){
			  ChartHypothesisPtr hypo( new ChartHypothesis(mat_cands[x1_start][x1_last]->GetHypo(0), mat_cands[x2_start][x2_last]->GetHypo(0),targetx,index++, lmCachePtr));
			  queue.push(hypo);
			}
		  }	
		}
	  }	
	}

}
void ChartCubePruning::GenerateKBest(size_t start, size_t last, const TranslationOptions& translationOptions)
{
	Queue<ChartHypothesisPtr> queue;
#ifdef DEBUG
	std::cerr<<"generate k best for "<<start<<"-"<<last<<std::endl;
	clock_t t=clock();
#endif
	FillCandMatrixBase(start, last, translationOptions, queue);
#ifdef DEBUG
	t = clock()-t;
	std::cerr<<"fill out cand matrix costing "<<(float)t*1000/CLOCKS_PER_SEC<<" ms"<<std::endl;
#endif	
	
	size_t sno=0;


	while (sno< God::Get<size_t>("pop-limit") && 
			mat_cands[start][last]->Size() <God::Get<size_t>("beam-size") && !queue.empty()){
		ChartHypothesisPtr tp= queue.top();
		queue.pop();

		QueueNeighbours(tp, queue);
		
		sno++;
		mat_cands[start][last]->AddCand(tp);
	}

#ifdef DEBUG
	std::cerr<<"after queueneighbours:"<<mat_cands[start][last]->Size()<<std::endl;
#endif
	mat_cands[start][last]->SortCand();
}



void ChartCubePruning::QueueNeighbours(ChartHypothesisPtr &hyp, Queue<ChartHypothesisPtr>& queue)
{
	ChartCubeCoord coords = hyp->GetCubeCoords();
	ChartHypothesisPtr left = hyp->LeftHypothesis();
	ChartHypothesisPtr right = hyp->RightHypothesis();
	TargetXPhrasePtr rule = hyp->CurrTargetXPhrase();
	if (left){
		size_t start = left->Start();
		size_t last = left->Back();
		if (coords[0] + 1< mat_cands[start][last]->Size()){
  		  ChartHypothesisPtr hypo( new ChartHypothesis(mat_cands[start][last]->GetHypo(coords[0]+1),right,rule,coords[2], lmCachePtr));
		  queue.push(hypo);
		}
	}
	if (right){
		size_t start = right->Start();
		size_t last = right->Back();
		if (coords[1]+1 < mat_cands[start][last]->Size()){
		  ChartHypothesisPtr hypo (new ChartHypothesis(left,mat_cands[start][last]->GetHypo(coords[1]+1),rule,coords[2], lmCachePtr));
		  queue.push(hypo);
		}
	}
}

void ChartCubePruning::Resize(size_t len)
{
	std::vector<ChartHypothesisPoolPtr> sub_mat_cands(len);
	mat_cands.resize(len,sub_mat_cands);
	for(size_t i(0);i<mat_cands.size();++i){
	  for(size_t j(0);j<mat_cands[i].size();++j){
		  mat_cands[i][j].reset(new ChartHypothesisPool());
	  }
	}
}
bool ChartHypothesisPool::IsBoundSame(const ChartHypothesisPtr &lh, const ChartHypothesisPtr &rh)
{
  if (lh->GetLeftBoundHash() != rh->GetLeftBoundHash()
		  || lh->GetRightBoundHash() != rh->GetRightBoundHash())
	  return false;
  return true;
}
void ChartHypothesisPool::AddCand(ChartHypothesisPtr &hypo)
{
#ifdef DEBUG
	//std::cerr<< *hypo <<std::endl;
#endif
	for(auto& ehypo:cand_pool_){
	  if (IsBoundSame(ehypo, hypo)){
	    if (ehypo->TotalCost() < hypo->TotalCost() ){
			ehypo = hypo;
		}
		return;
	  }
	}
	if (cand_pool_.size() > God::Get<size_t>("beam-size")){
	  ChartHypothesisPtr &min = *min_element(cand_pool_.begin(),cand_pool_.end(),CandLess);
	  if (min->TotalCost() < hypo->TotalCost()){
	  	min = hypo;
	  }
	  return;
	}
	cand_pool_.push_back(hypo);
}


void ChartHypothesisPool::SortCand()
{
	sort(cand_pool_.begin(),cand_pool_.end(),CandSorter);	
	size_t i=0;
	for(auto &hypo:cand_pool_)
		hypo->SetRank(i++);
}
};
