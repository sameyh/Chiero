
#include "chart_hypothesis.h"
//#define DEBUG
//#define DEBUG_LM
//#define DEBUG_TERM
//#define DEBUG_FORWARD
//#define DEBUG_TLM
//#define DEBUG_HASH
//#define DEBUG_BS

//#define HIER_RELEASE

#if !defined  HIER_MERT
  #define HIER_RELEASE
#endif


namespace herbal {

ChartHypothesis::ChartHypothesis(const ChartHypothesisPtr& lh, const ChartHypothesisPtr& rh, const TargetXPhrasePtr& tp, const size_t rank_tp, LmmapPtr &lmcache)
    :cost_(0),leftHyp_(lh), rightHyp_(rh), currentTargetXPhrase_(tp),
	 coverage_(tp->GetRange()->End()+1),
      chartCubeCoord_(0,0,rank_tp), hash_(0),word_num_(0),rank_(0),
	  lmCache_ ( lmcache )
{

  	word_num_ = currentTargetXPhrase_->GetPhrase().size();
	  if(lh){
		  cost_ = lh->GetCost();
		  chartCubeCoord_.Set(lh->GetRank(),0);

#ifndef HIER_RELEASE
		  ftScores_ = lh->GetFeatScores();
#endif


		  word_num_ += lh->GetWordNum()-1;
	  }
	  if(rh){
		  cost_ += rh->GetCost();
		  chartCubeCoord_.Set(rh->GetRank(),1);


#ifndef HIER_RELEASE
		  ftScores_ += rh->GetFeatScores();
#endif


		  word_num_ += rh->GetWordNum()-1;
	  }

#if defined HIER_RELEASE
	  cost_ += tp->GetScores()[0];
#else
	  for(size_t i=0;i<static_cast<size_t>(FEATURELIST::FEATCOUNT);++i){
	    if (i == static_cast<size_t>(FEATURELIST::WP) && tp->GetPhrase()[0] == lm::wUNK)
	 	  cost_ += -20;
	    
        cost_ += tp->GetScores()[i]*(God::GetTranslationModel().GetWeight(i));
		ftScores_.AddFeatScore(i,tp->GetScores()[i]);
	   
	  }
#endif

      size_t start = tp->GetRange()->Start();
      size_t end   = tp->GetRange()->End();
      coverage_.SetCovered(start, end);

	  for (auto &ff: God::GetFFs()){
		if (ff->GetFFType() == FFType::LanguageModel){
			HypoBoundary(ff->GetOrder());
	  	    float del_lm = ComputeAddLM(ff);	  	
			ComputeHypoBoundaryLM(ff);
#if defined HIER_RELEASE
			cost_ += del_lm;
#else
		    AddUnitScore(static_cast<size_t>(FEATURELIST::LM), del_lm);
	 	    cost_ += del_lm * God::GetTranslationModel().GetWeight(static_cast<size_t>(FEATURELIST::LM)); 
#endif


#ifdef DEBUG_TLM
		    std::vector<lm::Word> v;
		    PrintVocabBackTrack(v);
			ScorePiece sp(nullptr,0);
			AlignmentPiece ap(nullptr,0);
			TargetXPhrase ph(PhrasePiece(v.data(),v.size()),sp,ap);
			PrintBackTrack();
			float lms = queryFF(ph,ff);
			std::cerr<<"||| del_lm:"<<del_lm<<" ph_lm:"<< lms <<" ft_lm:"<<ftScores_.At(static_cast<size_t>(FEATURELIST::LM))
				<<" ft_all:"<<ftScores_.GetSum()<<" total:"<<TotalCost()<<std::endl;
			float del = lms-ftScores_.At(static_cast<size_t>(FEATURELIST::LM));
			assert(del > -0.0001 && del < 0.0001);
			float del1 = ftScores_.GetSum() - TotalCost();
			assert(del1 > -0.0001 && del1 < 0.0001);

 #endif
  
		}
	  }

      // Hash coverage and states for recombination
      hash_ = 0;
      hash_ = coverage_.HashCombine(hash_);
	  hash_ = chartCubeCoord_.HashCombine(hash_);
	  leftBoundHash_=0;
	  rightBoundHash_ = 0;
	  for(auto &w:leftBound_)
	    boost::hash_combine(leftBoundHash_,w);
	  for(auto &w:rightBound_)
		boost::hash_combine(rightBoundHash_,w);
}
void ChartHypothesis::PrintVocabBackTrack(std::vector<lm::Word> & v) const
{
  for (auto &w:currentTargetXPhrase_->GetPhrase()){
    if (w == lm::wX1M){
	  leftHyp_->PrintVocabBackTrack(v); 
	}
	else if(w == lm::wX2M){
	  rightHyp_->PrintVocabBackTrack(v);
	}
	else{
	  std::cerr<<God::GetVocab()[w]<<" ";
	  v.push_back(w);
	}
  } 
}

void ChartHypothesis::PrintBackTrack() const
{
  for (auto &w:currentTargetXPhrase_->GetPhrase()){
    if (w == lm::wX1M){
	  leftHyp_->PrintBackTrack(); 
	}
	else if(w == lm::wX2M){
	  rightHyp_->PrintBackTrack();
	}
	else{
	  std::cerr<<w<<" ";
	}
  } 
}
bool ChartHypothesis::GetTerminals(std::vector<PhrasePiece>&v)
{
  size_t pos(0),pos_x1(currentTargetXPhrase_->GetPhrase().size()),pos_x2(pos_x1);
  for(auto &t: currentTargetXPhrase_->GetPhrase()){
    if (t == lm::wX1M )
		pos_x1 = pos;
	else if(t==lm::wX2M)
		pos_x2 = pos;
	++pos;
  }
  bool Invert = false;
  size_t first,second;
  if (pos_x1 < pos_x2){
	  first = pos_x1;
	  second = pos_x2;
  }
  else{
  	first = pos_x2;
    second = pos_x1;	
	if (pos_x1 > pos_x2)
		Invert = true;
  }

  if (first < currentTargetXPhrase_->GetPhrase().size())
	  v[0] = PhrasePiece(currentTargetXPhrase_->GetPhrase().data(),first);
  else return Invert;
  assert (first < second);
  v[1] = PhrasePiece(currentTargetXPhrase_->GetPhrase().data()+first+1,second - first -1);
  if(second < currentTargetXPhrase_->GetPhrase().size()){
	  v[2] = PhrasePiece(currentTargetXPhrase_->GetPhrase().data()+second+1, currentTargetXPhrase_->GetPhrase().size()-second-1);
  }
  return Invert;
}
void ChartHypothesis::ForwardBoundaryUpdate(std::vector<lm::Word>& forwardBound, const PhrasePiece& rh, size_t max_order)
{
#ifdef DEBUG_FORWARD
  std::cerr<<"before=> forward:";
  for(auto &e:forwardBound)
	  std::cerr<<e<<" ";
  std::cerr<<"||| ";
  for(auto &e:rh)
	  std::cerr<<e<<" ";
  std::cerr<<"||| ";
#endif
  size_t order = max_order-1;
  if (rh.size() >= order){
  	size_t start = rh.size()-order;
	forwardBound.resize(order);
	for(auto &w:forwardBound )
		w = *(rh.data()+start++);
  }
  else if(rh.size() < order){
	if (forwardBound.size()+rh.size() <= order){
	  size_t start = forwardBound.size();
	  forwardBound.resize(start+rh.size());
	  for(size_t i=0;i<rh.size();++i)
		  forwardBound[start + i]=rh[i];
	}
	else{
	  size_t start = forwardBound.size()+rh.size()-order;
	  size_t i=start;
	  size_t leftsize = forwardBound.size();
	  for(;i<leftsize;++i){
	    forwardBound[i-start] = forwardBound[i];
	  }
	  forwardBound.resize(order);
	  for(size_t j=0; j<rh.size();++j){
		forwardBound[i-start]=*(rh.data()+j);
		++i;
	  } 
	}
  }
#ifdef DEBUG_FORWARD
  std::cerr<<"after=> forward:";
  for(auto &e:forwardBound)
	  std::cerr<<e<<" ";
  std::cerr<<std::endl;
#endif
}
const PhrasePiece ChartHypothesis::GetBoundary(const PhrasePiece& ph, size_t direction, size_t order)
{
  if (ph.size() <= order)
 	return ph; 
  if (direction == 0){//right boundary
	size_t start = ph.size() - order;
	return PhrasePiece(ph.data()+start,order);
  }
  else{
  	return PhrasePiece(ph.data(),order);
  }
}
void ChartHypothesis::HypoBoundary(size_t max_order)
{
  
  //left
  size_t pos(0),pos_x1(currentTargetXPhrase_->GetPhrase().size()),pos_x2(pos_x1);
  for(auto &t:currentTargetXPhrase_->GetPhrase()){
  	if (t==lm::wX1M)
		pos_x1 = pos;
	else if (t == lm::wX2M)
		pos_x2 = pos;
	++pos;
  }
  size_t order = max_order - 1;
  leftBound_.resize(order);
  auto *p = currentTargetXPhrase_->GetPhrase().begin();
  size_t realcount=0,xcount=0,state=0;
  while(realcount<order){
    if (state!=1 && xcount==pos_x1 && leftHyp_){
		p = leftHyp_->GetCurrBoundary(1).data();
		state = 1;
	}
	else if(state!=2 && xcount == pos_x2 && rightHyp_){
		p = rightHyp_->GetCurrBoundary(1).data();
		state = 2;
	}
	if (state == 1 && p==leftHyp_->GetCurrBoundary(1).data()+leftHyp_->GetCurrBoundary(1).size()){
		p = currentTargetXPhrase_->GetPhrase().data()+pos_x1+1;
		++xcount;
		state = 0;
	}
	else if (state == 2 && p==rightHyp_->GetCurrBoundary(1).data()+rightHyp_->GetCurrBoundary(1).size()){
		p = currentTargetXPhrase_->GetPhrase().data()+pos_x2+1;
		++xcount;
		state = 0;
	}
    if (state == 0 && p==currentTargetXPhrase_->GetPhrase().end())
	  break;
#ifdef DEBUG_LM
	std::cerr<<"before=> x1_pos="<<pos_x1<<" x2_pos="<<pos_x2
		<<" realcount="<<realcount<<" xcount="<<xcount
		<<" state="<<state<<" p="<<p<<" *p="<<*p<<std::endl;
#endif

	if ( ( state==0&&xcount==pos_x1  )|| (state==0 && xcount==pos_x2 ))
	  continue;

	if (state == 0 )++xcount;
	leftBound_[realcount++] = *p++;
  } 
  leftBound_.resize(realcount);

#ifdef DEBUG_LM 
  //log
  std::cerr<<*this<<std::endl;
  std::cerr<<"left boundary: ";
  for(auto &w : leftBound_)
	  std::cerr<<w<<"("<<God::GetVocab()[w]<<") ";
  std::cerr<<std::endl;
#endif

  //right
  //do it in computedeltalm 

}
void ChartHypothesis::ComputeHypoBoundaryLM(FeatureFunctionPtr &ff)
{
  ScorePiece sp(nullptr, 0);
  AlignmentPiece ap(nullptr,0);
  TargetPhrase ltp(PhrasePiece(leftBound_.data(),leftBound_.size()), sp, ap);
  TargetPhrase rtp(PhrasePiece(rightBound_.data(),rightBound_.size()),sp, ap);
  leftBoundLMScore_ = queryFF(ltp,ff);
}
/*float ChartHypothesis::queryFF(TargetPhrase& targetPhrase, FeatureFunctionPtr& ff, FFStatePtr next)
{
	FFStatePtr state = ff->EmptyState();
	FFStatePtr nextState = ff->EmptyState();
	return ff->Score(state, &targetPhrase, nextState);
}*/
float ChartHypothesis::queryFF(TargetPhrase& targetPhrase, FeatureFunctionPtr& ff, FFStatePtr state)
{
	FFStatePtr next = ff->EmptyState();
	if (state == nullptr)
	state = ff->EmptyState();
	float score =  ff->Score(state, &targetPhrase, next);
	lm::LanguageModel::state_type& nextLM =   static_cast<FFLanguageModelStatePtr>(next)->Get();
	lm::LanguageModel::state_type& stateLM =   static_cast<FFLanguageModelStatePtr>(state)->Get();
	swap(nextLM,stateLM);
	return score;
}

float ChartHypothesis::queryFFConst(TargetPhrase& targetPhrase, FeatureFunctionPtr& ff, FFStatePtr state)
{
	FFStatePtr next = ff->EmptyState();
	if (state == nullptr)
	state = ff->EmptyState();
	float score =  ff->Score(state, &targetPhrase, next);
	return score;
}

float ChartHypothesis::ComputeDeltaLM(const PhrasePiece&lh, const PhrasePiece&rh, FeatureFunctionPtr& ff , ChartHypothesisPtr ptr)
{
  if (lh.size() == 0 || rh.size() == 0)return 0;
  ScorePiece sp(nullptr,0);
  AlignmentPiece ap(nullptr,0);

  TargetPhrase l(lh,sp,ap);
  TargetPhrase r(rh,sp,ap);
//#define DEBUG_LMCACHE
  size_t lhash = l.HashCombine();
  auto val = lmCache_->find(lhash);	

  FFStatePtr state=ff->EmptyState();
  float ls,lrs; 
  if (val == lmCache_->end()){
	ls = queryFF(l,ff,state);
	lmCache_->emplace(lhash,std::make_pair(ls,state));
    lrs = queryFFConst(r,ff,state);
  }
  else{
    lrs = queryFFConst(r,ff,val->second.second);
  }

  if (ptr){
	return lrs - ptr->CurrLeftBoundScore();
  }
  return lrs-queryFFConst(r,ff);
}
float ChartHypothesis:: ComputeAddLM (FeatureFunctionPtr &ff)
{
  size_t order= ff->GetOrder();
  //AX1BX2C, AX1X2B, X1AX2B, AX1BX2, X1X2C,AX1X2, X1BX2,X1X2  
  std::vector<PhrasePiece> terminals(3,PhrasePiece(nullptr,0));
  bool Invert = GetTerminals(terminals);

  float score=0;
  std::vector<lm::Word> forwardBound;
  ChartHypothesisPtr first(nullptr),second(nullptr);
  
  if (leftHyp_==NULL){
	  ForwardBoundaryUpdate(forwardBound, currentTargetXPhrase_->GetPhrase(),order);
	  rightBound_ = forwardBound;
	  return score;
  }
  if (rightHyp_ == NULL)first=leftHyp_;
  else if(Invert == false){
  	first = leftHyp_;
	second = rightHyp_;
  }
  else{
  	first = rightHyp_;
	second = leftHyp_;
  }

  if (first){
 	//before x
	if (terminals[0].size() > 0){
		ForwardBoundaryUpdate(forwardBound,terminals[0],order);
		score= ComputeDeltaLM(PhrasePiece(forwardBound.data(),forwardBound.size()),PhrasePiece(first->GetCurrBoundary(1).data(),first->GetCurrBoundary(1).size()),ff,first);
	}
#ifdef DEBUG_TLM
	std::cerr<<"add_ax:"<<score<<" ";
#endif
	  
	ForwardBoundaryUpdate(forwardBound,PhrasePiece(first->GetCurrBoundary(0).data(),first->GetCurrBoundary(0).size()),order);

	//after x 
	if (terminals[1].size() > 0){
	  score += ComputeDeltaLM(PhrasePiece(forwardBound.data(),forwardBound.size()),GetBoundary(terminals[1],1,order),ff);
	  ForwardBoundaryUpdate(forwardBound,terminals[1],order);
	}
#ifdef DEBUG_TLM
	std::cerr<<"add_axb:"<<score<<" ";
#endif

  }
  if (second){
    //before x
	if (forwardBound.size() > 0){
	  score += ComputeDeltaLM(PhrasePiece(forwardBound.data(),forwardBound.size()),PhrasePiece(second->GetCurrBoundary(1).data(),second->GetCurrBoundary(1).size()),ff,second);
	}
	ForwardBoundaryUpdate(forwardBound,PhrasePiece(second->GetCurrBoundary(0).data(),second->GetCurrBoundary(0).size()),order);
#ifdef DEBUG_TLM
	std::cerr<<"add_axbx:"<<score<<" ";
#endif

	//after x
	if (terminals[2].size() > 0){
	  score += ComputeDeltaLM(PhrasePiece(forwardBound.data(),forwardBound.size()),GetBoundary(terminals[2],1,order),ff);
	  ForwardBoundaryUpdate(forwardBound,terminals[2],order);
	}
#ifdef DEBUG_TLM
	std::cerr<<"add_axbxc:"<<score<<std::endl;
#endif
	
  }
  rightBound_.resize(forwardBound.size());
  for(size_t i=0;i<forwardBound.size();++i)
	  rightBound_[i] = forwardBound[i];
  //TargetPhrase 
 
  return score;  	

}

void ChartHypothesis::AddUnitScore(size_t featType, float score)
{
	ftScores_.AddFeatScore(featType, score);

}
};
