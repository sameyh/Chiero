#pragma once

#include "dec/stack_cube_pruning.h"

namespace herbal {

//typedef std::vector<ChartHypothesisPtr> ChartHypothesisPool;

class ChartHypothesisPool{
	public:
		void AddCand(ChartHypothesisPtr &hypo);
		bool IsBoundSame(const ChartHypothesisPtr &lh, const ChartHypothesisPtr &rh);
		void SortCand();	
		size_t Size(){
		  return cand_pool_.size();
		}
		const ChartHypothesisPtr GetHypo(size_t index){
		  return cand_pool_[index];
		}
		
	private:
		std::vector<ChartHypothesisPtr> cand_pool_;

};

bool CandSorter(const ChartHypothesisPtr&a , const ChartHypothesisPtr& b);
bool CandLess(const ChartHypothesisPtr&a , const ChartHypothesisPtr& b);

class ChartCubePruning{
		
	
	typedef std::shared_ptr<ChartHypothesisPool> ChartHypothesisPoolPtr;
	
	typedef std::unordered_map<size_t, std::pair<float,FFStatePtr > >  LmCache;
	//typedef std::unordered_map<size_t, std::pair<float, lm::LanguageModel::state_type* > >  LmCache;
	typedef LmCache * LmCachePtr;
	public:

		/*
		 *
		 *
		 * */
		void FillCandMatrixBase(size_t start, size_t last, const TranslationOptions& translationOptions, Queue<ChartHypothesisPtr>& queue);
		/***
		 *
		 *
		 * */
		void GenerateKBest(size_t start, size_t last, const TranslationOptions& translationOptions);
		/*
		 *
		 *
		 * */
		void QueueNeighbours(ChartHypothesisPtr &hyp, Queue<ChartHypothesisPtr>& queue);
		/*
		 *
		 *
		 *
		 * */
		void Resize(size_t len);
		/*
		 *
		 *
		 * */
		const ChartHypothesisPtr Best(size_t sent_length) const;		
		/*
		 *
		 *
		 * */
		const ChartHypothesisPtr NBest(size_t sent_length, size_t index) const;
		void SetLmCache(LmCache &lmCache){
		  lmCachePtr = &lmCache;
		}
		LmCachePtr GetLmCache(){
		  return lmCachePtr;
		}
		const ChartHypothesisPoolPtr GetPool(size_t i, size_t j){
		  return mat_cands[i][j];
		}

	private:
		std::vector<std::vector<ChartHypothesisPoolPtr> > mat_cands;
		LmCachePtr lmCachePtr;


};


};
