#include <thread>

#include "dec/god.h"
#include "lm/vocab.h"
#include "lm/language_model.h"
#include "lm/wc_language_model.h"
#include "pt/paste.h"

#include "dec/ff/feature_function.h"
#include "dec/ff/ff_language_model.h"
#include "dec/ff/ff_distortion_penalty.h"
#include "dec/ff/ff_lexical_reordering.h"

#if !defined HIER_MERT && !defined PHRASE_RELEASE
#define HIER_RELEASE
#endif

namespace herbal {

using namespace lm;

God::God() {}

God God::instance_;

God& God::Init(const std::string& initString) {
  std::vector<std::string> args = po::split_unix(initString);
  int argc = args.size() + 1;
  char* argv[argc];
  argv[0] = const_cast<char*>("bogus");
  for(int i = 1; i < argc; i++)
    argv[i] = const_cast<char*>(args[i-1].c_str());
  return Init(argc, argv);
}


God& God::Init(int argc, char** argv) {
  return Summon().NonStaticInit(argc, argv);
}

God& God::NonStaticInit(int argc, char** argv) {

  po::options_description general("General options");
  general.add_options()
    ("blob,b", po::value<std::string>()->required(),
     "Path to blob")
    ("threads,t", po::value<size_t>()->default_value(std::thread::hardware_concurrency()),
     "Number of parallel threads")
  	("input-file", po::value<std::string>()->default_value(std::string("")),
     "input file")
#ifdef HIER_MERT
	("n-best-list", po::value<std::vector<std::string> >(),
     "nbest list name and number")
#endif
    ("show-unks,u", po::value<bool>()->zero_tokens()->default_value(false),
     "Mark unknown words in output")
	("drop-unks", po::value<bool>()->zero_tokens()->default_value(false),
     "drop unknown words in output")
	("port", po::value<int>()->default_value(8010),
     "Port on which the service will be accessible through XMLRPC")
    ("help,h", po::value<bool>()->zero_tokens()->default_value(false),
     "Print this help message and exit")
  ;
#ifdef HIER_MERT
  po::positional_options_description nbest;
  nbest.add("n-best-list", -1);
#endif

  po::options_description search("Search options");
  search.add_options()
    ("search", po::value<size_t>()->default_value(2),
     "0 - Cube-pruning, 1 - Stack-decoding, 2 - CYK-decoding")
    ("stack-size,s", po::value<size_t>()->default_value(200),
     "Size of decoding stack")
    ("pop-limit,p", po::value<size_t>()->default_value(600),
     "Cube-pruning pop-limit")
    ("max-phrase-length", po::value<size_t>()->default_value(10),
     "Maximum phrase length")
    ("distortion,d", po::value<size_t>()->default_value(6),
     "Distortion limit")
	("beam-size", po::value<size_t>()->default_value(200),
     "CYK-Cube-pruning beam-size")

  ;

  //po::options_description features("Feature options");
  //features.add_options()
  //;

  po::options_description cmdline_options("Allowed options");
  cmdline_options.add(general);
  cmdline_options.add(search);
  //cmdline_options.add(features);

  try {
#if defined HIER_MERT
    po::store(po::command_line_parser(argc,argv)
              .options(cmdline_options).positional(nbest).run(), vm_);
#else
	po::store(po::command_line_parser(argc,argv)
              .options(cmdline_options).run(), vm_);
#endif

    po::notify(vm_);

    //PrintConfig();
  }
  catch (std::exception& e) {
    std::cerr << "Error: " << e.what() << std::endl << std::endl;

    std::cerr << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cerr << cmdline_options << std::endl;
    exit(1);
  }

  if (Get<bool>("help")) {
    std::cerr << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cerr << cmdline_options << std::endl;
    exit(0);
  }

  vocab_.reset(new CHDVocab());
  tm_.reset(new Paste());

  if(Has("blob")) {
    blob_.Map(Get<std::string>("blob"));
	

    blob_ >> *vocab_;
    blob_ >> *tm_;
#if defined HIER_MERT || defined HIER_RELEASE
	for(size_t i=0;i<static_cast<size_t>(FEATURELIST::FEATCOUNT);++i)
		std::cerr<<tm_->GetWeight(i)<<" ";
	std::cerr<<std::endl;
#endif
    while(blob_) {
        ffs_.emplace_back(fffactory_.Load(ffs_.size(), blob_));
    }

	std::cerr<<"load done..."<<std::endl;
  }

  return *this;
}

lm::CHDVocab& God::GetVocab() {
  return *Summon().vocab_;
}

std::vector<FeatureFunctionPtr>& God::GetFFs() {
  return Summon().ffs_;
}

Paste& God::GetTranslationModel() {
  return *Summon().tm_;
}

thread_local std::unique_ptr<Pools> God::pools_;
}
