#include "dec/translation_options.h"
#include "dec/god.h"
#include "pt/paste.h"
#include "time.h"

namespace herbal {

//#define DEBUG
#if !defined HIER_MERT && !defined PHRASE_RELEASE
#define HIER_RELEASE
#endif
TranslationOptions::TranslationOptions(const Sentence& sentence)
 : sentence_(sentence)
{
  size_t len = sentence_.Length();
  wordRanges_.resize(len, std::vector<SourceRangePtr>(len));
#if defined HIER_RELEASE || defined HIER_MERT
  wordXRanges_.resize(len, std::vector<XSourceRangePoolPtr>(len));
  CollectXTranslationOptions();
#else
  CalculateFutureScores();
#endif
}

void TranslationOptions::CollectTranslationOptions() {
  const size_t max_phrase_length = God::Get<size_t>("max-phrase-length");
  for(size_t i = 0; i < sentence_.Length(); ++i) {
    for(size_t l = 0; l < max_phrase_length && i + l < sentence_.Length(); ++l) {
      lm::NGram source(sentence_.GetSource().data() + i, l + 1);
	  TargetPhrases tps = God::GetTranslationModel().find<lm::NGram,TargetPhrase>(source);
#ifdef DEBUG
      std::cerr << i << " " << i+l << " : ";
      for(auto& w : source) {
        std::cerr << w << " (" << God::GetVocab()[w] << ") ";
      }
      std::cerr << std::endl;
      for(auto& tp : tps) {
        std::cerr << "\t" << TargetPhraseVocab(*tp, God::GetVocab()) << std::endl;
      }
#endif
      if(tps.size() > 0) {
        wordRanges_[i][i + l] = God::Create<SourceRange>();
        wordRanges_[i][i + l]->SetRange(i, i + l, &sentence_.GetSource());
        wordRanges_[i][i + l]->SetTargetPhrases(tps);
      }
    }
  }
}
void TranslationOptions::GenerateX2Rules(size_t x1_start,  std::vector<lm::Word> &sourcevec, lm::Word xid, size_t abs_x1_start, size_t abs_x1_len,size_t abs_start,size_t abs_len)
{
	for(size_t len=1;len<sourcevec.size()-x1_start-1;++len){
	  for(size_t i=x1_start+2;i+len-1<sourcevec.size();++i){

#ifdef DEBUG
		  std::cerr<<"start-X1-X2-last: ["<<abs_start<<" ("<<abs_x1_start<<"-"<<abs_x1_start+abs_x1_len-1<<"),("<<abs_x1_start+abs_x1_len-1-x1_start+i<<"-"<<abs_x1_start+abs_x1_len-1-x1_start+i+len-1<<") "<<abs_start+abs_len-1<<"] "<<std::endl;

#endif
		  std::vector<lm::Word> sourceRule(sourcevec.begin(),sourcevec.begin()+i);
		  sourceRule.emplace_back(xid);
		  if(i+len<sourcevec.size())
			  sourceRule.insert(sourceRule.end(),sourcevec.begin()+i+len,sourcevec.end());
		  lm::NGram source(sourceRule.data(),sourceRule.size());
		  FillRuleMatrixUnit(source,abs_start,abs_len,abs_x1_start,abs_x1_len,abs_x1_start+abs_x1_len-1-x1_start+i,len);
	  }
	}
}
void TranslationOptions::GenerateXRules(size_t start, size_t len, const std::vector<lm::Word> &sourcevec, size_t source_last_pos, lm::Word xid )
{
    const size_t max_phrase_length = God::Get<size_t>("max-phrase-length");

	size_t leftbound = max_phrase_length  < start+len ?start+len-max_phrase_length:1;
	size_t rightbound = start+max_phrase_length - 1 < source_last_pos ?  start+max_phrase_length-1:source_last_pos;
	
	for(size_t i=leftbound; i<=start; ++i){
	  for(size_t j=start+len-1;j<i+max_phrase_length && j<=rightbound;++j){
	    if (j<=i+len-1){continue;}
		
		//for x1
#ifdef DEBUG
		std::cerr<<"start-X1-last:"<<i<<" ["<<start<<"-"<<start+len-1<<"] "<<j<<std::endl;
#endif
		std::vector<lm::Word> sourceRule;
		if (start>i)
		  sourceRule.assign(sourcevec.begin()+i,sourcevec.begin()+start);
		sourceRule.emplace_back(xid);
		if (j+1>start+len)
   		  sourceRule.insert(sourceRule.end(),sourcevec.begin()+start+len,sourcevec.begin()+j+1);
		
		lm::NGram source(sourceRule.data(),sourceRule.size());
		FillRuleMatrixUnit(source, i,j-i+1,start,len,0,0);	
		
			
		//for x1 x2
		lm::Word x2id = God::GetVocab()[lm::sX2M];
		GenerateX2Rules(start-i,sourceRule,x2id,start,len,i,j-i+1);
	    
	  } 
	}
   

}
void TranslationOptions::FillRuleMatrixUnit(lm::NGram &source, size_t abs_start, size_t abs_len, size_t abs_x1_start, size_t x1_len, size_t abs_x2_start, size_t x2_len)
{
    TargetXPhrases tps	= God::GetTranslationModel().find<lm::NGram,TargetXPhrase>(source);
#ifdef DEBUG
      std::cerr << abs_start << " " << abs_start+abs_len-1 << " : ";
      for(auto& w : source) {
        std::cerr << w << " (" << God::GetVocab()[w] << ") ";
      }
      std::cerr << std::endl;
      for(auto& tp : tps) {
        std::cerr << "\t" << TargetPhraseVocab(*tp, God::GetVocab()) << std::endl;
      }
#endif
      if(tps.size() > 0) {
		if (wordXRanges_[abs_start][abs_start+abs_len-1]==NULL)
			wordXRanges_[abs_start][abs_start+abs_len-1].reset( new XSourceRangePool() );
        wordXRanges_[abs_start][abs_start + abs_len-1]->push_back( God::Create<XSourceRange>() );
        wordXRanges_[abs_start][abs_start + abs_len-1]->back()->SetRange(abs_start, abs_start + abs_len-1, &sentence_.GetSource());
        wordXRanges_[abs_start][abs_start + abs_len-1]->back()->SetTargetXPhrases(tps);
		if (x1_len > 0){
			wordXRanges_[abs_start][abs_start+abs_len-1]->back()->SetXRange(abs_x1_start,abs_x1_start+x1_len-1);
		}
		if (x2_len > 0){
			wordXRanges_[abs_start][abs_start+abs_len-1]->back()->SetXRange(abs_x2_start , abs_x2_start+x2_len-1);
		}

      }
}
void TranslationOptions::CollectXTranslationOptions()
{
  const size_t max_phrase_length = God::Get<size_t>("max-phrase-length");
  lm::Word x1id = God::GetVocab()[lm::sX1M];
  for(size_t len=1;len <= max_phrase_length && len<=sentence_.Length(); ++len){
  	for(size_t start=0;start<=sentence_.Length() - len; ++start ){
  	    lm::NGram source(sentence_.GetSource().data() + start, len);
		FillRuleMatrixUnit(source,start,len,0,0,0,0);
		if (start ==0 || start+len == sentence_.Length())
			continue;
     	GenerateXRules(start, len, sentence_.GetSource(), sentence_.Length()-2,x1id);  
	  //to do...
	  //add BTG rules here
	}
  }
  GenerateGlueRules();
}
void TranslationOptions::GenerateGlueRules()
{
 
  for(size_t last=0; last<sentence_.Length(); ++last){
	
	wordXRanges_[0][last].reset( new XSourceRangePool()) ;
  	
	TargetXPhrasePtr tp = God::GetTranslationModel().find_glue(last);
	for(size_t split=0;split<last || (last==0 && split==0); ++split ){
      TargetXPhrases tps;
      wordXRanges_[0][last]->emplace_back(God::Create<XSourceRange>());
      wordXRanges_[0][last]->back()->SetRange(0, last, &sentence_.GetSource());
	  if(split < last){
        wordXRanges_[0][last]->back()->SetXRange(0,split);
	    wordXRanges_[0][last]->back()->SetXRange(split+1 , last);
	  }
	  tps.push_back(tp); 

#ifdef DEBUG
      std::cerr << 0 << " " << last << " : ";
      std::cerr << lm::wX1M << " (" << God::GetVocab()[lm::wX1M] << ") ";
      std::cerr << lm::wX2M << " (" << God::GetVocab()[lm::wX2M] << ") ";
      std::cerr << std::endl;
      for(auto& tp : tps) {
        std::cerr << "\t" << TargetPhraseVocab(*tp, God::GetVocab()) << std::endl;
      }
#endif
      wordXRanges_[0][last]->back()->SetTargetXPhrases(tps);
	}
  }
}
float TranslationOptions::GetFutureScorePerCoverage(const Coverage& coverage) const {
  float restCost = 0;
  size_t start = coverage.FirstGap();
  while(start < coverage.GetSize()) {
    if(!coverage.IsCovered(start)) {
      size_t end = start + 1;
      while(end < coverage.GetSize() && !coverage.IsCovered(end))
        end++;
      restCost += (*this)(start, end-1)->GetFutureScore();
      start = end;
    }
    else
      start++;
  }
  return restCost;
}

float TranslationOptions::GetFutureScorePerCoverage(const Coverage& coverage,
                                                    size_t exStart, size_t exEnd) const {
  float restCost = 0;
  size_t start = coverage.FirstGap();
  while(start < coverage.GetSize()) {
    if(!coverage.IsCovered(start) && (start < exStart || start > exEnd)) {
      size_t end = start + 1;
      while(end < coverage.GetSize() && !coverage.IsCovered(end))
        end++;
      restCost += (*this)(start, end-1)->GetFutureScore();
      start = end;
    }
    else
      start++;
  }
  return restCost;
}

const Ranges& TranslationOptions::GetRanges(const HypothesisPtr& hyp) {
  size_t hash = hyp->GetCoverage().Hash();
  auto it = rangesCache_.find(hash);
  if(it == rangesCache_.end()) {
    size_t length = this->GetSentence().Length();
    const Coverage& coverage = hyp->GetCoverage();

    size_t firstGap = 0;
    if(coverage.NumCovered() == 0) {
      // Handle BOS
      rangesCache_[hash].emplace_back(0, 0);
    }
    else if(coverage.NumCovered() == length - 1) {
    // Handle EOS
      rangesCache_[hash].emplace_back(length - 1, length - 1);
    }
    else {
      // @TODO: check impact of "first gap" vs. "end"
      int distortionLimit = God::Get<size_t>("distortion");
      size_t hypEnd = hyp->CurrTargetPhrase()->GetRange()->End();
      firstGap = hyp->GetCoverage().FirstGap();
      for(size_t start = firstGap; start < length - 1; ++start) {
        if(hyp->GetCoverage().IsCovered(start))
          continue;
        if(abs(hypEnd - start + 1) <= distortionLimit) {
          for(size_t end = start; end < length - 1; ++end) {
            if(!(*this)(start, end)->GetTargetPhrases().empty()) {
              if(!hyp->GetCoverage().IsCovered(start, end)) {
                if(firstGap == start)
                  rangesCache_[hash].emplace_back(start, end);
                // make sure there are no gaps that cannot be filled later
                else if (abs(end - firstGap + 1) <= distortionLimit)
                  rangesCache_[hash].emplace_back(start, end);
              }
            }
          }
        }
      }
    }
    return rangesCache_[hash];
  }
  else
    return it->second;
}

float TranslationOptions::GetFutureScore(size_t start, size_t length) {
  if(wordRanges_[start][length] == nullptr)
    wordRanges_[start][length] = God::Create<SourceRange>();
  return wordRanges_[start][length]->GetFutureScore();
}

void TranslationOptions::SetFutureScore(size_t start, size_t length, float score) {
  wordRanges_[start][length]->SetFutureScore(score);
}

void TranslationOptions::CalculateFutureScores() {
  for(size_t length = 1; length < sentence_.Length(); ++length) {
    for(size_t start = 0; start < sentence_.Length() - length; ++start) {
      size_t end = start + length;
      for(size_t i = start; i < end; ++i) {
        float ffs1 = GetFutureScore(start, i);
        float ffs2 = GetFutureScore(i + 1, end);
        float costSum = ffs1 + ffs2;
        if(costSum > GetFutureScore(start, end))
          SetFutureScore(start, end, costSum);
      }
    }
  }
}

}
