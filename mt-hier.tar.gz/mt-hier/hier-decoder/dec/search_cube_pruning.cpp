#include "dec/search_cube_pruning.h"
#include "dec/stack_cube_pruning.h"

namespace herbal {

void SearchCubePruning::Decode(Sentence& sentence,
                               const TranslationOptions& translationOptions) {
  HypothesisPtr empty(God::Create<Hypothesis>(sentence.Length()));
  stacks_.resize(sentence.Length() + 1);
  for(auto& stack : stacks_)
    stack.reset(new StackCubePruning());
  stacks_.front()->Insert(empty);
  
  size_t sno = 0;
  for(auto& stack : stacks_) {
    stack->Prune();
#ifdef DEBUG
    std::cerr << std::endl;
    std::cerr << sno << " Dividing into partitions: " << stack->GetSize() << std::endl;
#endif
    std::shared_ptr<StackCubePruning> cpStack
      = std::static_pointer_cast<StackCubePruning>(stack); 
    cpStack->DivideIntoPartitions(translationOptions);
    Queue<HypothesisPtr> queue;
    for(auto& partition : cpStack->GetPartitions()) {
      HypothesisPtr hyp = partition.second.Best();
      if(hyp != 0)
        queue.push(hyp);
    }
     
    // @TODO: find out where small search errors are coming from
    size_t poplimit = God::Get<size_t>("pop-limit");
    size_t popped = 0;
#ifdef DEBUG
    std::cerr << sno << std::endl;
#endif
    while(!queue.empty() && popped < poplimit) {
      HypothesisPtr top = queue.top();
      queue.pop();
      popped++;
#ifdef DEBUG
      std::cerr << "\t" << *top << std::endl;
#endif
      stacks_[top->GetCoverage().NumCovered()]->Insert(top);
      cpStack->QueueNeighbours(top, queue);
    }
  }
  sno++;
}

}

