#include "lr/builder/lr_utils.h"
#include <cmath>

namespace herbal {

void packSource(std::vector<lm::Word>& stWords,
                util::StringPiece& sourcePhrase,
                util::StringPiece& targetPhrase,
                std::unique_ptr<lm::Vocab>& vocab) {

    std::vector<util::StringPiece> srcTokens;
    util::split(srcTokens, sourcePhrase, " ");
    for (auto& tok : srcTokens)
        stWords.push_back((*vocab)[tok]);

    // separator
    stWords.push_back(0);

    std::vector<util::StringPiece> trgTokens;
    util::split(trgTokens, targetPhrase, " ");
    for (auto& tok : trgTokens)
        stWords.push_back((*vocab)[tok]);
}

void packScores(util::Bytes& targetBytes,
                util::StringPiece& scores,
                const std::vector<float>& weights) {

    std::vector<util::StringPiece> scoreTokens;
    util::split(scoreTokens, scores, " ");

    size_t i = 0;
    for (auto& score : scoreTokens) {
        float weightedScore = weights[i++] * log(boost::lexical_cast<float>(score));
        targetBytes.pack(weightedScore);
    }
}

}
