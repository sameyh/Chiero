#include <string>
#include <iostream>
#include <ios>
#include <vector>
#include <boost/program_options.hpp>
#include <boost/lexical_cast.hpp>

#include "hash/chd_builder.h"
#include "pt/builder/sources_builder.h"
#include "pt/sources.h"

#include "lr/builder/score_builder.h"
#include "lr/builder/lr_utils.h"
#include "lr/lr_scores.h"
#include "lr/lr_table_base.h"
#include "lr/quantization_lr.h"

#include "lm/vocab.h"

#include "util/string_piece.h"
#include "util/string_piece_split.h"
#include "util/blob.h"
#include "util/bytes.h"


#include "dec/ff/ff_header_builder.h"
#include "dec/ff/ff_type.h"

using namespace herbal;

// trim from end
static inline std::string &rtrim(std::string &s) {
    s.erase(std::find_if(s.rbegin(), s.rend(), std::not1(std::ptr_fun<int, int>(std::isspace))).base(), s.end());
    return s;
}

int main(int argc, char** argv) {
    namespace po = boost::program_options;
    po::options_description cmdline_options("Allowed options");

    bool help = false;
    bool quant = false;
    std::string lrPath;
    std::string vocabPath;
    std::string inputPath;

    std::vector<float> lrWeights;

    cmdline_options.add_options()
        ("output,o", po::value(&lrPath)->required(),
         "Path to output file")
        ("vocab,v", po::value(&vocabPath)->required(),
         "Path to common vocabulary")
        ("weights,w", po::value<std::vector<float>>(&lrWeights)->multitoken()->required(),
         "Reordering Model weights")
        ("quantization,q", po::value(&quant)->zero_tokens()->default_value(false),
         "Path to common vocabulary")
        ("help,h", po::value(&help)->zero_tokens()->default_value(false),
         "Print this help message and exit")
        ;

    po::variables_map vm;
    try {
        po::store(po::command_line_parser(argc, argv).options(cmdline_options).style(
                  po::command_line_style::unix_style ^ po::command_line_style::allow_short
        ).run(), vm);
        po::notify(vm);
    }
    catch (std::exception& e) {
        std::cout << "Error: " << e.what() << std::endl << std::endl;

        std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
        std::cout << cmdline_options << std::endl;
        exit(0);
    }

    if(lrWeights.size() != LRScores<float>::ScoreNumber) {
        std:: cout << "Reordering Models required exactly "
            << LRScores<float>::ScoreNumber
            << " weights! (given "
            << lrWeights.size()
            << ")." << std::endl;
        exit(0);
    }

    if (help) {
        std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
        std::cout << cmdline_options << std::endl;
        exit(0);
    }

    std::unique_ptr<lm::Vocab> vocab;
    util::Blob vocabBlob;
    std::unique_ptr<util::ScopedFile> vocabFile;
    if(vocabPath.size() > 0) {
        vocabFile.reset(new util::ScopedFile(vocabPath));
        vocabBlob.Map(*vocabFile);
        vocab.reset(new lm::CHDVocab());
        vocabBlob >> *(lm::CHDVocab*)vocab.get();
    }
    else
        vocab.reset(new lm::GrowVocab());

    std::ios_base::sync_with_stdio(false);

    ByteMapBuilder sourceByteMapBuilder;
    ScoreBuilder<LRScores<float>> scoreBuilder;

    size_t lineCounter = 0;

    for (std::string line; std::getline(std::cin, line); ) {
        rtrim(line);
        util::StringPiece s(line.data(), line.length());
        std::vector<util::StringPiece> fields;
        split(fields, s, " ||| ");
        if (fields.size() != 3) {
            std::cerr << "Line: " << line << "is broken. " << std::endl;
            continue;
        }
        ++lineCounter;

        std::vector<lm::Word> stWords;
        packSource(stWords, fields[0], fields[1], vocab);
        sourceByteMapBuilder.AppendPos();
        sourceByteMapBuilder.AppendData(stWords.data(), stWords.size());

        util::Bytes scoresBytes;
        packScores(scoresBytes, fields[2], lrWeights);
        scoreBuilder.AppendData(scoresBytes.data());

        if(lineCounter % 20000 == 0) {
          std::cout << ".";
        }
        if(lineCounter % 1000000 == 0) {
            std::cout << lineCounter << std::endl;
        }
    }
    util::ScopedFile sf(lrPath, util::SF_WRITE);

    FFHeaderBuilder(FFType::LexicalReorderingModel, std::vector<float>()) >> sf;

    ByteMap sources;
    sourceByteMapBuilder >> sources;
    SourcesBuilder(sources) >> sf;

    if (!quant) {
      sf << static_cast<uint8_t>(LRTableBase::LRTableType::Normal);
      scoreBuilder >> sf;
    } else {
        util::Blob tmpBlob;
        scoreBuilder.GetBytes() >> tmpBlob;
        util::ManyChunks<LRScores<float>> scores;
        tmpBlob >> scores(lineCounter);
        LRQuantization quantization;
        quantization.Compute(&scores);

        ScoreBuilder<LRScores<uint8_t>> tableBuilder;
        for (auto& entry: scores) {
          util::Bytes entryBytes;
          for (auto& score: entry) {
            entryBytes.pack((uint8_t)quantization.GetBucketIndex(score));
          }
          tableBuilder.AppendData(entryBytes.data());
        }
        sf << static_cast<uint8_t>(LRTableBase::LRTableType::Quantized);

        sf << (uint64_t)quantization.GetCentroids().size();
        for (auto& centroid: quantization.GetCentroids()) {
            sf << (float)centroid;
        }
        tableBuilder >> sf;
    }
}

