#pragma once

#include <algorithm>
#include <iostream>
#include <vector>
#include <iterator>

#include "util/blob.h"
#include "util/scoped_file.h"

namespace herbal {

    /**
     * @brief Builder of Lexical Reordering Model Scores
     *
     * @tparam T Type of scores
     */
template<typename T>
class ScoreBuilder : public util::Blob {
  public:

      /**
       * @brief Add new scores (data) to a builder.
       *
       * @param data
       */
    void AppendData(Byte* data) {
      bytes_.Write(data, sizeof(T));
    }

    /**
     * @brief Write all data (scores) to a scopedFile.
     *
     * @param sf Scoped File to write to.
     *
     * @return  True if the writing process was correct.
     */
    bool Write(util::ScopedFile& sf) {
      sf << (uint64_t)(bytes_.Size() / sizeof(T));

      util::Blob mapper;
      bytes_  >> mapper >> sf;

      return true;
    }


    /**
     * @brief Wrapper for the Write function. See @Write
     *
     * @param sf ScopedFile to write to.
     *
     * @return Reference to this builder.
     */
    ScoreBuilder& operator>>(util::ScopedFile& sf) {
      Write(sf);
      return *this;
    }
    util::ScopedFile& GetBytes() {
        return bytes_;
    }

  private:
    util::ScopedFile bytes_;
};

}
