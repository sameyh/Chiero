#pragma once

#include <vector>
#include <memory>
#include <algorithm>
#include <boost/lexical_cast.hpp>

#include "util/string_piece.h"
#include "util/string_piece_split.h"
#include "util/bytes.h"

#include "lm/vocab.h"

namespace herbal {

    /**
     * @brief Convert into a key(bytes) the source and target phrases.
     *
     * @param stWords Key to make.
     * @param sourcePhrase Source phrase
     * @param targetPhrase Target phrase
     * @param vocab Vocabulary
     */
void packSource(std::vector<lm::Word>& stWords,
                util::StringPiece& sourcePhrase,
                util::StringPiece& targetPhrase,
                std::unique_ptr<lm::Vocab>& vocab);

/**
 * @brief  Pack scores into a sequence of bytes.
 *
 * @param targetBytes Target bytes.
 * @param scores Scores to pack.
 * @param weights weights of a LR Model.
 */
void packScores(util::Bytes& targetBytes,
                util::StringPiece& scores,
                const std::vector<float>& weights);
}
