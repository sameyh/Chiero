#pragma once

#include <vector>
#include <string>
#include <algorithm>

#include "lr/quantization.h"

#include "lr/lr_scores.h"
#include "lr/lr_table.h"
#include "util/chunk.h"

namespace herbal {

class LRQuantization : public Quantization {
  private:
    void FillBuckets(const void* table) {
      for (auto& scores: *(util::ManyChunks<LRScores<float>>*)table) {
        for (auto& score: scores) {
          AddData(score);
        }
      }
    }

    void FindBounds(const void* table) {
      for (auto& scores: *(util::ManyChunks<LRScores<float>>*)table) {
        for (auto& score: scores) {
          UpdateBounds(score);
        }
      }
    }

};

}
