#pragma once

#include "util/blob.h"
#include "util/chunk.h"

#include "lr/lr_scores.h"
#include "lr/lr_table_base.h"

namespace herbal {

class QLRTable: public LRTableBase
{
  public:
    LRScores<float> GetScores(const size_t& index) const {
      float scores[LRScores<float>::ScoreNumber];
      const LRScores<uint8_t> &indexes = indexes_[index];
      for (size_t i = 0; i < LRScores<float>::ScoreNumber; ++i) {
          scores[i] = centroids_[indexes[i]];
      }
      return scores;
    }

  private:
    util::Chunk64 centroidsSize_;
    util::ManyChunks<float> centroids_;
    util::Chunk64 arraySize_;
    util::ManyChunks<LRScores<uint8_t>> indexes_;

    void MapBlob(util::Blob& blob) {
      blob >> centroidsSize_;
      blob >> centroids_(centroidsSize_);
      blob >> arraySize_;
      blob >> indexes_(arraySize_);
    }
};

}
