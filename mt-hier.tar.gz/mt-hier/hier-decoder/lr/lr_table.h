
#pragma once
#include <cmath>

#include "util/blob.h"
#include "util/chunk.h"

#include "lr/lr_scores.h"
#include "lr/lr_table_base.h"

namespace herbal {

class LRTable: public LRTableBase
{
  public:
    const LRScores<float>* begin() const {
      return scores_.begin();
    }

    const LRScores<float>* end() const {
      return scores_.end();
    }

    virtual LRScores<float> GetScores(const size_t& index) const {
      return scores_[index];
    }

  private:
    util::Chunk64 arraySize_;
    util::ManyChunks<LRScores<float>> scores_;

    void MapBlob(util::Blob& blob) {
      blob >> arraySize_;
#ifdef DEBUG
      std::cerr << "ARRAY SIZE: " << arraySize_ << std::endl;
#endif
      blob >> scores_(arraySize_);
    }
};

}
