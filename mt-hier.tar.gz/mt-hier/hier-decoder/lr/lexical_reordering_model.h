#pragma once

#include <string>
#include <iostream>
#include <vector>

#include "util/string_piece.h"
#include "util/string_piece_split.h"
#include "util/blob.h"
#include "util/chunk.h"

#include "pt/sources.h"

#include "lm/vocab.h"

#include "lr/lr_table_base.h"
#include "lr/lr_scores.h"

namespace herbal {

    /**
     * @brief Lexical Reordering Model.
     *
     * The model uses the following configuration: msd-bidirectional-fe.
     * It means that there are three types of reordering (monotonious, swapped and
     * discontinious), two scores (backward and forward) and training based on both
     * the source and target languages.
     *
     */
class LexicalReorderingModel : public util::Blobbed {

    public:
        /**
         * @brief Default constructor.
         */
        LexicalReorderingModel();
        /**
         * @brief Constructor - load a model from a blob.
         *
         * @param blob Blob.
         */
        LexicalReorderingModel(util::Blob& blob);

        /**
         * @brief Return scores with a  given key.
         *
         * @param key Key. See the MakeKey method.
         *
         * @return  LRScores associated with the key.
         */
        template <class Key>
        const LRScores<float> GetScores(Key& key)
        {
            const size_t index = sources_[key];
            return (index != Sources::NotFound) ? (*lrTable_)[index] : unkScore_;
        }

        /**
         * @brief Return scores with a  given key.
         *
         * @param key Key. See the MakeKey method.
         *
         * @return  LRScores associated with the key.
         */
        template <class Key>
        const LRScores<float> operator[](Key& key) {
            return GetScores(key);
        }


        /**
         * @brief Create a key from the source and target phrases.
         *
         * @param sPhrase Source phrase.
         * @param tPhrase Target phrase.
         * @param key Created key.
         */
        static void MakeKey(const std::vector<lm::Word>& sPhrase,
                     const std::vector<lm::Word>& tPhrase,
                           std::vector<lm::Word>& key);

        // void CheckLRTable() {
            // int i = 0;
            // for (auto& scores: *lrTable_) {
                // for (auto& score: scores) {
                    // if (score >=0 || score < -20)
                        // std::cerr << "STRANGE: " << score << "in " << i << std::endl;
                // }
                // ++i;
            // }
        // }


    private:
        void MapBlob(util::Blob& blob);
        std::unique_ptr<LRTableBase> lrTable_;
        Sources sources_;
        LRScores<float> unkScore_;
    };

}
