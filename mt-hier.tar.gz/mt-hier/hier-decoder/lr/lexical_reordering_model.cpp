#include "lr/lexical_reordering_model.h"

#include <vector>

#include "lm/vocab.h"
#include "lr/lr_table_base.h"
#include "lr/lr_table.h"
#include "lr/qlr_table.h"
#include "util/chunk.h"


using namespace herbal;

LexicalReorderingModel::LexicalReorderingModel()
    : sources_() {
}

LexicalReorderingModel::LexicalReorderingModel(util::Blob& blob) {
    MapBlob(blob);
}

void LexicalReorderingModel::MapBlob(util::Blob& blob) {
    blob >> sources_;
    util::Chunk<LRTableBase::LRTableType> lrTableType;
    blob >> lrTableType;
#ifdef DEBUG
    std::cerr << "lrTableType: " << (int)static_cast<uint8_t>(*lrTableType.data()) << std::endl;;
#endif

    if (lrTableType == LRTableBase::LRTableType::Normal) {
        lrTable_ = std::unique_ptr<LRTableBase>(new LRTable());
    } else {
        lrTable_ = std::unique_ptr<LRTableBase>(new QLRTable());
    }
    blob >> *lrTable_;
}

void LexicalReorderingModel::MakeKey(
    const std::vector<lm::Word>& sPhrase,
    const std::vector<lm::Word>& tPhrase,
          std::vector<lm::Word>& key)
{
    key.clear();
    for (auto& tok : sPhrase) {
        key.push_back(tok);
    }
    key.push_back(0);
    for (auto& tok : tPhrase) {
        key.push_back(tok);
    }
}
