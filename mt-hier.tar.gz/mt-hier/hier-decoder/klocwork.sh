#!/bin/sh

export FLEXLM_TIMEOUT=9000000
export PATH=${PATH}:/home/$USER/Klocwork/klocwork/bin
export PATH=${PATH}:/usr/share/ant/bin
export KW_JAVA=/usr/lib/jvm/java-6-openjdk-amd64/jre/bin/java

mkdir -p kw_build
cd kw_build
cmake ..

rm -f -r klocwork/
rm -f -r .kwps/
rm -f spec.out

make clean
kwinject -T build.trace make
kwinject -t build.trace -o spec.out

kwcheck create -pd klocwork
kwcheck import -pd klocwork /home/$USER/Klocwork/KWruleset/Mandatory.pconf.xml
kwcheck set license.host=165.213.149.177 -pd klocwork
kwcheck run -pd klocwork -b spec.out -F detailed > report.txt
kwgcheck klocwork/

