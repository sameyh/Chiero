#include <string>
#include <iostream>
#include <ios>
#include <vector>
#include <boost/program_options.hpp>
#include <boost/lexical_cast.hpp>

#include "pt/paste.h"
#include "pt/builder/sources_builder.h"
#include "pt/sources.h"
#include "pt/builder/byte_map_builder.h"

#include "util/string_piece.h"
#include "util/string_piece_split.h"

#include "util/blob.h"
#include "util/bytes.h"

#include "lm/vocab.h"

#include "dec/ff/ff_factory.h"
#include "dec/ff/ff_header_builder.h"

#if !defined HIER_MERT && !defined PHRASE_RELEASE
#define HIER_RELEASE
#endif
using namespace herbal;
//enum modeltype{PHRASE_RELEASE,HIER_MERT,HIER_RELEASE};

void packSource(std::vector<lm::Word>& sourceWords, util::StringPiece& source,
                std::unique_ptr<lm::Vocab>& vocab) {
  std::vector<util::StringPiece> srcTokens;
  util::split(srcTokens, source, " ");
  for(auto& tok : srcTokens)
      sourceWords.push_back((*vocab)[tok]);
}

float queryFF(TargetPhrase& targetPhrase, FeatureFunctionPtr& ff) {
  FFStatePtr state = ff->EmptyState();
  FFStatePtr nextState = ff->EmptyState();
  return ff->Score(state, &targetPhrase, nextState);
}
size_t WordCount(util::StringPiece& target,size_t trgTokenSize)
{
  size_t trg_word_count=trgTokenSize;
  size_t pos1=target.find(lm::sX1M);
  size_t pos2=target.find(lm::sX2M);
  if (pos1!=util::StringPiece::npos){
	  trg_word_count -= 1;
  }
  if(pos2!=util::StringPiece::npos){
	  trg_word_count -= 1;
  }
 return trg_word_count; 

}
float packAndScoreTarget(util::Bytes& targetBytes,
                util::StringPiece& target,
                util::StringPiece& scores,
                util::StringPiece& alignment,
                std::unique_ptr<lm::Vocab>& vocab,
                const std::vector<float>& weights,
                std::vector<FeatureFunctionPtr>& ffs,
				int modelType) {

  std::vector<util::StringPiece> trgTokens;
  util::split(trgTokens, target, " ");
  std::vector<size_t> pos;
  
  size_t trg_word_count = WordCount(target,trgTokens.size());
  targetBytes.pack((Byte)trgTokens.size());

  std::vector<lm::Word> targetWords;
  std::vector<TargetPhrase > terminals;
  std::vector<lm::Word> tmp_targetWords;
  
  lm::Word x1id = (*vocab)[lm::sX1M];
  lm::Word x2id = (*vocab)[lm::sX2M];
  size_t k=0;
  for (auto& tok : trgTokens) {
    lm::Word word = (*vocab)[tok];
    targetBytes.pack(word);
    targetWords.push_back(word);
	if(word==x1id || word == x2id)
		pos.push_back(k);
	++k;
  }

  if(pos.empty())
	terminals.emplace_back(PhrasePiece(targetWords.data(),targetWords.size()),ScorePiece(),AlignmentPiece());
  else{
    terminals.emplace_back(PhrasePiece(targetWords.data(),pos[0]),ScorePiece(),AlignmentPiece());
    if(pos.size()>1)
	  terminals.emplace_back(PhrasePiece(targetWords.data()+pos[0]+1,pos[1]-pos[0]-1),ScorePiece(),AlignmentPiece());
  	if(pos.back()+1<targetWords.size())
	  terminals.emplace_back(PhrasePiece(targetWords.data()+pos.back()+1,targetWords.size()-pos.back()-1),ScorePiece(),AlignmentPiece());
  } 


  std::vector<util::StringPiece> scoreTokens;
  util::split(scoreTokens, scores, " ");
  float sum = 0;
  size_t i = 0;

  // tm scores

  for(auto& score : scoreTokens){
    sum += weights[i] * (boost::lexical_cast<float>(score));
#if defined HIER_MERT
	targetBytes.pack( (boost::lexical_cast<float>(score)));
#endif
	++i;
  }
  
  float penalties = 0;
  // word-penalty
  penalties += weights[i] *-(int)trg_word_count;
#if defined HIER_MERT
  float wp_val=-1*(int)trg_word_count;
  targetBytes.pack(wp_val);
#endif
  ++i;

  // prase-penalty
  penalties += weights[i] * 1;
#if defined HIER_MERT
  float pp_val = 1;
  targetBytes.pack(pp_val);
#endif
  ++i;
  
  TargetPhrase targetPhrase(
          PhrasePiece(targetWords.data(), targetWords.size()),
          ScorePiece(), AlignmentPiece()
  );

  // lm-score (part of future score)
  float ffScore = 0.0;
#if defined PHRASE_RELEASE
  for (auto& ff: ffs) {
    ffScore += queryFF(targetPhrase, ff);
  }

  sum += penalties;
  ffScore -= penalties;
  targetBytes.pack(sum);
  targetBytes.pack(ffScore);

#elif defined HIER_MERT
  for(auto& ff: ffs){
	for(auto& tp: terminals){
	  float a = queryFF(tp,ff);
	  ffScore += a;
	}
  }	
  sum += ffScore * weights[i]; 
  targetBytes.pack(ffScore); 

#elif defined HIER_RELEASE
 	 
  for(auto& ff: ffs){
    for(auto& tp: terminals){
	  float a = queryFF(tp,ff);
	  ffScore += a;
	}
  }
  sum += penalties;
  sum += ffScore;
  targetBytes.pack(sum);
#endif
  ++i;

  //glue penalty
#if defined HIER_MERT
  targetBytes.pack(weights[i] * 0);
#endif

  ++i;

  std::vector<util::StringPiece> alignTokens;
  util::split(alignTokens, alignment, " ");
  targetBytes.pack((Byte)alignTokens.size());
  for(auto& align : alignTokens) {
    std::vector<util::StringPiece> ij;
    util::split(ij, align, "-");
    targetBytes.pack((Byte)boost::lexical_cast<size_t>(ij[0]));
    targetBytes.pack((Byte)boost::lexical_cast<size_t>(ij[1]));
  }
#if defined HIER_MERT
  return sum;
#elif defined HIER_RELEASE
  return sum-penalties;
#else
  return sum + ffScore;
#endif
}

void getOptions(
   int argc,
   char** argv,
   std::string& ptPath,
   std::string& vocabPath,
   std::vector<std::string>& lmPaths,
   std::vector<float>& tmWeights,
   float& wordPenalty,
   float& phrasePenalty,
   float& gluePenalty,
   float& lmPenalty) {
    
  namespace po = boost::program_options;
  po::options_description cmdline_options("Allowed options");

  bool help = false;

  cmdline_options.add_options()
    ("output,o", po::value(&ptPath)->required(),
     "Path to output phrase table")
    ("vocab,v", po::value(&vocabPath)->required(),
     "Path to common vocabulary")
    ("lm,l", po::value<std::vector<std::string>>(&lmPaths)->multitoken(),
     "Path to lms for scoring")
    ("tm-weights", po::value<std::vector<float> >(&tmWeights)->multitoken(),
     "Translation model weights")
    ("word-penalty", po::value<float>(&wordPenalty),
     "Word penalty weight")
    ("phrase-penalty", po::value<float>(&phrasePenalty),
     "Phrase penalty weight")
	("glue-penalty", po::value<float>(&gluePenalty),
     "Phrase penalty weight")
	("lm-penalty", po::value<float>(&lmPenalty),
     "lm weight")
    ("help,h", po::value(&help)->zero_tokens()->default_value(false),
     "Print this help message and exit")
  ;

  po::variables_map vm;
  try {

    po::store(po::parse_command_line(argc, argv, cmdline_options,
                                     po::command_line_style::unix_style ^
                                     po::command_line_style::allow_short), vm);
    po::notify(vm);
  }

  catch (std::exception& e) {
    std::cout << "Error: " << e.what() << std::endl << std::endl;

    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }

  if (help) {
    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }
}

int main(int argc, char** argv) {
  std::string ptPath;
  std::string vocabPath;
  std::vector<std::string> lmPaths;
  std::vector<float> tmWeights;
  float wordPenalty = 0;
  float phrasePenalty = 0;
  float gluePenalty = 0;
  float lmPenalty = 0;

  getOptions(argc, argv, ptPath, vocabPath, lmPaths, tmWeights, wordPenalty, phrasePenalty, gluePenalty, lmPenalty);

  std::vector<float> weights;
  for(auto& weight: tmWeights) {
    weights.push_back(weight);
  }
  weights.push_back(wordPenalty);
  weights.push_back(phrasePenalty);
  weights.push_back(lmPenalty);
  weights.push_back(gluePenalty);
  std::cout<<"weight size:"<<weights.size()<<std::endl;
  float penalties = 0;
  penalties += wordPenalty * -1;
  penalties += phrasePenalty * 1;

  FFFactory ffFactory;
  std::vector<FeatureFunctionPtr> ffs;
  std::vector<std::unique_ptr<util::Blob>> lmBlobs;
  std::vector<std::unique_ptr<util::ScopedFile>> lmFiles;

  for (auto& lmPath : lmPaths) {
    std::cout << "LM: " << lmPath << std::endl;
    if (lmPath.size() > 0) {
      lmFiles.emplace_back(new util::ScopedFile(lmPath));
      lmBlobs.emplace_back(new util::Blob());
      lmBlobs.back()->Map(*lmFiles.back());
      ffs.push_back(ffFactory.Load(0, *lmBlobs.back()));
    }
  }


  std::unique_ptr<lm::Vocab> vocab;
  util::Blob vocabBlob;
  std::unique_ptr<util::ScopedFile> vocabFile;
  if(vocabPath.size() > 0) {
    vocabFile.reset(new util::ScopedFile(vocabPath));
    vocabBlob.Map(*vocabFile);
    vocab.reset(new lm::CHDVocab());
    vocabBlob >> *(lm::CHDVocab*)vocab.get();
  } else {
    vocab.reset(new lm::GrowVocab());
  }

  std::ios_base::sync_with_stdio(false);

  ByteMapBuilder sourceByteMapBuilder;
  ByteMapBuilder targetByteMapBuilder;

  size_t count = 0;
  size_t countSource = 0;
  std::string lastSource;

  size_t maxSourcePhraseLength = 0;

  std::vector<std::pair<float,util::Bytes>> targetBytesCollection;

  //std::cerr<<"start to convert...\n";
  std::string line;
  while(std::getline(std::cin, line)) {
    util::StringPiece s(line.data(), line.length());
    std::vector<util::StringPiece> fields;
    split(fields, s, " ||| ");

    if(lastSource.empty() || lastSource != fields[0]) {
      std::sort(targetBytesCollection.begin(), targetBytesCollection.end());

      size_t c = 0;
      for(auto& scoredTp : targetBytesCollection) {
        if (c >= 20) break; // no table limit
        targetByteMapBuilder.AppendData(scoredTp.second.data(),
                                        scoredTp.second.size());
        c++;
      }
      targetBytesCollection.clear();

      sourceByteMapBuilder.AppendPos();
      std::vector<lm::Word> sourceWords;
      packSource(sourceWords, fields[0], vocab);

      if(sourceWords.size() > maxSourcePhraseLength)
        maxSourcePhraseLength = sourceWords.size();

      sourceByteMapBuilder.AppendData(sourceWords.data(), sourceWords.size());
      lastSource = fields[0].as_string();
      countSource++;

      targetByteMapBuilder.AppendPos();
    }

    util::Bytes targetBytes;
    float score = packAndScoreTarget(targetBytes,
                                     fields[1], fields[2], fields[3],
                                     vocab, weights, ffs,1);
    targetBytesCollection.emplace_back(-score, targetBytes);

    count++;
    if(count % 20000 == 0) {
      std::cout << ".";
    }
    if(count % 1000000 == 0) {
      std::cout << countSource << "/" << count << std::endl;
    }
  }
  std::sort(targetBytesCollection.begin(), targetBytesCollection.end());
  size_t c = 0;
  for(auto& tp : targetBytesCollection) {
    if (c >= 20) break; //No table limit 
    targetByteMapBuilder.AppendData(tp.second.data(), tp.second.size());
    c++;
  }

  util::ScopedFile sf(ptPath, util::SF_WRITE);
  FFHeaderBuilder(FFType::PhraseTable, weights) >> sf;
#if defined PHRASE_RELEASE
  sf << penalties;
#else
  for(auto &wt:weights)
	sf<<wt;  
#endif
  sf << maxSourcePhraseLength;

  ByteMap sources;
  sourceByteMapBuilder >> sources;
  SourcesBuilder(sources) >> sf;

  targetByteMapBuilder >> sf;
}

