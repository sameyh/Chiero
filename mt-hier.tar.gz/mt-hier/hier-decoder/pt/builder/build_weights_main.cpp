#include <string>
#include <iostream>
#include <ios>
#include <vector>
#include <boost/program_options.hpp>
#include <boost/lexical_cast.hpp>

#include "util/blob.h"
#include "util/bytes.h"
#include "lm/vocab.h"
#include "lm/language_model.h"

using namespace herbal;

int main(int argc, char** argv) {
  namespace po = boost::program_options;
  po::options_description cmdline_options("Allowed options");

  bool help = false;

  std::string weightsPath;
  float languageModelWeight = 1;
  float wcLanguageModelWeight = 1;
  float distortionWeight = 1;
  float lrWeight = 1;

  cmdline_options.add_options()
    ("output,o", po::value(&weightsPath)->required(),
     "Path to output weights")
    ("lm-weight", po::value<float>(&languageModelWeight),
     "Language model weight")
    ("wclm-weight", po::value<float>(&wcLanguageModelWeight),
     "Language model weight")
    ("distortion-weight", po::value<float>(&distortionWeight),
     "Distortion penalty")
    ("help,h", po::value(&help)->zero_tokens()->default_value(false),
     "Print this help message and exit")
  ;

  po::variables_map vm;
  try {
    po::store(po::command_line_parser(argc, argv).
              options(cmdline_options).run(), vm);
    po::notify(vm);
  }
  catch (std::exception& e) {
    std::cout << "Error: " << e.what() << std::endl << std::endl;

    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }

  if (help) {
    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }

  std::vector<float> weights;
  weights.push_back(languageModelWeight);
  weights.push_back(wcLanguageModelWeight);
  weights.push_back(distortionWeight);
  weights.push_back(lrWeight);

  util::ScopedFile sf(weightsPath, util::SF_WRITE);

  sf << (uint64_t)weights.size();
  for (auto& weight: weights) {
      sf << (float)weight;
  }
}
