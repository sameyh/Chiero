#pragma once

#include <algorithm>

#include "util/blob.h"
#include "pt/builder/byte_map_builder.h"

namespace herbal {

class TargetsBuilder : public util::Blob {
  public:
     
    TargetsBuilder() {}
    
    template <class Trans>
    TargetsBuilder(const Trans& trans) {
      Build(trans);
    }
    
    template <class Trans>
    TargetsBuilder& Build(const Trans& trans) {
      
      char null = '\0';
      
      ByteMapBuilder byteMapBuilder;
      for(auto& tps : trans) {
        byteMapBuilder.AppendPos();
        for(auto& tp : tps) {
          byteMapBuilder.AppendData(tp.data(), tp.length());
          byteMapBuilder.AppendData(&null, 1); 
        }
      }
      byteMapBuilder >> sf_;
      Map(sf_);
      return *this;
    }
    
  private:
    util::ScopedFile sf_;
};
    
}