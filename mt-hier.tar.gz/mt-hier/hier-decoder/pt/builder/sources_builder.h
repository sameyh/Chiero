#pragma once

#include <algorithm>

#include "util/blob.h"
#include "pt/builder/check_order_builder.h"
#include "hash/chd.h"
#include "hash/chd_builder.h"

namespace herbal {

class SourcesBuilder : public util::Blob {
  public:

    SourcesBuilder() {}

    template <class Keys>
    SourcesBuilder(const Keys& keys) {
      Build(keys);
    }

    template <class Keys>
    SourcesBuilder& Build(const Keys& keys) {

      CHD<herbal::Murmur> hash;
      CHDBuilder<herbal::Murmur> hash_builder(keys, 0.9);
      hash_builder >> hash;

      CheckOrderBuilder<herbal::Murmur> co_builder(keys, hash);

      Allocate(hash_builder.size() + co_builder.size());

      *this
        << hash_builder
        << co_builder;

      Rewind();

      return *this;
    }
};

}
