#pragma once

#include <algorithm>

#include "util/blob.h"
#include "pt/check_order.h"

namespace herbal {

template <class RandomHash>
class CheckOrderBuilder : public util::Blob {
  public:
     
    CheckOrderBuilder() {}
    
    template <class Keys, class Hash>
    CheckOrderBuilder(const Keys& keys, const Hash& hash) {
      Build(keys, hash);
    }
    
    template <class Keys, class Hash>
    CheckOrderBuilder& Build(const Keys& keys, const Hash& hash) {
      size_t bytes = sizeof(uint32_t) + sizeof(OrderTuple) * keys.size();
      Allocate(bytes);
            
      util::Chunk<uint32_t> size;
      util::ManyChunks<OrderTuple> orderTuples;
      
      (*this) >> size;
      size = keys.size();
      (*this) >> orderTuples(size);
      
      uint32_t seed = hash.GetSeed();
      size_t i = 0;
      for(auto& key: keys) {
        HashTuple ht;
        RandomHash::Hash(seed, key, ht);
        uint64_t pos = hash[ht];
        orderTuples[pos].p = ht.p;
        orderTuples[pos].i = i;
        i++;
      }
      Rewind();
      return *this;
    }
};
    
}