#pragma once

#include <algorithm>
#include <vector>
#include <cstring>

#include "dec/god.h"
#include "util/blob.h"
#include "util/exception.h"
#include "util/string_piece.h"
#include "pt/byte_map.h"
#include "pt/target_phrase.h"

namespace herbal {

class Targets : public util::Blobbed {
  public:
	template<typename T>
    std::vector<T*> find(uint64_t pos) {
      try {
        return DecodeBytes<T>(byteMap_[pos]);  
      }
      catch(util::Exception& e) {
        return std::vector<T*>();
      }
    }

  private:
	template<typename T>
    std::vector<T*> DecodeBytes(const util::ManyChunksC8 bytes) {
		std::vector<T*> tps;
      TargetPhraseDecoder tpd(bytes.data(), bytes.size());
      T* tp = God::Create<T>();
      while(tpd >> *tp) {
        tps.push_back(tp);
        tp = God::Create<T>();
      }
      return tps;
    }

    void MapBlob(util::Blob& blob) {
      blob
        >> byteMap_;
    }

    ByteMap byteMap_;
};

}
