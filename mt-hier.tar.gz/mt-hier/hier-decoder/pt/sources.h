#pragma once

#include <algorithm>

#include "util/blob.h"
#include "hash/random_hash.h"
#include "hash/chd.h"
#include "pt/check_order.h"

namespace herbal {

class Sources : public util::Blobbed {
  public:  
    template <class Key>
    uint64_t operator[](Key& key) {
      HashTuple tuple;
      Murmur::Hash(hash_.GetSeed(), key, tuple);
      uint64_t pos = hash_[tuple];
      if(tuple.p == checkOrder_[pos].p)
        return checkOrder_[pos].i;
      else
        return NotFound; 
    }
    
  private:
    
    void MapBlob(util::Blob& blob) {
      blob
        >> hash_
        >> checkOrder_;
    }
    
    CHD<Murmur> hash_;
    CheckOrder checkOrder_;
    
  public:
    static const uint64_t NotFound;
};    
}