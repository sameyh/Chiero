#pragma once

#include <algorithm>

#include "util/blob.h"
#include "pt/sources.h"
#include "pt/targets.h"
#include "dec/ff/ff_header.h"
#include "dec/ff/ff_language_model.h"
#include "dec/god.h"

#if !defined HIER_MERT && !defined PHRASE_RELEASE
#define HIER_RELEASE
#endif

namespace herbal {

const size_t  WNUM = 8;

class Paste : public util::Blobbed {
  public:

    template <class Key,class T>
    std::vector<T*> find(Key& key) {
      if(key.size() == 1) {
        if (key.data()[0] == lm::wBOS) {
          return BOS<T>();
        }
        if (key.data()[0] == lm::wEOS) {
          return EOS<T>();
        }
      }
      
      if(key.size() > maxSourcePhraseLength_)
        return std::vector<T*>();
      
      uint64_t pos = sources_[key];
      if(pos != Sources::NotFound)
        return targets_.find<T>(pos);
      else {
        if(key.size() == 1)
          //return UNK<Key,T>(key);   
          return UNK<PhrasePiece,T>(PhrasePiece(&lm::wUNK,1)); //words in vocab, but no any candidate 
        else
          return std::vector<T*>();
      }
    }
    TargetXPhrasePtr find_glue(size_t last) {
		if (last == 0){
		  std::vector<TargetXPhrasePtr> tps = BOS<TargetXPhrase>();
		  return tps[0];
		}
		else
		  return GLUE();	
	}

  const	util::Chunk<float> &GetWeight(size_t index) {
    return weights[index];
  }

  private:
    template<typename T> 
    std::vector<T*> BOS() {
	  std::vector<T*> tpBOS;
      PhrasePiece bos(&lm::wBOS, 1);
#if defined HIER_MERT
	  ScorePiece bosScorePiece(xbosScore_,WNUM);
#elif defined HIER_RELEASE
	  ScorePiece bosScorePiece(xbosScoreRL_,1);
#else
      ScorePiece bosScorePiece(bosScore_, 2);
#endif
      AlignmentPiece ap(&oneone_, 1);
      tpBOS.emplace_back(God::Create<T>(bos, bosScorePiece, ap));
      return tpBOS;
    }
   	template<typename T> 
    std::vector<T*> EOS() {
		std::vector<T*>tpEOS;
      PhrasePiece eos(&lm::wEOS, 1);
#if defined HIER_MERT
	  ScorePiece eosScorePiece(xeosScore_,WNUM);
#elif defined HIER_RELEASE
	  ScorePiece eosScorePiece(xeosScoreRL_,1);
#else
      ScorePiece eosScorePiece(eosScore_, 2);
#endif
      AlignmentPiece ap(&oneone_, 1);
      tpEOS.emplace_back(God::Create<T>(eos, eosScorePiece, ap));
      return tpEOS;
    }
	
    TargetPhrases UNK() {
      PhrasePiece key(&lm::wUNK, 1);
	  TargetPhrases tps;
      return UNK<PhrasePiece,TargetPhrase>(key);
    }

   TargetXPhrasePtr GLUE() {
      PhrasePiece glue(glueTarget_, 2);

#if defined HIER_MERT 
      ScorePiece sp(glueScore_, WNUM);
#else
      ScorePiece sp(glueScoreRL_, 1);
#endif

      AlignmentPiece ap(glue_, 2);
      TargetXPhrasePtr p= God::Create<TargetXPhrase>(glue, sp, ap);
	  return p;
   }	
   	template<typename T>
    void ScoreUNK(T* tp) {
      // UNK_PROP = WP * -1 + PP * 1;
      // REST_COST = WLM * LM(copied unk) - UNK_PROP
      
      float lmprobs = 0;
      
      for(auto& ff : God::GetFFs()) {
        if (ff->GetFFType() == FFType::LanguageModel
            || ff->GetFFType() == FFType::WordClassLanguageModel) {
          lm::NGram ngram(tp->GetPhrase().data(), tp->GetPhrase().size());
          float prob = std::static_pointer_cast<FFLanguageModel>(ff)->QueryProb(ngram);
#if defined HIER_MERT
          lmprobs += prob ;
#else
		  lmprobs += prob * ff->GetWeights()[0];
#endif
        }
      }
      
      const ScorePiece& sp = tp->GetScores();

#if defined HIER_MERT
      const_cast<float&>(sp.data()[static_cast<size_t>(FEATURELIST::WP)]) = -1;
	  const_cast<float&>(sp.data()[static_cast<size_t>(FEATURELIST::PP)]) = 1;
	  const_cast<float&>(sp.data()[static_cast<size_t>(FEATURELIST::LM)]) = lmprobs;
#elif defined HIER_RELEASE
	  const_cast<float&>(sp.data()[0]) = -20+lmprobs+
		  (-1)*weights[static_cast<size_t>(FEATURELIST::WP)]+
		  1 * weights[static_cast<size_t>(FEATURELIST::PP)];
#else
	  const_cast<float&>(sp.data()[0]) = penalties_;
      const_cast<float&>(sp.data()[1]) = lmprobs - sp[0];
#endif
    }
    
    template <class Key,class T>
    std::vector<T*> UNK(const Key& key) {
      PhrasePiece unk((lm::Word*)key.data(), key.size());
 
#if defined  HIER_MERT
      float* unkScores = God::Memory<float>(WNUM);
      ScorePiece sp(unkScores, WNUM);

#elif defined HIER_RELEASE
	  float* unkScores = God::Memory<float>(1);
      ScorePiece sp(unkScores, 1);
#else
	  float* unkScores = God::Memory<float>(2);
      ScorePiece sp(unkScores, 2);
#endif


      AlignmentPiece ap(&oneone_, 1);
	  std::vector<T*> tps;
      tps.emplace_back(God::Create<T>(unk, sp, ap));
      ScoreUNK(tps.back());
      
      return tps;
    }
    void MapBlob(util::Blob& blob) {
      blob
        >> header_;

#if defined HIER_MERT || defined HIER_RELEASE
	  std::cerr<<"hier mode..."<<std::endl;
	  for(size_t i=0;i<WNUM;++i)
	    blob>>weights[i];
#else 
      blob>> penalties_;
#endif
	  blob>> maxSourcePhraseLength_;
      blob >> sources_;
      blob >> targets_;
		
#if defined HIER_RELEASE || defined HIER_MERT
	  xbosScore_[static_cast<size_t>(FEATURELIST::PP)]=1;
	  xeosScore_[static_cast<size_t>(FEATURELIST::PP)]=1;
	  glueScore_[static_cast<size_t>(FEATURELIST::GP)]=1;
	  glueScore_[static_cast<size_t>(FEATURELIST::PP)]=1;
	  xbosScoreRL_[0] = weights[static_cast<size_t>(FEATURELIST::PP)];
	  xeosScoreRL_[0] = weights[static_cast<size_t>(FEATURELIST::PP)];
	  glueScoreRL_[0] = weights[static_cast<size_t>(FEATURELIST::GP)]
		  +weights[static_cast<size_t>(FEATURELIST::PP)];
#endif
    }

    FFHeader header_;
	util::Chunk<float> weights[WNUM]; //wp, pp, gp, lmp, tm
    util::Chunk<float> penalties_;
    util::Chunk<uint64_t> maxSourcePhraseLength_;
    Sources sources_;
    Targets targets_;

    float bosScore_[2] = { 0.0, 0.0 };
    float eosScore_[2] = { 0.0, 0.0 };

	float xbosScore_[WNUM] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    float xeosScore_[WNUM] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};

	float xbosScoreRL_[1] = { 0.0 };
	float xeosScoreRL_[1] = { 0.0 };

	float glueScore_[WNUM] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
	float glueScoreRL_[1] = { 0.0 };

    Alignment oneone_ = { 0, 0 };
	Alignment glue_[2] = {Alignment(0,0),Alignment(1,1)};

    TargetPhrases tpUNK_;
    TargetPhrases tpBOS_;
    TargetPhrases tpEOS_;
	lm::Word glueTarget_[2] = {lm::wX1M, lm::wX2M};

  };

}
