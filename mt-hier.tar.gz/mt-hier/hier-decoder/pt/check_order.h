#pragma once

#include <algorithm>

#include "util/blob.h"

namespace herbal {

struct OrderTuple {
  uint32_t p;
  uint32_t i;
};

class CheckOrder : public  util::Blobbed {
  public:

    OrderTuple& operator[](uint64_t position) {
      return orderTuples_[position];
    }

  private:

    void MapBlob(util::Blob& blob) {
      blob
        >> size_;

      blob
        >> orderTuples_(size_);
    }

    util::Chunk<uint32_t> size_;
    util::ManyChunks<OrderTuple> orderTuples_;
};

}
