#include <iostream>
#include <string>
#include <boost/program_options.hpp>
#include <boost/lexical_cast.hpp>

#include "dec/god.h"
#include "pt/paste.h"

#include "util/string_piece.h"
#include "util/string_piece_split.h"

#include "util/blob.h"
#include "util/bytes.h"
#include "lm/vocab.h"

using namespace herbal;

void packSource(std::vector<lm::Word>& sourceWords, util::StringPiece& source,
                std::unique_ptr<lm::Vocab>& vocab) {
  std::vector<util::StringPiece> srcTokens;
  util::split(srcTokens, source, " ");
  for(auto& tok : srcTokens)
      sourceWords.push_back((*vocab)[tok]);
}

int main(int argc, char** argv) {
  namespace po = boost::program_options;
  po::options_description cmdline_options("Allowed options");

  bool help = false;
  bool counts = false;
  std::string ptPath;
  std::string vocabPath;

  cmdline_options.add_options()
    ("pt,p", po::value(&ptPath)->required(),
     "Path to phrase table")
    ("vocab,v", po::value(&vocabPath)->required(),
     "Path to common vocabulary")
    ("counts,c", po::value(&counts)->zero_tokens()->default_value(false),
     "Report only counts")
    ("help,h", po::value(&help)->zero_tokens()->default_value(false),
     "Print this help message and exit")
  ;

  po::variables_map vm;
  try {
    po::store(po::command_line_parser(argc, argv).
              options(cmdline_options).run(), vm);
    po::notify(vm);
  }
  catch (std::exception& e) {
    std::cout << "Error: " << e.what() << std::endl << std::endl;

    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }

  if (help) {
    std::cout << "Usage: " + std::string(argv[0]) +  " [options]" << std::endl;
    std::cout << cmdline_options << std::endl;
    exit(0);
  }

  std::unique_ptr<lm::Vocab> vocab;
  util::Blob vocabBlob;
  std::unique_ptr<util::ScopedFile> vocabFile;
  if(vocabPath.size() > 0) {
    vocabFile.reset(new util::ScopedFile(vocabPath));
    vocabBlob.Map(*vocabFile);
    vocab.reset(new lm::CHDVocab());
    vocabBlob >> *(lm::CHDVocab*)vocab.get();
  }
  else
    vocab.reset(new lm::GrowVocab());

  util::Blob pasteBlob;
  Paste paste;

  pasteBlob.Map(ptPath);
  pasteBlob >> paste;

  std::string line;
  while(std::getline(std::cin, line)) {
    util::StringPiece linePiece(line);
    std::vector<lm::Word> source;
    packSource(source, linePiece, vocab);
	TargetPhrase t;
    TargetPhrases tp = paste.find<std::vector<lm::Word>, TargetPhrase >(source);
    if(counts) {
      std::cout << line;
      std::cout << " ";
      std::cout << tp.size() << std::endl;
    }
    else {
      for(auto& t : tp) {
        std::cout << line << " ||| " << TargetPhraseVocab(*t, *vocab) << std::endl;
      }
    }
  }
}
