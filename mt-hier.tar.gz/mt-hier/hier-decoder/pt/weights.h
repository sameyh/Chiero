#pragma once

#include "util/blob.h"
#include "util/exception.h"

namespace herbal {

class Weights : public util::Blobbed {
  public:
    typedef const float value_type;

    value_type operator[](uint64_t pos) const {
      THROW_IF(pos >= weightsSize_, "Out of range!");
      return weights_[pos];
    }

    size_t size() const {
      return weightsSize_;
    }

    size_t Size() const {
      return weightsSize_;
    }

  private:
    void MapBlob(util::Blob& blob) {
      blob >> weightsSize_;
      blob >> weights_(weightsSize_);
#ifdef DEBUG
      for(auto w : weights_)
        std::cerr << w << std::endl;
#endif
    }

    util::ChunkC64 weightsSize_;
    util::ManyChunks<value_type> weights_;
};

}
